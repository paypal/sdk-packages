module DocaptureHelper
end
