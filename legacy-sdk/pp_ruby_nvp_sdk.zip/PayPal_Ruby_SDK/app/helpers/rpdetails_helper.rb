module RpdetailsHelper
end
