module MasspayHelper
end
