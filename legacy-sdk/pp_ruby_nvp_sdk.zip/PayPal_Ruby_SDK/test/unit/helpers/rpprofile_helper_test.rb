require 'test_helper'

class RpprofileHelperTest < ActionView::TestCase
end
