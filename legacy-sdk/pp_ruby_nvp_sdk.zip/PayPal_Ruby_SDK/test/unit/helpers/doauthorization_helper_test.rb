require 'test_helper'

class DoauthorizationHelperTest < ActionView::TestCase
end
