require 'test_helper'

class BilloutamtHelperTest < ActionView::TestCase
end
