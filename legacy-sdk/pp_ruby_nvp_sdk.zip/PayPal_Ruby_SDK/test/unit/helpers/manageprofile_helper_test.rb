require 'test_helper'

class ManageprofileHelperTest < ActionView::TestCase
end
