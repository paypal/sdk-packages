require 'test_helper'

class DovoidHelperTest < ActionView::TestCase
end
