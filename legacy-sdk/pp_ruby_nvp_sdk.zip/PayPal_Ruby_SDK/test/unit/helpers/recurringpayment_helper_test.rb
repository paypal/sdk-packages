require 'test_helper'

class RecurringpaymentHelperTest < ActionView::TestCase
end
