require 'test_helper'

class ReauthHelperTest < ActionView::TestCase
end
