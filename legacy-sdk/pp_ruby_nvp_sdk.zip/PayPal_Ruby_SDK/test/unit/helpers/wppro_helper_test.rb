require 'test_helper'

class WpproHelperTest < ActionView::TestCase
end
