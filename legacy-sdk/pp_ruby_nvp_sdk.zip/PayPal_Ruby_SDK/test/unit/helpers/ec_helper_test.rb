require 'test_helper'

class EcHelperTest < ActionView::TestCase
end
