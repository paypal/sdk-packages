require 'test_helper'

class RefundHelperTest < ActionView::TestCase
end
