<?php

/****************************************************
Permissions.php

This file contains client business methods to call
PayPals Permissioning Webservice APIs.

****************************************************/
require_once 'Config/paypal_sdk_clientproperties.php' ;
require_once 'CallerServices.php'  ;
require_once 'Stub/Permissions/PermissionsProxy.php'  ;
require_once 'SOAPEncoder/SOAPEncoder.php'  ;
require_once 'XMLEncoder/XMLEncoder.php'  ;
require_once 'JSONEncoder/JSONEncoder.php'  ;
require_once 'Exceptions/FatalException.php'  ;

class Permissions extends CallerServices {
   
   function RequestPermission($permissionRequest, $SerializeOption=false,$isRequestString = false) {
   		try {
   			if($isRequestString) {
   				return parent::callWebService($permissionRequest, 'Permissions/RequestPermissions');
   			}
   			else {
   				return $this->callAPI($permissionRequest, 'Permissions/RequestPermissions',$SerializeOption);	
   			}
   				
   		}
   		catch(Exception $ex) {
				  			
   			throw new FatalException('Error occurred in PequestPermission method');
   		}
   		
   }


 function GetAccessToken($GetAccesstoken, $isRequestString = false) {
   		try {
   			if($isRequestString) {
   				return parent::callWebService($GetAccesstoken, 'Permissions/GetAccessToken');
   			}
   			else {
   				return $this->callAPI($GetAccesstoken, 'Permissions/GetAccessToken');	
   			}
   				
   		}
   		catch(Exception $ex) {
				  			
   			throw new FatalException('Error occurred in GetAccessToken method');
   		}
   		
   }
   
 function GetPermissions($GetPermission, $isRequestString = false) {
   		try {
   			if($isRequestString) {
   				return parent::callWebService($GetPermission, 'Permissions/GetPermissions');
   			}
   			else {
   				return $this->callAPI($GetPermission, 'Permissions/GetPermissions');	
   			}
   				
   		}
   		catch(Exception $ex) {
				  			
   			throw new FatalException('Error occurred in GetPermission method');
   		}
   		
   }
   
function CancelPermissions($CancelPermission, $isRequestString = false) {
   		try {
   			if($isRequestString) {
   				return parent::callWebService($CancelPermission, 'Permissions/CancelPermissions');
   			}
   			else {
   				return $this->callAPI($CancelPermission, 'Permissions/CancelPermissions');	
   			}
   				
   		}
   		catch(Exception $ex) {
				  			
   			throw new FatalException('Error occurred in CancelPermission method');
   		}
   		
   }
   
   function GetBasicPersonalData($GetBasicPersonalData,$SerializeOption=false, $isRequestString = false) {
   		try {
   			if($isRequestString) {
   				return parent::callWebService($GetBasicPersonalData, 'Permissions/GetBasicPersonalData');
   			}
   			else {
   				return $this->callAPI($GetBasicPersonalData, 'Permissions/GetBasicPersonalData',$SerializeOption);	
   			}
   				
   		}
   		catch(Exception $ex) {
				  			
   			throw new FatalException('Error occurred in GetBasicPersonalData method');
   		}
   		
   }
   
   function GetAdvancedPersonalData($GetAdvancedPersonalData, $SerializeOption=false,$isRequestString = false) {
   		try {
   			if($isRequestString) {
   				return parent::callWebService($GetAdvancedPersonalData, 'Permissions/GetAdvancedPersonalData');
   			}
   			else {
   				return $this->callAPI($GetAdvancedPersonalData, 'Permissions/GetAdvancedPersonalData',$SerializeOption);	
   			}
   				
   		}
   		catch(Exception $ex) {
				  			
   			throw new FatalException('Error occurred in GetAdvancedPersonalData method');
   		}
   		
   }
   /*
    * Calls the call method of CallerServices class and returns the response.
    */
   private function callAPI($request, $URL,$SerializeOption=null)
   {
   		$response = null;
		$isError = false;
		$reqObject = $request;
   		try {
			
   		
   			switch(X_PAYPAL_REQUEST_DATA_FORMAT) {
   				case "JSON" :
   						$request = JSONEncoder::Encode($request);
   						$response = parent::callWebService($request, $URL);
   					break;
   				case "SOAP11" :
   						$request = SoapEncoder::Encode($request,$SerializeOption);
   						$response = parent::call($request, $URL);
   					break;
   				case "XML" :
   						$request = XMLEncoder::Encode($request,$SerializeOption);
   						$response = parent::callWebService($request, $URL);
   						
   					break;
   				
   			}
   			if((X_PAYPAL_RESPONSE_DATA_FORMAT == 'XML')||(X_PAYPAL_RESPONSE_DATA_FORMAT == 'JSON'))
   			{
   				switch(X_PAYPAL_RESPONSE_DATA_FORMAT) {
   				case "JSON" :
   						$strObjName = get_class($reqObject);
        				$strObjName = str_replace('Request', 'Response', $strObjName);
        				$response = JSONEncoder::Decode($response,$isError, $strObjName); 
   					break;
   				case "XML" :
   						$response = XMLEncoder::Decode($response, $isError);
   					break;
   				
   				}  			
			
   			
	      	 if($isError)
	     	  {
	        	$this->isSuccess = 'Failure' ;
	     		$this->setLastError($response) ;
	        	$response = null ;
	     	  }
	      	  else
	      	  {
	   			$this->isSuccess = 'Success' ;
	      	  }
	      	  
   			}  
   		} 
   		catch(Exception $ex) {
				  			
   			throw new FatalException('Error occurred in callAPI method');
   		}
   		
   		return $response;
   }
   
}
?>