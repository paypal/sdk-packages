<?php

if (!class_exists("ErrorData")) {
/**
 * ErrorData
 */
class ErrorData {
	/**
	 * @access public
	 * @var xslong
	 */
	public $errorId;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $domain;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $subdomain;
	/**
	 * @access public
	 * @var tnsErrorSeverity
	 */
	public $severity;
	/**
	 * @access public
	 * @var tnsErrorCategory
	 */
	public $category;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $message;
	/**
	 * @access public
	 * @var xstoken
	 */
	public $exceptionId;
	/**
	 * @access public
	 * @var tnsErrorParameter
	 */
	public $parameter;
}}

if (!class_exists("ErrorParameter")) {
/**
 * ErrorParameter
 */
class ErrorParameter {
}}

if (!class_exists("ResponseEnvelope")) {
/**
 * ResponseEnvelope
 */
class ResponseEnvelope {
	/**
	 * @access public
	 * @var xsdateTime
	 */
	public $timestamp;
	/**
	 * @access public
	 * @var tnsAckCode
	 */
	public $ack;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $correlationId;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $build;
}}

if (!class_exists("RequestEnvelope")) {
/**
 * RequestEnvelope
 */
class RequestEnvelope {
	/**
	 * @access public
	 * @var xsstring
	 */
	public $errorLanguage;
}}

if (!class_exists("FaultMessage")) {
/**
 * FaultMessage
 */
class FaultMessage {
	/**
	 * @access public
	 * @var tnsResponseEnvelope
	 */
	public $responseEnvelope;
	/**
	 * @access public
	 * @var tnsErrorData
	 */
	public $error;
}}

if (!class_exists("RequestPermissionsRequest")) {
/**
 * RequestPermissionsRequest
 */
class RequestPermissionsRequest {
	/**
	 * @access public
	 * @var commonRequestEnvelope
	 */
	public $requestEnvelope;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $scope;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $callback;
}}

if (!class_exists("RequestPermissionsResponse")) {
/**
 * RequestPermissionsResponse
 */
class RequestPermissionsResponse {
	/**
	 * @access public
	 * @var commonResponseEnvelope
	 */
	public $responseEnvelope;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $token;
}}

if (!class_exists("GetAccessTokenRequest")) {
/**
 * GetAccessTokenRequest
 */
class GetAccessTokenRequest {
	/**
	 * @access public
	 * @var commonRequestEnvelope
	 */
	public $requestEnvelope;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $token;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $verifier;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $subjectAlias;
}}

if (!class_exists("GetAccessTokenResponse")) {
/**
 * GetAccessTokenResponse
 */
class GetAccessTokenResponse {
	/**
	 * @access public
	 * @var commonResponseEnvelope
	 */
	public $responseEnvelope;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $scope;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $token;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $tokenSecret;
}}

if (!class_exists("GetPermissionsRequest")) {
/**
 * GetPermissionsRequest
 */
class GetPermissionsRequest {
	/**
	 * @access public
	 * @var commonRequestEnvelope
	 */
	public $requestEnvelope;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $token;
}}

if (!class_exists("GetPermissionsResponse")) {
/**
 * GetPermissionsResponse
 */
class GetPermissionsResponse {
	/**
	 * @access public
	 * @var commonResponseEnvelope
	 */
	public $responseEnvelope;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $scope;
}}

if (!class_exists("CancelPermissionsRequest")) {
/**
 * CancelPermissionsRequest
 */
class CancelPermissionsRequest {
	/**
	 * @access public
	 * @var commonRequestEnvelope
	 */
	public $requestEnvelope;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $token;
}}

if (!class_exists("CancelPermissionsResponse")) {
/**
 * CancelPermissionsResponse
 */
class CancelPermissionsResponse {
	/**
	 * @access public
	 * @var commonResponseEnvelope
	 */
	public $responseEnvelope;
}}

if (!class_exists("PersonalAttributeList")) {
/**
 * PersonalAttributeList
 */
class PersonalAttributeList {
	/**
	 * @access public
	 * @var tnsPersonalAttribute
	 */
	public $attribute;
}}

if (!class_exists("PersonalData")) {
/**
 * PersonalData
 */
class PersonalData {
	/**
	 * @access public
	 * @var tnsPersonalAttribute
	 */
	public $personalDataKey;
	/**
	 * @access public
	 * @var xsstring
	 */
	public $personalDataValue;
}}

if (!class_exists("PersonalDataList")) {
/**
 * PersonalDataList
 */
class PersonalDataList {
	/**
	 * @access public
	 * @var tnsPersonalData
	 */
	public $personalData;
}}

if (!class_exists("GetBasicPersonalDataRequest")) {
/**
 * GetBasicPersonalDataRequest
 */
class GetBasicPersonalDataRequest {
	/**
	 * @access public
	 * @var commonRequestEnvelope
	 */
	public $requestEnvelope;
	/**
	 * @access public
	 * @var tnsPersonalAttributeList
	 */
	public $attributeList;
}}

if (!class_exists("GetAdvancedPersonalDataRequest")) {
/**
 * GetAdvancedPersonalDataRequest
 */
class GetAdvancedPersonalDataRequest {
	/**
	 * @access public
	 * @var commonRequestEnvelope
	 */
	public $requestEnvelope;
	/**
	 * @access public
	 * @var tnsPersonalAttributeList
	 */
	public $attributeList;
}}

if (!class_exists("GetBasicPersonalDataResponse")) {
/**
 * GetBasicPersonalDataResponse
 */
class GetBasicPersonalDataResponse {
	/**
	 * @access public
	 * @var commonResponseEnvelope
	 */
	public $responseEnvelope;
	/**
	 * @access public
	 * @var tnsPersonalDataList
	 */
	public $response;
}}

if (!class_exists("GetAdvancedPersonalDataResponse")) {
/**
 * GetAdvancedPersonalDataResponse
 */
class GetAdvancedPersonalDataResponse {
	/**
	 * @access public
	 * @var commonResponseEnvelope
	 */
	public $responseEnvelope;
	/**
	 * @access public
	 * @var tnsPersonalDataList
	 */
	public $response;
}}


?>