<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>PayPal SDK - Permissions RequestPermission</title>
 <link href="common/style.css" rel="stylesheet" type="text/css" />
</head>
<body >
<br/>
        <div id="jive-wrapper">
            <div id="jive-header">
                <div id="logo">
                    <span >You must be Logged in to <a href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a></span>
                    <a title="Paypal X Home" href="#"><div id="titlex"></div></a>
                </div>
            </div>

<div id="main">
<?php include 'menu.html'?>
<div id="request_form">
<center>
<table align="center" class="api">

	<tr>
		<h3>Request Permission - Response</h3>
	</tr>
	
	
	<?php 
	
	foreach($_GET as $variable => $value)
{
    echo "<tr><td class=\"thinfield\">" . $variable . ":</td>";
    echo "<td class=\"thinfield\">" . $value . "</td>";
}
?>
</table>
</center>
</div>
</div>
</body>
</html>