<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>PayPal SDK - Permissions GetAccessToken</title>
 <link href="common/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<br/>
        <div id="jive-wrapper">
            <div id="jive-header">
                <div id="logo">
                    <span >You must be Logged in to <a href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a></span>
                    <a title="Paypal X Home" href="#"><div id="titlex"></div></a>
                </div>
            </div>


<?php include 'menu.html'?>
<div id="request_form">
 
<form id="Form1" name="Form1" action="GetAccessTokenReceipt.php">

		<h3>Permissions - GetAccessToken</h3>
	
<table align="center">
	
	<tr>
		<td class="thinfield" width="50"></td>
	</tr>
	<tr>
		<td class="thinfield" width="50">token</td>
		<td><input id="token"  maxlength="32" name="token" 	size="50" type="text" /></td>
	</tr>
	<tr>
		<td class="thinfield" width="50">verifier</td>
		<td align="left"><input id="verifier" maxlength="32" name="verifier" size="50" type="text" /></td>
	</tr>
	<tr>
		<td class="thinfield" width="50">subjectAlias</td>
		<td align="left"><input id="subjectAlias" maxlength="32" name="subjectAlias" size="50" type="text" /></td>
	</tr>
	 <tr>
	<td>
	<br />
	</td>
	</tr>

	<tr align="center">
<td colspan="2">
<a class="pop-button primary" onclick="document.Form1.submit();" id="Submit"><span>Submit</span></a>
			</td>
		</tr>
</table>



</form>
</div>
</div>
</body>
</html>
