<?php 
/*PermissionRequestReceipt.php
Called by PermissionRequest.php
Calls  CallerService.php,and APIError.php.
********************************************/
session_start();
require_once '../../../lib/Permissions.php';
require_once 'web_constants.php';

try {
		
	           $serverName = $_SERVER['SERVER_NAME'];
	           $serverPort = $_SERVER['SERVER_PORT'];
	           $url=dirname('http://'.$serverName.':'.$serverPort.$_SERVER['REQUEST_URI']);
			   $returnURL = $url."/RequestPermissionsResponse.php";
	
	          /* Make the call to PayPal to Request Permission token
	            If the API call succeded, then redirect to PayPal
	            where merchant logs in and grants the permission to the partner.  
	            If an error occured, show the resulting errors
	            */        
	
	          
		
		$RequestPermissionsRequest = new RequestPermissionsRequest();
		$RequestPermissionsRequest->callback= $_REQUEST['callback'];
	
		$RequestPermissionsRequest->requestEnvelope = new RequestEnvelope();
		$RequestPermissionsRequest->requestEnvelope->errorLanguage = "en_US";
if(isset($_REQUEST['api']))
   {
    $i =0;
  
    foreach ($_POST['api'] as $value)
    {
    	
    $RequestPermissionsRequest->scope[]=$value;
     
     $i++;
     
    }
    

   }
		 $permission = new Permissions();
		 $response=$permission->RequestPermission($RequestPermissionsRequest,$SerializeOption='simplexml');
		           
		           if(strtoupper($permission->isSuccess) == 'FAILURE')
					{
						//Redirecting to APIError.php to display errors.
						$_SESSION['FAULTMSG']=$permission->getLastError();
						$location = "APIError.php";
						header("Location: $location");
					
					}
					else
					{	
						// Redirect to paypal.com here
						$_SESSION['RequestToken'] = $response->token;
						$RequestToken =$response->token;
						$payPalURL = PAYPAL_REDIRECT_URL.'_grant-permission&request_token='.$RequestToken;
		                header("Location: ".$payPalURL);
						
					}
			}
			catch(Exception $ex) {
				
				$fault = new FaultMessage();
				$errorData = new ErrorData();
				$errorData->errorId = $ex->getFile() ;
  				$errorData->message = $ex->getMessage();
		  		$fault->error = $errorData;
				$_SESSION['FAULTMSG']=$fault;
				$location = "APIError.php";
				header("Location: $location");
			}
			

?>


