<?php 
/*GetPermissionsReceipt.php
Called by GetPermissions.php
Calls  CallerService.php,and APIError.php.
********************************************/
session_start();
require_once '../../../lib/Permissions.php';
require_once 'web_constants.php';

try {
		$GetPermissions= new getPermissionsRequest();
		$GetPermissions->token=$_REQUEST['token'];
		$GetPermissions->requestEnvelope = new RequestEnvelope();
		$GetPermissions->requestEnvelope->errorLanguage = "en_US";
	
		 $permission = new Permissions();
		 $response=$permission->GetPermissions($GetPermissions);
		           
		           if(strtoupper($permission->isSuccess) == 'FAILURE')
					{
						//Redirecting to APIError.php to display errors.
						$_SESSION['FAULTMSG']=$permission->getLastError();
						$location = "APIError.php";
						header("Location: $location");
					
					}
					
			}
			catch(Exception $ex) {
				
				$fault = new FaultMessage();
				$errorData = new ErrorData();
				$errorData->errorId = $ex->getFile() ;
  				$errorData->message = $ex->getMessage();
		  		$fault->error = $errorData;
				$_SESSION['FAULTMSG']=$fault;
				$location = "APIError.php";
				header("Location: $location");
			}
			

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>PayPal SDK - Permissions GetPermission</title>
 <link href="common/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<br/>
        <div id="jive-wrapper">
            <div id="jive-header">
                <div id="logo">
                    <span >You must be Logged in to <a href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a></span>
                    <a title="Paypal X Home" href="#"><div id="titlex"></div></a>
                </div>
            </div>

<div id="main">
<?php include 'menu.html'?>
<div id="request_form">
	
		<h3> GetPermissions -response</h3>

<table align="center">


	<tr>
		<td class="thinfield">Scope:</td>
		<td class="thinfield">
<?php
if(isset($response->scope))
		{
			foreach($response->scope as $val)
			{
				echo "<br>".$val;
			}
		}
 		?>
		</td>
	</tr>
</table>
</div>
</div>

</body>
</html>