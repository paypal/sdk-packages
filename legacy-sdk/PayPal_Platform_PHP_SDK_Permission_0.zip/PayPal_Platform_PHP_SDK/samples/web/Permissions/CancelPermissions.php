<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>PayPal SDK - Permissions CancelPermission</title>
 <link href="common/style.css" rel="stylesheet" type="text/css" />

</head>

<body>
<br/>
        <div id="jive-wrapper">
            <div id="jive-header">
                <div id="logo">
                    <span >You must be Logged in to <a href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a></span>
                    <a title="Paypal X Home" href="#"><div id="titlex"></div></a>
                </div>
            </div>

<div id="main">
<?php include 'menu.html'?>
<div id="request_form">

    <form id="Form1" name="Form1" method="post" action="CancelPermissionsReceipt.php">
	<h3>Permissions - CancelPermissions</h3>
<br />


<table align="center">
	
	<tr>
		<td class="thinfield2">token:</td>
		<td class="thinfield3"><input id="token1" type="text" size="60" value="" name="token"></td>
	</tr>
	<tr>
	<td>
	<br />
	</td>
	</tr>

	<tr align="center">
<td colspan="2">
<a class="pop-button primary" onclick="document.Form1.submit();" id="Submit"><span>Submit</span></a>
			</td>
		</tr>
</table>

</form>
</div>
</div>
</body>
</html>