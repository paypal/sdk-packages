<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<title>PayPal SDK - Permissions GetBasicPersonalData</title>
		<link href="common/style.css" rel="stylesheet" type="text/css" />
	</head>
	<?php
require_once 'web_constants.php';
$serverName=$_SERVER['SERVER_NAME'];
$serverPort=$_SERVER['SERVER_PORT'];
$url=dirname('http://'.$serverName.':'.$serverPort.$_SERVER['REQUEST_URI']);
$callbackURL=$url."/GetBasicPersonalDataResponse.php";
	?>

	<body>
		<br/>
		<div id="jive-wrapper">
			<div id="jive-header">
				<div id="logo">
					<span >
						You must be Logged in to
						<a href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a>
					</span>
					<a title="Paypal X Home" href="#">
					<div id="titlex">
					</div>
					</a>
				</div>
			</div>
			<div id="main">
				<?php include 'menu.html'?>
				<div id="request_form">
					<form name="Form1" method="post" action="GetBasicPersonalDataReceipt.php">

						<h3>GetBasicPersonalData</h3>
						<table width="500" >

							
							<tr>
								<td class="smalltext" width="52">Basic Attributes:</td>
								<td class="thinfield">
								<input type=checkbox name=attr[] value='http://axschema.org/namePerson/first' checked=true/>
								FirstName
								<br />
								<input type=checkbox name=attr[] value='http://axschema.org/namePerson/last' checked=true/>
								LastName
								<br />
								<input type=checkbox name=attr[] value='http://axschema.org/contact/email' checked=true/>
								Email
								<br />
								<input type=checkbox name=attr[] value='http://schema.openid.net/contact/fullname' checked=true/>
								FullName
								<br />
								<input type=checkbox name=attr[] value='http://axschema.org/company/name' checked=true/>
								BusinessName
								<br />
								<input type=checkbox name=attr[] value='http://axschema.org/contact/country/home' checked=true/>
								CountryCode
								<br />
								<input type=checkbox name=attr[] value='https://www.paypal.com/webapps/auth/schema/payerID' checked=true/>
								PayerId
								<br />
								</td>
							</tr>
							<tr>
								<td>
								<br />
								</td>
							</tr>
							<tr align="center">
								<td colspan="2">
								<a class="pop-button primary" onclick="document.Form1.submit();" id="Submit">
								<span>Submit</span>
								</a>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
	</body>
</html>
