<?php 
/*GetAccessTokenReceipt.php
Called by GetAccessToken.php
Calls  CallerService.php,and APIError.php.
********************************************/
session_start();
require_once '../../../lib/Permissions.php';
require_once 'web_constants.php';

try {
		$GetAccessToken= new getAccessTokenRequest();
		$GetAccessToken->token=$_REQUEST['token'];
		$GetAccessToken->verifier=$_REQUEST['verifier'];
		if(!empty($_REQUEST['subjectAlias']))
		{
			$GetAccessToken->subjectAlias=$_REQUEST['subjectAlias'];
		}
		$GetAccessToken->requestEnvelope = new RequestEnvelope();
		$GetAccessToken->requestEnvelope->errorLanguage = "en_US";
	
		 $permission = new Permissions();
		 $response=$permission->GetAccessToken($GetAccessToken);
		           
		           if(strtoupper($permission->isSuccess) == 'FAILURE')
					{
						//Redirecting to APIError.php to display errors.
						$_SESSION['FAULTMSG']=$permission->getLastError();
						$location = "APIError.php";
						header("Location: $location");
					
					}
					else
					{
?>	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">					
<html>
<head>
<title>PayPal SDK - Permissions GetAccessToken</title>
 <link href="common/style.css" rel="stylesheet" type="text/css" />
</head>
<body >	
<br/>
        <div id="jive-wrapper">
            <div id="jive-header">
                <div id="logo">
                    <span >You must be Logged in to <a href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a></span>
                    <a title="Paypal X Home" href="#"><div id="titlex"></div></a>
                </div>
            </div>

<div id="main">
<?php include 'menu.html'?>
<div id="request_form">

		<h3>Get Access Token- Response</h3>
	
 

<table width="50%" align="center">
	
	
	<tr>
		<td class="thinfield">Acknowledgement:</td>
		<td class="thinfield"><?php echo $response->responseEnvelope->ack; ?></td>
	</tr>
	<tr>
		<td class="thinfield">Token :</td>
		<td class="thinfield"><?php echo $response->token;?></td>
	</tr>

	<tr>
		<td class="thinfield">Token Secret:</td>
		<td class="thinfield"><?php echo $response->tokenSecret;?></td>
	</tr>

	<tr>
		<td class="thinfield">Scope:</td>
		<td class="thinfield">
		<?php 
		if(isset($response->scope))
		{
			foreach($response->scope as $val)
			{
				echo "<br>".$val;
			}
		}
		?>
		</td>
	</tr>

</table>
</div>
</div>
</body>
</html>
<?php 
					}
					
			}
			catch(Exception $ex) {
				
				$fault = new FaultMessage();
				$errorData = new ErrorData();
				$errorData->errorId = $ex->getFile() ;
  				$errorData->message = $ex->getMessage();
		  		$fault->error = $errorData;
				$_SESSION['FAULTMSG']=$fault;
				$location = "APIError.php";
				header("Location: $location");
			}
			

?>
	
	
