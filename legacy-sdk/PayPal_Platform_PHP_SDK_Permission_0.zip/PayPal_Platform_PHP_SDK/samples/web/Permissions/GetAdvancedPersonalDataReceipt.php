<?php 
/*PermissionRequestReceipt.php
Called by PermissionRequest.php
Calls  CallerService.php,and APIError.php.
********************************************/
session_start();
require_once '../../../lib/Permissions.php';
require_once 'web_constants.php';

try {
		
	           $serverName = $_SERVER['SERVER_NAME'];
	           $serverPort = $_SERVER['SERVER_PORT'];
	           $url=dirname('http://'.$serverName.':'.$serverPort.$_SERVER['REQUEST_URI']);
			   $returnURL = $url."/GetAdvancedPersonalDataResponse.php";
	
	          /* Make the call to PayPal to Request Permission token
	            If the API call succeded, then redirect to PayPal
	            where merchant logs in and grants the permission to the partner.  
	            If an error occured, show the resulting errors
	            */        
	
	          
		
		$GetAdvancedPersonalDataRequest = new GetAdvancedPersonalDataRequest();
	
	
		$GetAdvancedPersonalDataRequest->requestEnvelope = new RequestEnvelope();
		$GetAdvancedPersonalDataRequest->requestEnvelope->errorLanguage = "en_US";
if(isset($_REQUEST['attr']))
   {
    $i =0;
  
    foreach ($_POST['attr'] as $value)
    {
    	
    $GetAdvancedPersonalDataRequest->attributeList->attribute[]=$value;
     
     $i++;
     
    }
    

   }
		 $permission = new Permissions();
		 $response=$permission->GetAdvancedPersonalData($GetAdvancedPersonalDataRequest,$SerializeOption='simplexml');
		           
		           if(strtoupper($permission->isSuccess) == 'FAILURE')
					{
						//Redirecting to APIError.php to display errors.
						$_SESSION['FAULTMSG']=$permission->getLastError();
						$location = "APIError.php";
						header("Location: $location");
					
					}
					else
					{	
						?>	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">					
<html>
<head>
<title>PayPal SDK - Permissions GetAccessToken</title>
 <link href="common/style.css" rel="stylesheet" type="text/css" />
</head>
<body >	
<br/>
        <div id="jive-wrapper">
            <div id="jive-header">
                <div id="logo">
                    <span >You must be Logged in to <a href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a></span>
                    <a title="Paypal X Home" href="#"><div id="titlex"></div></a>
                </div>
            </div>

<div id="main">
<?php include 'menu.html'?>
<div id="request_form">

		<h3>Get Access Token- Response</h3>
	
 

<table width="50%" align="center">
	
	
	<tr>
		<td class="thinfield">Acknowledgement:</td>
		<td class="thinfield"><?php echo $response->responseEnvelope->ack; ?></td>
	</tr>
	

	<tr>
		<td class="thinfield">Attributes:</td></tr>
		
		
		<?php 
		if(isset($response->response))
		{
		$personalData=$response->response;
			foreach($personalData->personalData as $val)
			{
			?>
			<tr>
			<td class="thinfield">
			<?php 
			echo "Name:";
			?>
			</td>
			<td class="thinfield">
			<?php 
		
				echo $val->personalDataKey."<br>";
				?>
			</td></tr><tr>
			<td class="thinfield">
			<?php 
			echo "Value:";
			?>
			</td>
			<td class="thinfield">
			<?php 
		
				echo $val->personalDataValue."<br>";
				?>
			</td>
			</tr>
			<?php 
			}
		}
		?>
		
	

</table>
</div>
</div>
</body>
</html>
<?php 
						
					}
			}
			catch(Exception $ex) {
				
				$fault = new FaultMessage();
				$errorData = new ErrorData();
				$errorData->errorId = $ex->getFile() ;
  				$errorData->message = $ex->getMessage();
		  		$fault->error = $errorData;
				$_SESSION['FAULTMSG']=$fault;
				$location = "APIError.php";
				header("Location: $location");
			}
			

?>


