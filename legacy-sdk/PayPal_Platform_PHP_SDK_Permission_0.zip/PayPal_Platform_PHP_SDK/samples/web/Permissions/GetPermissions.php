<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>PayPal SDK - Permissions GetPermission</title>
<link href="common/style.css" rel="stylesheet" type="text/css" />

</head>

<body>
<br />
<div id="jive-wrapper">
<div id="jive-header">
<div id="logo"><span>You must be Logged in to <a
	href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a></span>
<a title="Paypal X Home" href="#">
<div id="titlex"></div>
</a></div>
</div>


<?php include 'menu.html'?>
<div id="request_form">
<form name="Form1" method="post" action="GetPermissionsReceipt.php">


<h3>GetPermissions Request</h3>
<br />

<table align="center">

	<tr>
		<td class="thinfield2">Token:</td>
		<td class="thinfield3"><input id="token" maxlength="100" name="token"
			size="60" type="text" /></td>
	</tr>

	<tr>
		<td><br />
		</td>
	</tr>

	<tr align="center">
		<td colspan="2"><a class="pop-button primary"
			onclick="document.Form1.submit();" id="Submit"><span>Submit</span></a>
		</td>
	</tr>
</table>

</form>
</div>
</div>

</body>
</html>
