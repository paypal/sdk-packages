<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>PayPal PHP SDK - Permission Signature generation</title>
 <link href="common/style.css" rel="stylesheet" type="text/css" />
</head>
<body >
<br/>
        <div id="jive-wrapper">
            <div id="jive-header">
                <div id="logo">
                    <span >You must be Logged in to <a href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a></span>
                    <a title="Paypal X Home" href="#"><div id="titlex"></div></a>
                </div>
            </div>

<div id="main">
<?php include 'menu.html'?>
<div id="request_form">
<br />
<h3>Generate Signature</h3>
<br />

<form name="Form1" method="post" action="OAuth_client.php">

<table align="center">
	<tr>
		<td class="thinfield">API User Name(Consumer Key):</td>
		<td class="thinfield"><input type="text" name="consumerKey" value="" size="50" /></td>
		<td class="thinfield">(Required)</td>
	</tr>
	<tr>
		<td class="thinfield">API Password(Consumer Secret):</td>

		<td class="thinfield"><input type="text" name="consumerSecret" value="" size="50"/></td>
		<td class="thinfield">(Required)</td>
	</tr>
	<tr>
		<td class="thinfield">Access Token:</td>
		<td class="thinfield"><input type="text" name="accessToken" value="" size="50"/></td>
		<td class="thinfield">(Required)</td>

	</tr>

	<tr>
		<td class="thinfield">Token Secret:</td>
		<td class="thinfield"><input type="text" name="tokenSecret" value="" size="50"/></td>
		<td class="thinfield">(Required)</td>
	</tr>
	<tr>

		<td class="thinfield">Http Method:</td>
		<td class="thinfield">
		   <select name="httpMethod">
				<option value="POST" >POST</option>
			
			</select>
		</td>
		<td class="thinfield">(Required)</td>
	</tr>

	<tr>
		<td class="thinfield">Script Uri (endpoint):</td>

		<td class="thinfield"><input type="text" name="endpoint" value="" size="50"/></td>
		<td class="thinfield">(Required)</td>
	</tr>
 <tr>
	<td>
	<br />
	</td>
	</tr>

	<tr align="center">
<td colspan="2">
<a class="pop-button primary" onclick="document.Form1.submit();" id="Submit"><span>Submit</span></a>
			</td>
		</tr>
</table>
<br/>

</form>
</div>
</div>
</body>
</html>