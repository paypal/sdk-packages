<?php

/******************************************************
CancelPermissionReceipt.php


******************************************************/
session_start();
require_once '../../../lib/Permissions.php';
require_once 'web_constants.php';


session_start();

	
	try {
		
		$CPRequest = new cancelPermissionsRequest();
		$CPRequest->token = $_REQUEST['token']; 
		$CPRequest->requestEnvelope = new RequestEnvelope();
		$CPRequest->requestEnvelope->errorLanguage = "en_US";
		
		
		$Permission = new Permissions();
		$response = $Permission->CancelPermissions($CPRequest);
		
		
		/* Display the API response back to the browser.
		   If the response from PayPal was a success, display the response parameters'
		   If the response was an error, display the errors received using APIError.php.
		*/
			if(strtoupper($Permission->isSuccess) == 'FAILURE')
			{
				$_SESSION['FAULTMSG']=$Permission->getLastError();
				$location = "APIError.php";
				header("Location: $location");
			
			}		
	}
	catch(Exception $ex) {
		
		$fault = new FaultMessage();
		$errorData = new ErrorData();  
		$errorData->errorId = $ex->getFile() ;
  		$errorData->message = $ex->getMessage();
  		$fault->error = $errorData;
		$_SESSION['FAULTMSG']=$fault;
		$location = "APIError.php";
		header("Location: $location");
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
  <meta name="generator" content=
  "HTML Tidy for Windows (vers 14 February 2006), see www.w3.org">

  <title>PayPal PHP SDK -Cancel Permissions</title>
 <link href="common/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<br/>
        <div id="jive-wrapper">
            <div id="jive-header">
                <div id="logo">
                    <span >You must be Logged in to <a href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a></span>
                    <a title="Paypal X Home" href="#"><div id="titlex"></div></a>
                </div>
            </div>

<div id="main">
<?php include 'menu.html'?>
<div id="request_form">
 
  
	<h3><b>Cancel Permissions -response </b></h3><br>

	
 
    <table align="center">
		
		<tr>
        <td class="thinfield">Transaction Status:</td>
        <td class="thinfield"><?php echo $response->responseEnvelope->ack ; ?></td>
    </tr> 	
      <tr>
        <td class="thinfield">CorrelationId:</td>
        <td class="thinfield"><?php echo $response->responseEnvelope->correlationId ; ?></td>
    </tr>
    </table>
 </div>
 </div>
</body>
</html>