<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<title>PayPal SDK - Permissions RequestPermission</title>
		<link href="common/style.css" rel="stylesheet" type="text/css" />
	</head>
	<?php
require_once 'web_constants.php';
$serverName=$_SERVER['SERVER_NAME'];
$serverPort=$_SERVER['SERVER_PORT'];
$url=dirname('http://'.$serverName.':'.$serverPort.$_SERVER['REQUEST_URI']);
$callbackURL=$url."/RequestPermissionsResponse.php";
	?>

	<body>
		<br/>
		<div id="jive-wrapper">
			<div id="jive-header">
				<div id="logo">
					<span >
						You must be Logged in to
						<a href="<?php echo DEVELOPER_PORTAL;?>" target="_blank">PayPal sandbox</a>
					</span>
					<a title="Paypal X Home" href="#">
					<div id="titlex">
					</div>
					</a>
				</div>
			</div>
			<div id="main">
				<?php include 'menu.html'?>
				<div id="request_form">
					<form name="Form1" method="post" action="RequestPermissionsReceipt.php">

						<h3>RequestPermissions</h3>
						<table width="500" >

							<tr>
								<td class="smalltext">callback:</td>
								<td class="thinfield">
								<input id="callback" type="text" maxLength="32" size="100"
								value="<?php echo $callbackURL;?>" name="callback">
								</td>
							</tr>
							<tr>
								<td class="smalltext" width="52">scope</td>
								<td class="thinfield">
								<input class="checkbox" type="checkbox" name="api[]" value="EXPRESS_CHECKOUT">
								EXPRESS_CHECKOUT
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="DIRECT_PAYMENT">
								DIRECT_PAYMENT
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="AUTH_CAPTURE">
								AUTH_CAPTURE
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="AIR_TRAVEL">
								AIR_TRAVEL
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="TRANSACTION_SEARCH">
								TRANSACTION_SEARCH
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="RECURRING_PAYMENTS">
								RECURRING_PAYMENTS
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="ACCOUNT_BALANCE">
								ACCOUNT_BALANCE
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="ENCRYPTED_WEBSITE_PAYMENTS">
								ENCRYPTED_WEBSITE_PAYMENTS
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="REFUND">
								REFUND
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="BILLING_AGREEMENT">
								BILLING_AGREEMENT
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="REFERENCE_TRANSACTION">
								REFERENCE_TRANSACTION
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="MASS_PAY">
								MASS_PAY
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="TRANSACTION_DETAILS">
								TRANSACTION_DETAILS
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="NON_REFERENCED_CREDIT">
								NON_REFERENCED_CREDIT
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="SETTLEMENT_CONSOLIDATION"/>
								SETTLEMENT_CONSOLIDATION
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="SETTLEMENT_REPORTING"/>
								SETTLEMENT_REPORTING
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="BUTTON_MANAGER"/>
								BUTTON_MANAGER
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="MANAGE_PENDING_TRANSACTION_STATUS">
								MANAGE_PENDING_TRANSACTION_STATUS
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="RECURRING_PAYMENT_REPORT"/>
								RECURRING_PAYMENT_REPORT
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="EXTENDED_PRO_PROCESSING_REPORT"/>
								EXTENDED_PRO_PROCESSING_REPORT
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="EXCEPTION_PROCESSING_REPORT"/>
								EXCEPTION_PROCESSING_REPORT
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="ACCOUNT_MANAGEMENT_PERMISSION"/>
								ACCOUNT_MANAGEMENT_PERMISSION
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="INVOICING"/>
								INVOICING
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="ACCESS_BASIC_PERSONAL_DATA"/>
								ACCESS_BASIC_PERSONAL_DATA
								<br/>
								<input class="checkbox" type="checkbox" name="api[]" value="ACCESS_ADVANCED_PERSONAL_DATA"/>
								ACCESS_ADVANCED_PERSONAL_DATA
								<br/>
								</td>
							</tr>
							<tr>
								<td>
								<br />
								</td>
							</tr>
							<tr align="center">
								<td colspan="2">
								<a class="pop-button primary" onclick="document.Form1.submit();" id="Submit">
								<span>Submit</span>
								</a>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
	</body>
</html>
