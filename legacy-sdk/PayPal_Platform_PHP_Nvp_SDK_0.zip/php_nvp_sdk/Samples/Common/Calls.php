<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head >
    <title>PayPal Platform SDK Calls page</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
        <div id="jive-wrapper">
            <div id="jive-header">
                <div id="logo">
                    <span style="float: right; height: 30px;">Login to <a href="https://developer.paypal.com">PayPal sandbox</a></span>
                    <a title="Paypal X Home" href="#" id="web_pageheader_anchor_index"><img width="266" height="28" border="0" alt="Paypal X" src="../Common/paypal_x_logo.gif"></img></a>
                </div>
            </div><h1>&nbsp;</h1>
        </div>
<?php
include 'menu.html'; 
?>
<table align="center">
<tr>
<td>
Welcome to PayPal Platform PHP NVP SDK
</td>
</tr>
</table>
</div>
</body>
</html>

