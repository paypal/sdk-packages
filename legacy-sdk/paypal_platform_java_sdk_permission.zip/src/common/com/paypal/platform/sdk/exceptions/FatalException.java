package common.com.paypal.platform.sdk.exceptions;

public class FatalException extends Exception {

	public FatalException() {
		// TODO Auto-generated constructor stub
	}

	public FatalException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FatalException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public FatalException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
