package permissions;

import java.util.Properties;

import javax.xml.ws.BindingProvider;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.paypal.svcs.services.PPFaultMessage;
import com.paypal.svcs.services.PermissionsPortType;
import com.paypal.svcs.types.perm.CancelPermissionsRequest;
import com.paypal.svcs.types.perm.CancelPermissionsResponse;
import com.paypal.svcs.types.perm.GetAccessTokenRequest;
import com.paypal.svcs.types.perm.GetAccessTokenResponse;
import com.paypal.svcs.types.perm.GetAdvancedPersonalDataRequest;
import com.paypal.svcs.types.perm.GetAdvancedPersonalDataResponse;
import com.paypal.svcs.types.perm.GetBasicPersonalDataRequest;
import com.paypal.svcs.types.perm.GetBasicPersonalDataResponse;
import com.paypal.svcs.types.perm.GetPermissionsRequest;
import com.paypal.svcs.types.perm.GetPermissionsResponse;
import com.paypal.svcs.types.perm.RequestPermissionsRequest;
import com.paypal.svcs.types.perm.RequestPermissionsResponse;
import common.com.paypal.platform.sdk.CallerServices;
import common.com.paypal.platform.sdk.exceptions.FatalException;
import common.com.paypal.platform.sdk.exceptions.SSLConnectionException;
import common.com.paypal.platform.sdk.utils.JsonSerialiser;
import common.com.paypal.platform.sdk.utils.XMLSerialiser;

public class Permissions extends CallerServices {
	private static Log log = LogFactory.getLog(Permissions.class);
	private static String permissionEndpoint = null;
	String packageContext = "com.paypal.svcs.types.perm";

	private final com.paypal.svcs.services.Permissions service = new com.paypal.svcs.services.Permissions();

	public Permissions() throws FatalException, SSLConnectionException {
		try {
			CallerServices.loadPropertiesFromDefaultLocation();
			permissionEndpoint = CallerServices.getPayPalBaseEndpoint()
					+ "/Permissions/";
			setupSSL();
		} catch (Exception localException) {
			throw new FatalException(localException);
		}
	}

	public Permissions(String paramString) throws FatalException,
			SSLConnectionException {
		try {
			CallerServices.loadPropertiesFromFiles(paramString);
			permissionEndpoint = CallerServices.getPayPalBaseEndpoint()
					+ "/Permissions/";
			setupSSL();
		} catch (Exception localException) {
			throw new FatalException(localException);
		}
	}

	public Permissions(Properties paramProperties) throws FatalException,
			SSLConnectionException {
		try {
			CallerServices.loadProperties(paramProperties);
			setupSSL();
			permissionEndpoint = CallerServices.getPayPalBaseEndpoint()
					+ "/Permissions/";
		} catch (Exception localException) {
			throw new FatalException(localException);
		}
	}

	public RequestPermissionsResponse requestPermissions(
			RequestPermissionsRequest request) throws FatalException,
			PPFaultMessage {
		RequestPermissionsResponse localPermResponse = null;
		String payload = "";
		String serverResponse = "";
		String endpoint = permissionEndpoint + "RequestPermissions";
		if ("JSON".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = JsonSerialiser.serializeObjectToJson(request);
			serverResponse = call(payload, endpoint);
			localPermResponse = (RequestPermissionsResponse) JsonSerialiser
					.deserializeJsonToObject(serverResponse,
							RequestPermissionsResponse.class);
		} else if ("XML".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = XMLSerialiser.serializeObjectToXML(request,
					packageContext);
			serverResponse = call(payload, endpoint);
			localPermResponse = (RequestPermissionsResponse) XMLSerialiser
					.deserializeXMLToObject(serverResponse,
							RequestPermissionsResponse.class, packageContext);
		} else if ("SOAP11".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			try {
				PermissionsPortType permissionsPortType = null;
				permissionsPortType = setupSoapClient(endpoint);
				localPermResponse = permissionsPortType
						.requestPermissions(request);
				log.debug("SOAP request and response :" + output.toString());
			} catch (PPFaultMessage ppf) {
				log.debug("SOAP request and response :" + output.toString());
				throw ppf;
			}
		}
		return localPermResponse;
	}

	public CancelPermissionsResponse cancelPermissions(
			CancelPermissionsRequest request) throws FatalException,
			PPFaultMessage {
		CancelPermissionsResponse localPermResponse = null;
		String payload = "";
		String serverResponse = "";
		String endpoint = permissionEndpoint + "CancelPermissions";
		if ("JSON".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = JsonSerialiser.serializeObjectToJson(request);
			serverResponse = call(payload, endpoint);
			localPermResponse = (CancelPermissionsResponse) JsonSerialiser
					.deserializeJsonToObject(serverResponse,
							CancelPermissionsResponse.class);
		} else if ("XML".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = XMLSerialiser.serializeObjectToXML(request,
					packageContext);
			serverResponse = call(payload, endpoint);
			localPermResponse = (CancelPermissionsResponse) XMLSerialiser
					.deserializeXMLToObject(serverResponse,
							CancelPermissionsResponse.class, packageContext);
		} else if ("SOAP11".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			try {
				PermissionsPortType permissionsPortType = null;
				permissionsPortType = setupSoapClient(endpoint);
				localPermResponse = permissionsPortType
						.cancelPermissions(request);
				log.debug("SOAP request and response :" + output.toString());
			} catch (PPFaultMessage ppf) {
				log.debug("SOAP request and response :" + output.toString());
				throw ppf;
			}
		}
		return localPermResponse;
	}

	public GetAccessTokenResponse getAccessToken(GetAccessTokenRequest request)
			throws FatalException, PPFaultMessage {
		GetAccessTokenResponse localPermResponse = null;
		String payload = "";
		String serverResponse = "";
		String endpoint = permissionEndpoint + "GetAccessToken";
		if ("JSON".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = JsonSerialiser.serializeObjectToJson(request);
			serverResponse = call(payload, endpoint);
			localPermResponse = (GetAccessTokenResponse) JsonSerialiser
					.deserializeJsonToObject(serverResponse,
							GetAccessTokenResponse.class);
		} else if ("XML".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = XMLSerialiser.serializeObjectToXML(request,
					packageContext);
			serverResponse = call(payload, endpoint);
			localPermResponse = (GetAccessTokenResponse) XMLSerialiser
					.deserializeXMLToObject(serverResponse,
							GetAccessTokenResponse.class, packageContext);
		} else if ("SOAP11".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			try {
				PermissionsPortType permissionsPortType = null;
				permissionsPortType = setupSoapClient(endpoint);
				localPermResponse = permissionsPortType.getAccessToken(request);
				log.debug("SOAP request and response :" + output.toString());
			} catch (PPFaultMessage ppf) {
				log.debug("SOAP request and response :" + output.toString());
				throw ppf;
			}
		}
		return localPermResponse;
	}

	public GetPermissionsResponse getPermissions(GetPermissionsRequest request)
			throws FatalException, PPFaultMessage {
		GetPermissionsResponse localPermResponse = null;
		String payload = "";
		String serverResponse = "";
		String endpoint = permissionEndpoint + "GetPermissions";
		if ("JSON".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = JsonSerialiser.serializeObjectToJson(request);
			serverResponse = call(payload, endpoint);
			localPermResponse = (GetPermissionsResponse) JsonSerialiser
					.deserializeJsonToObject(serverResponse,
							GetPermissionsResponse.class);
		} else if ("XML".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = XMLSerialiser.serializeObjectToXML(request,
					packageContext);
			serverResponse = call(payload, endpoint);
			localPermResponse = (GetPermissionsResponse) XMLSerialiser
					.deserializeXMLToObject(serverResponse,
							GetPermissionsResponse.class, packageContext);
		} else if ("SOAP11".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			try {
				PermissionsPortType permissionsPortType = null;
				permissionsPortType = setupSoapClient(endpoint);
				localPermResponse = permissionsPortType.getPermissions(request);
				log.debug("SOAP request and response :" + output.toString());
			} catch (PPFaultMessage ppf) {
				log.debug("SOAP request and response :" + output.toString());
				throw ppf;
			}
		}
		return localPermResponse;
	}

	public GetBasicPersonalDataResponse getBasicPersonalData(
			GetBasicPersonalDataRequest request) throws FatalException,
			PPFaultMessage {
		GetBasicPersonalDataResponse localPermResponse = null;
		String payload = "";
		String serverResponse = "";
		String endpoint = permissionEndpoint + "GetBasicPersonalData";
		if ("JSON".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = JsonSerialiser.serializeObjectToJson(request);
			serverResponse = call(payload, endpoint);
			localPermResponse = (GetBasicPersonalDataResponse) JsonSerialiser
					.deserializeJsonToObject(serverResponse,
							GetBasicPersonalDataResponse.class);
		} else if ("XML".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = XMLSerialiser.serializeObjectToXML(request,
					packageContext);
			serverResponse = call(payload, endpoint);
			localPermResponse = (GetBasicPersonalDataResponse) XMLSerialiser
					.deserializeXMLToObject(serverResponse,
							GetBasicPersonalDataResponse.class, packageContext);
		} else if ("SOAP11".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			try {
				PermissionsPortType permissionsPortType = null;
				permissionsPortType = setupSoapClient(endpoint);
				localPermResponse = permissionsPortType
						.getBasicPersonalData(request);
				log.debug("SOAP request and response :" + output.toString());
			} catch (PPFaultMessage ppf) {
				log.debug("SOAP request and response :" + output.toString());
				throw ppf;
			}
		}
		return localPermResponse;
	}

	public GetAdvancedPersonalDataResponse getAdvancedPersonalData(
			GetAdvancedPersonalDataRequest request) throws FatalException,
			PPFaultMessage {
		GetAdvancedPersonalDataResponse localPermResponse = null;
		String payload = "";
		String serverResponse = "";
		String endpoint = permissionEndpoint + "GetAdvancedPersonalData";
		if ("JSON".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = JsonSerialiser.serializeObjectToJson(request);
			serverResponse = call(payload, endpoint);
			localPermResponse = (GetAdvancedPersonalDataResponse) JsonSerialiser
					.deserializeJsonToObject(serverResponse,
							GetAdvancedPersonalDataResponse.class);
		} else if ("XML".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			payload = XMLSerialiser.serializeObjectToXML(request,
					packageContext);
			serverResponse = call(payload, endpoint);
			localPermResponse = (GetAdvancedPersonalDataResponse) XMLSerialiser
					.deserializeXMLToObject(serverResponse,
							GetAdvancedPersonalDataResponse.class,
							packageContext);
		} else if ("SOAP11".equalsIgnoreCase(getClientprops().getProperty(
				"X-PAYPAL-REQUEST-DATA-FORMAT"))) {
			try {
				PermissionsPortType permissionsPortType = null;
				permissionsPortType = setupSoapClient(endpoint);
				localPermResponse = permissionsPortType
						.getAdvancedPersonalData(request);
				log.debug("SOAP request and response :" + output.toString());
			} catch (PPFaultMessage ppf) {
				log.debug("SOAP request and response :" + output.toString());
				throw ppf;
			}
		}
		return localPermResponse;
	}

	private PermissionsPortType setupSoapClient(String paramString)
			throws FatalException {

		PermissionsPortType permissionsPortType = null;
		permissionsPortType = this.service.getPermissionsSOAP11PortHttp();
		BindingProvider localBindingProvider = (BindingProvider) permissionsPortType;
		if (CallerServices.isLogging())
			addLogHandler(localBindingProvider);
		CallerServices.setupHeaders(localBindingProvider);
		CallerServices.setupHttpProxyServer();
		CallerServices.setupEndPoint(localBindingProvider, paramString);
		return permissionsPortType;
	}
}
