# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
PayPalPlatformRubySDK::Application.config.secret_token = '91f8c9e96aaff572c534cdc2379a3b2c29d04b5de9f89f7eb35e443a658daae675db5f16f742dab937f907f2b481fd7d5a39174c97987a2d5c84940f4dab8139'
