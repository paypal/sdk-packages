class Websamples::IndexController < ApplicationController
  def index
  end
  
  def menu
  end

end
