module Websamples::Permission::GetaccesstokenHelper
end
