module Websamples::IndexHelper
end
