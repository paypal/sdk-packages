require 'test_helper'

class Websamples::Aa::CallsHelperTest < ActionView::TestCase
end
