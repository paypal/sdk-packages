require 'test_helper'

class Websamples::Aa::AddpaymentcarddirectHelperTest < ActionView::TestCase
end
