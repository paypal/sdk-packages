require 'test_helper'

class Websamples::Aa::GetverifiedstatusHelperTest < ActionView::TestCase
end
