require 'test_helper'

class Websamples::Aa::CreateaccountHelperTest < ActionView::TestCase
end
