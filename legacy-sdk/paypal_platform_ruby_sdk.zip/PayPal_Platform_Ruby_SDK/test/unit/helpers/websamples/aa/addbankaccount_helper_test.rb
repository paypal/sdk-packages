require 'test_helper'

class Websamples::Aa::AddbankaccountHelperTest < ActionView::TestCase
end
