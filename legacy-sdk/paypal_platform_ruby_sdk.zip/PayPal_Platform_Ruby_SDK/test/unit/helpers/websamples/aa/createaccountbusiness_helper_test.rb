require 'test_helper'

class Websamples::Aa::CreateaccountbusinessHelperTest < ActionView::TestCase
end
