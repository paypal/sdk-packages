require 'test_helper'

class Websamples::Aa::AddbankaccountdirectHelperTest < ActionView::TestCase
end
