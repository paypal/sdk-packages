require 'test_helper'

class Websamples::Aa::AddpaymentcardHelperTest < ActionView::TestCase
end
