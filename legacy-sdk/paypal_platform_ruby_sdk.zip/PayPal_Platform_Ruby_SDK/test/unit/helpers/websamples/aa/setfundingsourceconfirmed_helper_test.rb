require 'test_helper'

class Websamples::Aa::SetfundingsourceconfirmedHelperTest < ActionView::TestCase
end
