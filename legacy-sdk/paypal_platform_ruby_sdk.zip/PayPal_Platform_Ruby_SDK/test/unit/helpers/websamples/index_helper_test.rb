require 'test_helper'

class Websamples::IndexHelperTest < ActionView::TestCase
end
