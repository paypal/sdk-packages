require 'test_helper'

class Websamples::Ap::CreatepayHelperTest < ActionView::TestCase
end
