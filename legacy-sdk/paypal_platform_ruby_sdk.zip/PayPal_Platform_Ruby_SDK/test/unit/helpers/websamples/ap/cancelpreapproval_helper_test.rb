require 'test_helper'

class Websamples::Ap::CancelpreapprovalHelperTest < ActionView::TestCase
end
