require 'test_helper'

class Websamples::Ap::SetpaymentoptionHelperTest < ActionView::TestCase
end
