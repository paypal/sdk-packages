require 'test_helper'

class Websamples::Ap::ConvertcurrencyHelperTest < ActionView::TestCase
end
