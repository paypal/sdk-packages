require 'test_helper'

class Websamples::Ap::SetpayHelperTest < ActionView::TestCase
end
