require 'test_helper'

class Websamples::Ap::ExecutepayHelperTest < ActionView::TestCase
end
