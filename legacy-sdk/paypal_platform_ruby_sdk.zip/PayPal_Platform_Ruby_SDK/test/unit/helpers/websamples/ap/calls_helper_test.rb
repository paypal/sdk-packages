require 'test_helper'

class Websamples::Ap::CallsHelperTest < ActionView::TestCase
end
