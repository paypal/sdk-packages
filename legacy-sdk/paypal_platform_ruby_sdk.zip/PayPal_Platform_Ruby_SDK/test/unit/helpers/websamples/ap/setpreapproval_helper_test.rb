require 'test_helper'

class Websamples::Ap::SetpreapprovalHelperTest < ActionView::TestCase
end
