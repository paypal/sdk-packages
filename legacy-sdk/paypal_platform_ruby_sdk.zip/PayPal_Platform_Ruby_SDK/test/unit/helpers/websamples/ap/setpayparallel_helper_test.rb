require 'test_helper'

class Websamples::Ap::SetpayparallelHelperTest < ActionView::TestCase
end
