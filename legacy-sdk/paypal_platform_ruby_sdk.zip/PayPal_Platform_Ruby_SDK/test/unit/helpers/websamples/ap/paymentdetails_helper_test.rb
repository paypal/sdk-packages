require 'test_helper'

class Websamples::Ap::PaymentdetailsHelperTest < ActionView::TestCase
end
