require 'test_helper'

class Websamples::Ap::GetpaymentoptionHelperTest < ActionView::TestCase
end
