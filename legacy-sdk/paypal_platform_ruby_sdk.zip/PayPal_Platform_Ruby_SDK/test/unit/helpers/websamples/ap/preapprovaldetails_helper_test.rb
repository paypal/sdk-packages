require 'test_helper'

class Websamples::Ap::PreapprovaldetailsHelperTest < ActionView::TestCase
end
