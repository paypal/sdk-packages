require 'test_helper'

class Websamples::Ap::SetpaychainedHelperTest < ActionView::TestCase
end
