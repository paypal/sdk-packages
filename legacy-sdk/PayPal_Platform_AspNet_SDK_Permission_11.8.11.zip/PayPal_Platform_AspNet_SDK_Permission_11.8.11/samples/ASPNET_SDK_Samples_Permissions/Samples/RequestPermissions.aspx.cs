using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Configuration;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using PayPal.Platform.SDK;
using PayPal.Services.Private.Permissions;


namespace ASPNET_SDK_Samples.Samples
{
	/// <summary>
	/// Summary description for SetPay.
	/// </summary>

	public class PayCreate : System.Web.UI.Page
	{

       
		#region Private Members

        protected System.Web.UI.HtmlControls.HtmlInputText callback;
        protected System.Web.UI.HtmlControls.HtmlInputText scope;
        protected System.Web.UI.WebControls.CheckBoxList standardScope;
			
		#endregion
	
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			//this.Submit.ServerClick += new System.EventHandler(this.Submit_ServerClick);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region Events

		private void Page_Load(object sender, System.EventArgs e)
		{
            string url = Request.Url.Scheme + "://" + Request.Url.Host + ":" + Request.Url.Port;
            string returnURL = url + ResolveUrl("RequestPermissionsResponse.aspx");
            callback.Value = returnURL;
            

		}

		/// <summary>
		/// Handles onclick event of Submit button
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>




        protected void Submit_ServerClick1(object sender, EventArgs e)
        {
            RequestPermissionsRequest permissionsRequest = null;
            BaseAPIProfile profile2 = null;


            try
            {
                profile2 = (BaseAPIProfile)HttpContext.Current.Session[Constants.SessionConstants.PROFILE];
                permissionsRequest = new RequestPermissionsRequest();
                permissionsRequest.requestEnvelope = ClientInfoUtil.getMyAppRequestEnvelope();
                permissionsRequest.callback = callback.Value;
                permissionsRequest.scope = new string[17];
                
                int i = 0;
                foreach (ListItem lstItem in standardScope.Items)
                {
                   if (lstItem.Selected == true)
                   {
                      
                       permissionsRequest.scope[i] = lstItem.Value;
                       i++;
                   }
                }
              
                PayPal.Platform.SDK.Permissions per = new PayPal.Platform.SDK.Permissions();
                per.APIProfile = profile2;
                RequestPermissionsResponse PResponse = per.requestPermissions(permissionsRequest);

                if (per.isSuccess.ToUpper() == "FAILURE")
                {
                    HttpContext.Current.Session[Constants.SessionConstants.FAULT] = per.LastError;
                    HttpContext.Current.Response.Redirect("APIError.aspx", false);
                }
                else
                {



                    //HttpContext.Current.Session[Constants.SessionConstants.TOKENKEY] = PResponse.token;
                    HttpContext.Current.Session[Constants.SessionConstants.REQUESTPERMISSIONSRESPONSE] = PResponse;
                    HttpContext.Current.Response.Redirect(ConfigurationManager.AppSettings["PAYPAL_REDIRECT_URL"] + "_grant-permission&request_token=" + PResponse.token, false);
                    


                }
            }
            catch (FATALException FATALEx)
            {
                Session[Constants.SessionConstants.FATALEXCEPTION] = FATALEx;
                this.Response.Redirect(Constants.ASPXPages.APIERROR + "?" + Constants.QueryStringConstants.TYPE + "=FATAL", false);
            }
            catch (Exception ex)
            {
                FATALException FATALEx = new FATALException("Error occurred in PayCreate Page.", ex);
                Session[Constants.SessionConstants.FATALEXCEPTION] = FATALEx;
                this.Response.Redirect("APIError.aspx?type=FATAL", false);
            }

        }
        #endregion
    }
}
