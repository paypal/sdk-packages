using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ASPNET_SDK_Samples.Samples
{
    public partial class CancelPermissionsResponsePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region Public Properties

        /// <summary>
        /// PaymentDetailsResponse Session object
        /// </summary>
        public PayPal.Services.Private.Permissions.CancelPermissionsResponse getAccessTokenResponse
        {
            get
            {
                if (Session[Constants.SessionConstants.cancelPermissionsResponse] == null)
                    return null;

                return (PayPal.Services.Private.Permissions.CancelPermissionsResponse)Session[Constants.SessionConstants.cancelPermissionsResponse];
            }

        }

        #endregion
    }
}
