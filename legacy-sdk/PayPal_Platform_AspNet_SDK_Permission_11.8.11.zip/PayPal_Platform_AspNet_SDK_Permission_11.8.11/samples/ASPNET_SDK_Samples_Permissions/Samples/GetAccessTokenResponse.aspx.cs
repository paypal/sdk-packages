using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ASPNET_SDK_Samples.Samples
{
    public partial class GetAccessTokenResponsePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            dtlGetResponse.DataSource = getAccessTokenResponse.scope;            
            dtlGetResponse.DataBind();

        }

        #region Public Properties

        /// <summary>
        /// PaymentDetailsResponse Session object
        /// </summary>
        public PayPal.Services.Private.Permissions.GetAccessTokenResponse getAccessTokenResponse
        {
            get
            {
                if (Session[Constants.SessionConstants.GetAccessTokenResponse] == null)
                    return null;

                return (PayPal.Services.Private.Permissions.GetAccessTokenResponse)Session[Constants.SessionConstants.GetAccessTokenResponse];
            }

        }

        #endregion
    }
}
