using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using PayPal.Platform.SDK;
using PayPal.Services.Private.Permissions;

namespace ASPNET_SDK_Samples.Samples
{
    public partial class GetAccessToken : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Submit_ServerClick1(object sender, EventArgs e)
        {
            GetAccessTokenRequest getAccessTokenRequest = null;
            BaseAPIProfile profile2 = null;
            

            try
            {
                profile2 = (BaseAPIProfile)HttpContext.Current.Session[Constants.SessionConstants.PROFILE];
                getAccessTokenRequest = new GetAccessTokenRequest();
                getAccessTokenRequest.requestEnvelope = ClientInfoUtil.getMyAppRequestEnvelope();


                getAccessTokenRequest.token = token.Value;
                if(subjectAlias.Value.Length>1)
                    getAccessTokenRequest.subjectAlias = subjectAlias.Value;
                if(verifier.Value.Length>1)
                    getAccessTokenRequest.verifier = verifier.Value;

                PayPal.Platform.SDK.Permissions per = new PayPal.Platform.SDK.Permissions();
                per.APIProfile = profile2;
                GetAccessTokenResponse getAccessTokenResponse = per.getAccessToken(getAccessTokenRequest);

                if (per.isSuccess.ToUpper() == "FAILURE")
                {
                    HttpContext.Current.Session[Constants.SessionConstants.FAULT] = per.LastError;
                    HttpContext.Current.Response.Redirect("APIError.aspx", false);
                }
                else
                {

                    Session[Constants.SessionConstants.GetAccessTokenResponse] = getAccessTokenResponse;
                    this.Response.Redirect("GetAccessTokenResponse.aspx", false);


                }
            }
            catch (FATALException FATALEx)
            {
                Session[Constants.SessionConstants.FATALEXCEPTION] = FATALEx;
                this.Response.Redirect(Constants.ASPXPages.APIERROR + "?" + Constants.QueryStringConstants.TYPE + "=FATAL", false);
            }
            catch (Exception ex)
            {
                FATALException FATALEx = new FATALException("Error occurred in PayCreate Page.", ex);
                Session[Constants.SessionConstants.FATALEXCEPTION] = FATALEx;
                this.Response.Redirect("APIError.aspx?type=FATAL", false);
            }


        }
    }
}
