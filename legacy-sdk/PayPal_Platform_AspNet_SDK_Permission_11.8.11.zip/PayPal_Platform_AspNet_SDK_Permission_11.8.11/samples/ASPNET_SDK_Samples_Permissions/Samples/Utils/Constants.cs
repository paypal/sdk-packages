using System;

namespace ASPNET_SDK_Samples.Samples
{
	/// <summary>
	/// Summary description for Constants.
	/// </summary>
	public class Constants
	{
		public Constants()
		{
			//
			// TODO: Add constructor logic here
			//
		}
        
        /// <summary>
        /// Session Constants
        /// </summary>
		public class SessionConstants
		{
			
			public const string FAULT = "FAULT";
            public const string ERRORFAULT = "ERRORFAULT";
            public const string REQUESTPERMISSIONSRESPONSE = "REQUESTPERMISSIONSRESPONSE";
            public const string GETBASICPERSONALDATARESPONSE = "GETBASICPERSONALDATARESPONSE";
            public const string GETADVANCEDPERSONALDATARESPONSE = "GETADVACNEDPERSONALDATARESPONSE";
            public const string GetPermissionsResponse = "GetPermissionsResponse";
            public const string GetAccessTokenResponse = "GetAccessTokenResponse";
            public const string cancelPermissionsResponse = "cancelPermissionsResponse";
			public const string PROFILE = "PROFILE";
			public const string TOKENKEY = "TOKENKEY";
			public const string PREAPPROVALKEY = "PREAPPROVALKEY";
			public const string FATALEXCEPTION = "FATALEXCEPTION";
		
			
		}
        /// <summary>
        /// QueryString Constants
        /// </summary>
		public class QueryStringConstants
		{
			
			public const string TOKENKEY = "TOKENKEY";
			public const string TYPE = "type";
            public const string PREAPPROVALKEY = "preapprovalkey";
			

		}

        /// <summary>
        /// ASPXPages Constants
        /// </summary>
		public class ASPXPages
		{
			public const string APIERROR = "APIError.aspx";
			public const string PAYMENTDETAILS = "PaymentDetails.aspx";
            public const string PREAPPROVALDETAILS = "PreapprovalDetails.aspx";

		}

	}
}
