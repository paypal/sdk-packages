using System;

namespace PayPal.Platform.SDK
{
	/// <summary>
	/// Summary description for ProfileType.
	/// </summary>
	public enum ProfileType
	{
		ThreeToken ,
		Certificate
	}
}
