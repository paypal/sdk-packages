using System;
using System.Configuration;
using System.Collections;
//Added for PayPal
using PayPalPlatformNVPSDK;

namespace ASPNET_Platform_SDK_NVP_Samples.SamplesWeb.AdaptiveAccounts
{
    public partial class CreateAccount : System.Web.UI.Page
    {

        protected void Submit1_ServerClick(object sender, EventArgs e)
        {
            try
            {
                string endpoint = Constants_Common.endpoint_AA + "CreateAccount";
                NVPHelper NVPRequest = new NVPHelper();
                string accountType = AccountType.SelectedValue;

                //requestEnvelope.errorLanguage is common for all the request
                NVPRequest[SampleNVPConstant.requestEnvelopeerrorLanguage] = "en_US";
                NVPRequest[SampleNVPConstant.CreateAccount.accountType] = AccountType.SelectedValue;
                NVPRequest[SampleNVPConstant.CreateAccount.addresscity] = city.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.addresscountryCode] = countryCode.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.addressline1] = address1.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.addressline2] = address2.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.addresspostalCode] = postalCode.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.addressstate] = state.SelectedValue;
                NVPRequest[SampleNVPConstant.CreateAccount.citizenshipCountryCode] = citizenshipCountryCode.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.contactPhoneNumber] = contactPhoneNumber.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.currencyCode] = currencyCode.SelectedValue;
                NVPRequest[SampleNVPConstant.CreateAccount.dateOfBirth] = dateOfBirth.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.namefirstName] = firstName.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.namelastName] = lastName.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.namemiddleName] = middleName.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.namesalutation] = salutation.SelectedValue;
                NVPRequest[SampleNVPConstant.CreateAccount.notificationURL] = notificationUrl.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.partnerField1] = p1.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.partnerField2] = p2.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.partnerField3] = p3.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.partnerField4] = p4.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.partnerField5] = p5.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.preferredLanguageCode] = "en_US";
                string url = Request.Url.Scheme + "://" + Request.Url.Host + ":" + Request.Url.Port;
                string returnURL = url + ResolveUrl("../Public/WebflowReturnPage.aspx");

                NVPRequest[SampleNVPConstant.CreateAccount.createAccountWebOptionsreturnUrl] = returnURL;
                NVPRequest[SampleNVPConstant.CreateAccount.registrationType] = "WEB";
                NVPRequest[SampleNVPConstant.CreateAccount.sandboxEmailAddress] = sandboxDeveloperEmail.Text;
                NVPRequest[SampleNVPConstant.CreateAccount.emailAddress] = sandboxEmail.Text;

                //If account type is business adding business informations
                if (accountType == "BUSINESS")
                {
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfoaverageMonthlyVolume] = averageMonthlyVolume.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfoaveragePrice] = avgPrice.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfobusinessAddresscity] = businessCity.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfobusinessAddresscountryCode] = businessCountry.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfobusinessAddressline1] = businessAddress1.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfobusinessAddressline2] = businessAddress2.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfobusinessAddresspostalCode] = businessZip.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfobusinessAddressstate] = businessState.SelectedValue;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfobusinessName] = businessName.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfobusinessType] = businessType.SelectedValue;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfocustomerServiceEmail] = businessCustomerServiceEmail.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfocustomerServicePhone] = businessCustomerServicePhone.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfodateOfEstablishment] = dateOfEstablishment.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfopercentageRevenueFromOnline] = percentageRevenueFromOnline.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfosalesVenue] = salesVenue.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfocategory] = businessCategory.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfosubCategory] = businessSubCategory.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfowebSite] = businessWeb.Text;
                    NVPRequest[SampleNVPConstant.CreateAccount.businessInfoworkPhone] = businessPhone.Text;

                }

                string strrequestforNvp = NVPRequest.Encode();
                Hashtable hash = Constants_Common.headers();

                //Adding sandbox email address to the header hash table.
                hash.Add("X-PAYPAL-SANDBOX-EMAIL-ADDRESS", sandboxDeveloperEmail.Text);
                CallerServices_NVP CallerServices = new CallerServices_NVP();

                //calling Call method where actuall API call is made, NVP string, header value adne end point are passed as the input.
                string stresponsenvp = CallerServices.Call(strrequestforNvp, hash, endpoint);

                //Response is send to Decoder method where it is decoded to readable hash table
                NVPHelper decoder = new NVPHelper();
                decoder.Decode(stresponsenvp);

                //Response obtained after the API call is stored in print string to display all the response
                string print = Utils.BuildResponse(decoder, "CreateAccount", "");

                //Storing response string in session
                Session["AllResponse"] = print;
                string redirectURL = decoder["redirectURL"];

                if (decoder != null && decoder["responseEnvelope.ack"].Equals("Success"))
                {
                    Session["AACreateRedirect"] = decoder["redirectURL"];                
                }
                Response.Redirect("../Public/allResponse.aspx");                    
            }
            catch (FATALException fx)
            {
                NVPHelper decoder = new NVPHelper();
                decoder.Add("fx.FATALExceptionMessage", fx.FATALExceptionMessage);
                decoder.Add("fx.FATALExceptionLongMessage", fx.FATALExceptionLongMessage);
                string printerror = Utils.BuildResponse(decoder, "SDK Error Page", "");
                Session["AllResponse"] = printerror;
                Response.Redirect("../Public/allResponse.aspx");
            }
        }
    }
}
