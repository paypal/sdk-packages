using System;


namespace ASPNET_Platform_SDK_NVP_Samples.SamplesWeb.Public
{
    public partial class AllResponse : System.Web.UI.Page
    {      
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
