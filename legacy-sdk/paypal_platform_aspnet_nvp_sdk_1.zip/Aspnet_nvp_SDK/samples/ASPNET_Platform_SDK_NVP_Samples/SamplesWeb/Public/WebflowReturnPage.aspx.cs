using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace ASPNET_Platform_SDK_NVP_Samples.SamplesWeb.Public
{
    public partial class WebflowReturnPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public String QueryStringKey(int key)
        {
            if(Request.QueryString.Count>key)
                return this.Request.QueryString.GetKey(key);
            else
                return "";
        }
         public String QueryStringValue(int key)
        {
            if (Request.QueryString.Count > key)
                return this.Request.QueryString[key];
            else
                return "";
        }
    }
}
