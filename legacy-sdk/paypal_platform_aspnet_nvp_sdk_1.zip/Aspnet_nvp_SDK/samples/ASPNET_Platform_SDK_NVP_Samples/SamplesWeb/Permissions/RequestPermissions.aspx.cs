using System;
using System.Web.UI.WebControls;
using System.Configuration;
//Added for PayPal
using PayPalPlatformNVPSDK;


namespace ASPNET_Platform_SDK_NVP_Samples.SamplesWeb.Permissions
{
    public partial class RequestPermissions : System.Web.UI.Page
    {

        protected void Submit1_ServerClick(object sender, EventArgs e)
        {
            try
            {
                string endpoint = Constants_Common.endpoint_PE + "RequestPermissions";
                NVPHelper NVPRequest = new NVPHelper();
                //requestEnvelope.errorLanguage is common for all the request
                NVPRequest[SampleNVPConstant.requestEnvelopeerrorLanguage] = "en_US";

                NVPRequest[SampleNVPConstant.RequestPermissions.callback] = txtcallback.Text;

                int i = 0;
                int j = 0;
                foreach (ListItem lstItem in standardScope.Items)
                {
                    if (lstItem.Selected == true)
                    {
                        
                    NVPRequest[SampleNVPConstant.RequestPermissions.scope+"("+j.ToString()+")"]  = lstItem.Value;
                        j++;
                        i++;
                    }
                }

    

                string strrequestforNvp = NVPRequest.Encode();

                /*calling Call method where actuall A
                PI call is made, NVP string, header value adne end point are passed as the input.*/
                CallerServices_NVP CallerServices = new CallerServices_NVP();

                string stresponsenvp = CallerServices.Call(strrequestforNvp, Constants_Common.headers(), endpoint);

                //Response is send to Decoder method where it is decoded to readable hash table
                NVPHelper decoder = new NVPHelper();
                decoder.Decode(stresponsenvp);

                //Response obtained after the API call is stored in print string to display all the response
                string print = Utils.BuildResponse(decoder, "Request Permissions", "");
                //Storing response string in session
                Session["AllResponse"] = print;                
                //Session["RequestPermissionredirect"] = ConfigurationManager.AppSettings["PAYPAL_REDIRECT_URL"] + "_ap-payment&paykey=" + decoder["payKey"];
                Session["RequestPermissionredirect"] = ConfigurationManager.AppSettings["PAYPAL_REDIRECT_URL"] + "_grant-permission&request_token=" + decoder["token"];
                Response.Redirect("../Public/allResponse.aspx");
            }
            catch (FATALException fx)
            {
                NVPHelper decoder = new NVPHelper();
                decoder.Add("fx.FATALExceptionMessage", fx.FATALExceptionMessage);
                decoder.Add("fx.FATALExceptionLongMessage", fx.FATALExceptionLongMessage);
                string printerror = Utils.BuildResponse(decoder, "SDK Error Page", "");
                Session["AllResponse"] = printerror;
                Response.Redirect("../Public/allResponse.aspx");
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string url = Request.Url.Scheme + "://" + Request.Url.Host + ":" + Request.Url.Port;
            string returnURL = url + ResolveUrl("../Public/WebflowReturnPage.aspx");
            txtcallback.Text = returnURL;

        }
    }
}
