using System;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
namespace ASPNET_Platform_SDK_NVP_Samples.SamplesWeb
{
    public class Constants_Common
    {
        //Creating hash table for storing header values
        public static Hashtable headers()
        {
            Hashtable NVPHeaders = new Hashtable();
            NVPHeaders["X-PAYPAL-SECURITY-USERID"] = ConfigurationManager.AppSettings["API_USERNAME"];
            NVPHeaders["X-PAYPAL-SECURITY-PASSWORD"] = ConfigurationManager.AppSettings["API_PASSWORD"];
            NVPHeaders["X-PAYPAL-SECURITY-SIGNATURE"] = ConfigurationManager.AppSettings["API_SIGNATURE"];
            NVPHeaders["X-PAYPAL-APPLICATION-ID"] = ConfigurationManager.AppSettings["APPLICATION-ID"];
            NVPHeaders["X-PAYPAL-REQUEST-DATA-FORMAT"] = ConfigurationManager.AppSettings["API_REQUESTFORMAT"];
            NVPHeaders["X-PAYPAL-RESPONSE-DATA-FORMAT"] = ConfigurationManager.AppSettings["API_RESPONSEFORMAT"];
            NVPHeaders["X-PAYPAL-DEVICE-IPADDRESS"] = ConfigurationManager.AppSettings["API_DEVICE_IP"];
            return NVPHeaders;
        }
        //Setting endpoint for adaptive payment and adaptive account.
        public static string endpoint = ConfigurationManager.AppSettings["EndpointAP"];
        public static string endpoint_AA = ConfigurationManager.AppSettings["EndpointAA"];
        public static string endpoint_PE = ConfigurationManager.AppSettings["EndpointPE"];

    }
}
