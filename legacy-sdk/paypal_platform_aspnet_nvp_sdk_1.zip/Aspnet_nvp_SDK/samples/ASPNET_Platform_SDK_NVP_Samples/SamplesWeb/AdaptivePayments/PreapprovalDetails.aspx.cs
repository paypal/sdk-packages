using System;
//Added for PayPal
using PayPalPlatformNVPSDK;

namespace ASPNET_Platform_SDK_NVP_Samples.SamplesWeb.AdaptivePayments
{
    public partial class PreapprovalDetail : System.Web.UI.Page
    {

        protected void Submit1_ServerClick(object sender, EventArgs e)
        {
            try
            {
                string endpoint = Constants_Common.endpoint + "PreapprovalDetails";
                NVPHelper NVPRequest = new NVPHelper();
                //requestEnvelope.errorLanguage is common for all the request
                NVPRequest[SampleNVPConstant.requestEnvelopeerrorLanguage] = "en_US";

                NVPRequest[SampleNVPConstant.PreapprovalDetail.preapprovalKey] = txtPayKey.Text;

                string strrequestforNvp = NVPRequest.Encode();
                CallerServices_NVP CallerServices = new CallerServices_NVP();

                //calling Call method where actuall API call is made, NVP string, header value adne end point are passed as the input.
                string stresponsenvp = CallerServices.Call(strrequestforNvp, Constants_Common.headers(), endpoint);

                //Response is send to Decoder method where it is decoded to readable hash table
                NVPHelper decoder = new NVPHelper();
                decoder.Decode(stresponsenvp);

                //Response obtained after the API call is stored in print string to display all the response
                string print = Utils.BuildResponse(decoder, "Pre Approval Detail", "");

                //Storing response string in session
                Session["AllResponse"] = print;
                Response.Redirect("../Public/allResponse.aspx");
            }
            catch (FATALException fx)
            {
                NVPHelper decoder = new NVPHelper();
                decoder.Add("fx.FATALExceptionMessage", fx.FATALExceptionMessage);
                decoder.Add("fx.FATALExceptionLongMessage", fx.FATALExceptionLongMessage);
                string printerror = Utils.BuildResponse(decoder, "SDK Error Page", "");
                Session["AllResponse"] = printerror;
                Response.Redirect("../Public/allResponse.aspx");
            }
        }
    }
}
