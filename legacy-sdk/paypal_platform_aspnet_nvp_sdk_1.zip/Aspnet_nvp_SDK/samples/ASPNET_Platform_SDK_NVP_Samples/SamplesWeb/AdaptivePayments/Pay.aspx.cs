using System;
using System.Configuration;
//Added for PayPal
using PayPalPlatformNVPSDK;


namespace ASPNET_Platform_SDK_NVP_Samples.SamplesWeb.AdaptivePayments
{
    public partial class Pay : System.Web.UI.Page
    {

        protected void Submit1_ServerClick(object sender, EventArgs e)
        {
            try
            {
                string endpoint = Constants_Common.endpoint + "Pay";
                NVPHelper NVPRequest = new NVPHelper();
                //requestEnvelope.errorLanguage is common for all the request
                NVPRequest[SampleNVPConstant.requestEnvelopeerrorLanguage] = "en_US";

                NVPRequest[SampleNVPConstant.Pay.actionType] = ddlActiontype.SelectedValue;
                NVPRequest[SampleNVPConstant.Pay.currencyCode] = ddlCurrency.SelectedValue;
                NVPRequest[SampleNVPConstant.Pay.feesPayer] = ddlFeepayer.SelectedValue;
                NVPRequest[SampleNVPConstant.Pay.memo] = txtMemo.Text;
                NVPRequest[SampleNVPConstant.Pay.receiverListreceiveramount_0] = txtamount_0.Text;
                NVPRequest[SampleNVPConstant.Pay.receiverListreceiveremail_0] = txtReceiveremail_0.Text;
                NVPRequest[SampleNVPConstant.Pay.receiverListreceiverprimary_0] = ddlPrimary_0.SelectedValue;
                NVPRequest[SampleNVPConstant.Pay.receiverListreceiveramount_1] = txtamount_1.Text;
                NVPRequest[SampleNVPConstant.Pay.receiverListreceiveremail_1] = txtReceiveremail_1.Text;
                NVPRequest[SampleNVPConstant.Pay.receiverListreceiverprimary] = ddlPrimary_1.SelectedValue;
                NVPRequest[SampleNVPConstant.Pay.senderEmail] = txtSendermail.Text;
                

                string url = Request.Url.Scheme + "://" + Request.Url.Host + ":" + Request.Url.Port;
                string returnURL = url + ResolveUrl("../Public/WebflowReturnPage.aspx");
                string cancelURL = url + ResolveUrl("../Public/Calls.aspx");

                NVPRequest[SampleNVPConstant.Pay.cancelUrl] = cancelURL;
                NVPRequest[SampleNVPConstant.Pay.returnUrl] = returnURL;


                if (txtPreapprovalkey.Text.Trim() != "")
                {
                    NVPRequest[SampleNVPConstant.Pay.preapprovalKey] = txtPreapprovalkey.Text;
                }
                string strrequestforNvp = NVPRequest.Encode();
                //calling Call method where actuall API call is made, NVP string, header value adne end point are passed as the input.
                CallerServices_NVP CallerServices = new CallerServices_NVP();
                string stresponsenvp = CallerServices.Call(strrequestforNvp, Constants_Common.headers(), endpoint);

                //Response is send to Decoder method where it is decoded to readable hash table
                NVPHelper decoder = new NVPHelper();
                decoder.Decode(stresponsenvp);

                //Response obtained after the API call is stored in print string to display all the response
                string print = Utils.BuildResponse(decoder, "Pay", "");
                //Storing response string in session
                Session["AllResponse"] = print; //
                //COMPLETED, CREATED, Success

                if (decoder != null && decoder["responseEnvelope.ack"].Equals("Success") && ddlActiontype.SelectedValue == "PAY" && decoder["paymentExecStatus"].Equals("CREATED"))
                {
                    Session["PayRedirect"] = ConfigurationManager.AppSettings["PAYPAL_REDIRECT_URL"] + "_ap-payment&paykey=" + decoder["payKey"];
                }
                else if (decoder != null && decoder["responseEnvelope.ack"].Equals("Success") && (txtPreapprovalkey.Text != "") && ddlActiontype.SelectedValue == "CREATE" && decoder["paymentExecStatus"].Equals("CREATED"))
                {
                    Session["PayRedirect"] = ConfigurationManager.AppSettings["PAYPAL_REDIRECT_URL"] + "_ap-payment&paykey=" + decoder["payKey"];
                    Session["setPayKey"] = decoder["payKey"];
                    Session["executePayKey"] = decoder["payKey"];
                }
                else if (decoder != null && decoder["responseEnvelope.ack"].Equals("Success") && ddlActiontype.SelectedValue == "CREATE" && decoder["paymentExecStatus"].Equals("CREATED"))
                {
                    string senderApiEmail = ConfigurationManager.AppSettings["API_USERNAME"];
                    string senderEmail = txtSendermail.Text;
                    string senderTruncatedEmail = senderEmail.Substring(0, senderEmail.IndexOf("@"));
                    string senderApiTruncatedEmail = senderApiEmail.Substring(0, senderApiEmail.IndexOf("_api"));
                    if (senderTruncatedEmail == senderApiTruncatedEmail)
                    {
                        Session["PayRedirect"] = ConfigurationManager.AppSettings["PAYPAL_REDIRECT_URL"] + "_ap-payment&paykey=" + decoder["payKey"];
                        Session["setPayKey"] = decoder["payKey"];
                        Session["executePayKey"] = decoder["payKey"];
                    }
                    else
                    {
                        Session["PayRedirect"] = ConfigurationManager.AppSettings["PAYPAL_REDIRECT_URL"] + "_ap-payment&paykey=" + decoder["payKey"];
                    }
                }
                Response.Redirect("../Public/allResponse.aspx");   
            }
            catch (FATALException fx)
            {
                NVPHelper decoder = new NVPHelper();
                decoder.Add("fx.FATALExceptionMessage", fx.FATALExceptionMessage);
                decoder.Add("fx.FATALExceptionLongMessage", fx.FATALExceptionLongMessage);
                string printerror = Utils.BuildResponse(decoder, "SDK Error Page", "");
                Session["AllResponse"] = printerror;
                Response.Redirect("../Public/allResponse.aspx");
            }
        }
    }
}
