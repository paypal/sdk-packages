using System;
//Added for PayPal
using PayPalPlatformNVPSDK;

namespace ASPNET_Platform_SDK_NVP_Samples.SamplesWeb.AdaptivePayments
{
    public partial class SetPaymentOptions : System.Web.UI.Page
    {
        private void Page_Load(object sender, System.EventArgs e)
        {
            if (Request.QueryString["Paykey"] != null)
            this.txtPaykey.Text = Request.QueryString["Paykey"];
        } 
        protected void Submit1_ServerClick(object sender, EventArgs e)
        {
            try
            {
                string endpoint = Constants_Common.endpoint + "SetPaymentOptions";
                NVPHelper NVPRequest = new NVPHelper();
                //requestEnvelope.errorLanguage is common for all the request
                NVPRequest[SampleNVPConstant.requestEnvelopeerrorLanguage] = "en_US";

                NVPRequest[SampleNVPConstant.SetPaymentOption.payKey] = txtPaykey.Text;
                
                if (txtEmailHeaderimage.Text != "")
                    NVPRequest[SampleNVPConstant.SetPaymentOption.displayOptionsemailHeaderImageUrl] = txtEmailHeaderimage.Text;
                if (txtEmailMarkettingImage.Text != "")
                    NVPRequest[SampleNVPConstant.SetPaymentOption.displayOptionsemailMarketingImageUrl] = txtEmailMarkettingImage.Text;
                if(txtCountryCode.Text != "")
                    NVPRequest[SampleNVPConstant.SetPaymentOption.initiatingEntityinstitutionCustomercountryCode] = txtCountryCode.Text;

                if (txtName.Text != "")
                    NVPRequest[SampleNVPConstant.SetPaymentOption.initiatingEntityinstitutionCustomerdisplayName] = txtName.Text;

                if (txtEmail.Text != "")
                    NVPRequest[SampleNVPConstant.SetPaymentOption.initiatingEntityinstitutionCustomeremail] = txtEmail.Text;

                if (txtFirstName.Text != "")
                    NVPRequest[SampleNVPConstant.SetPaymentOption.initiatingEntityinstitutionCustomerfirstName] = txtFirstName.Text;

                if (txtLastName.Text != "")
                    NVPRequest[SampleNVPConstant.SetPaymentOption.initiatingEntityinstitutionCustomerlastName] = txtLastName.Text;

                if (txtCustomerId.Text != "")
                    NVPRequest[SampleNVPConstant.SetPaymentOption.initiatingEntityinstitutionCustomerinstitutionCustomerId] = txtCustomerId.Text;

                if (txtInstitutionId.Text != "")
                    NVPRequest[SampleNVPConstant.SetPaymentOption.initiatingEntityinstitutionCustomerinstitutionId] = txtInstitutionId.Text;


                string strrequestforNvp = NVPRequest.Encode();
                CallerServices_NVP CallerServices = new CallerServices_NVP();
                //calling Call method where actuall API call is made, NVP string, header value adne end point are passed as the input.
                string stresponsenvp = CallerServices.Call(strrequestforNvp, Constants_Common.headers(), endpoint);

                //Response is send to Decoder method where it is decoded to readable hash table
                NVPHelper decoder = new NVPHelper();
                decoder.Decode(stresponsenvp);

                //Response obtained after the API call is stored in print string to display all the response
                string print = Utils.BuildResponse(decoder, "Set PaymentOptions", "");

                //Storing response string in session
                Session["AllResponse"] = print;
                if (decoder != null && decoder["responseEnvelope.ack"].Equals("Success"))
                    Session["SetpaymentPayKey"] = txtPaykey.Text;
                Response.Redirect("../Public/allResponse.aspx");
            }
            catch (FATALException fx)
            {
                NVPHelper decoder = new NVPHelper();
                decoder.Add("fx.FATALExceptionMessage", fx.FATALExceptionMessage);
                decoder.Add("fx.FATALExceptionLongMessage", fx.FATALExceptionLongMessage);
                string printerror = Utils.BuildResponse(decoder, "SDK Error Page", "");
                Session["AllResponse"] = printerror;
                Response.Redirect("../Public/allResponse.aspx");
            }
        }
    }
}
