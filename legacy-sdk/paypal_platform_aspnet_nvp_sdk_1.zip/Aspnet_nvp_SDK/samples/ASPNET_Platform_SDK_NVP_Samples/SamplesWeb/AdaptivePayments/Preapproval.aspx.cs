using System;
using System.Configuration;
//Added for PayPal
using PayPalPlatformNVPSDK;

namespace ASPNET_Platform_SDK_NVP_Samples.SamplesWeb.AdaptivePayments
{
    public partial class Preapproval : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtStartedate.Text = DateTime.Now.ToString("yyyy-MM-dd");
                txtEnddate.Text = DateTime.Now.AddMonths(1).ToString("yyyy-MM-dd");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string endpoint = Constants_Common.endpoint + "Preapproval";
            NVPHelper NVPRequest = new NVPHelper();
            //requestEnvelope.errorLanguage is common for all the request
            NVPRequest[SampleNVPConstant.requestEnvelopeerrorLanguage] = "en_US";

            NVPRequest[SampleNVPConstant.Preapproval.currencyCode] = ddlCurrency.SelectedValue;
            NVPRequest[SampleNVPConstant.Preapproval.startingDate] = txtStartedate.Text;
            NVPRequest[SampleNVPConstant.Preapproval.endingDate] = txtEnddate.Text;
            NVPRequest[SampleNVPConstant.Preapproval.maxNumberOfPayments] = txtMaxnoofPayments.Text;
            NVPRequest[SampleNVPConstant.Preapproval.maxTotalAmountOfAllPayments] = txtMaxtotalAmount.Text;
            NVPRequest[SampleNVPConstant.Preapproval.requestEnvelopesenderEmail] = txtSenderemail.Text;

            string url = Request.Url.Scheme + "://" + Request.Url.Host + ":" + Request.Url.Port;
            string returnURL = url + ResolveUrl("../Public/WebflowReturnPage.aspx");
            string cancelURL = url + ResolveUrl("../Public/Calls.aspx");

            NVPRequest[SampleNVPConstant.Preapproval.cancelUrl] = cancelURL;
            NVPRequest[SampleNVPConstant.Preapproval.returnUrl] = returnURL;

            string strrequestforNvp = NVPRequest.Encode();
            CallerServices_NVP CallerServices = new CallerServices_NVP();
            string stresponsenvp = CallerServices.Call(strrequestforNvp, Constants_Common.headers(), endpoint);

            NVPHelper decoder = new NVPHelper();
            decoder.Decode(stresponsenvp);

            string print = Utils.BuildResponse(decoder, "Preapproval", "");
            Session["AllResponse"] = print;
            Session["PayRedirect"] = ConfigurationManager.AppSettings["PAYPAL_REDIRECT_URL"] + "_ap-preapproval&preapprovalkey=" + decoder["preapprovalkey"];
            Response.Redirect("../Public/allResponse.aspx");
        }
    }
}
