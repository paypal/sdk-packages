using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using PayPal.Platform.SDK;
using PayPal.Services.Private.Permissions;
namespace ASPNET_SDK_Samples.Samples
{
    public partial class GetPermissionsResponsePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            dtlGetResponse.DataSource = getPermissionsResponse.scope;
            dtlGetResponse.DataBind();
        }
        #region Public Properties

        /// <summary>
        /// PaymentDetailsResponse Session object
        /// </summary>
        public PayPal.Services.Private.Permissions.GetPermissionsResponse getPermissionsResponse
        {
            get
            {
                if (Session[Constants.SessionConstants.GetPermissionsResponse] == null)
                    return null;

                return (PayPal.Services.Private.Permissions.GetPermissionsResponse)Session[Constants.SessionConstants.GetPermissionsResponse];
            }

        }

        #endregion
    }
}
