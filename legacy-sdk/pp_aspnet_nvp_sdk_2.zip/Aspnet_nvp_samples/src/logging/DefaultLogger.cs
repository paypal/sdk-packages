using log4net;

namespace com.paypal.sdk.logging
{
	/// <summary>
	/// Summary description for DefaultLogger.
	/// </summary>
	public class DefaultLogger
	{
		/// <summary>
		/// Central logger used in several places in the SDK.
		/// </summary>
		public static readonly ILog LOG = LogManager.GetLogger("com.paypal.sdk.logging.DefaultLogger");
	}
}
