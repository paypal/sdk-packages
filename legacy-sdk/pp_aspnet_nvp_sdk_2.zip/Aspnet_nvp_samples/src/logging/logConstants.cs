
namespace com.paypal.sdk.logging
{
	/// <summary>
	/// Defines PayPal-specific log levels, and maps them to corresponding log4net levels.
	/// </summary>
	public enum LogConstants {
			/// <summary>
			/// Represents a log level of 'NONE', ie. only major errors
			/// </summary>
			LOG_NONE,
			/// <summary>
			/// Represents a log level of 'TRANSACTION', ie. web service call details
			/// </summary>
			LOG_TRANSACTION,
			/// <summary>
			/// Represents a log level of 'DEBUG', ie. all debug statements
			/// </summary>
			LOG_DEBUG

		} // LogConstants
} // logging namespace