namespace com.paypal.sdk.util
{
	/// <summary>
	/// Summary description for Resource.
	/// </summary>
	public class Constants
	{
		/// <summary>
		/// Defines the Resource root name for resources, which is defined to be the namespace they are embedded in.
		/// </summary>
		public static readonly string RESOURCE_ROOT = "com.paypal.sdk";

		public static readonly string  X_PP_AUTHORIZATION ="X-PP-AUTHORIZATION";
	}
}
