namespace com.paypal.sdk.core
{
	/// <summary>
	/// Default config values
	/// </summary>
	public class ConfigDefaults
	{
		/// <summary>
		/// 
		/// </summary>
		public const int MAXIMUM_RETRIES = 0;

		/// <summary>
		/// 
		/// </summary>
		public const string WSDL_VERSION = "92.0";

		/// <summary>
		/// 
		/// </summary>
		public const int DELAY_TIME = 2000;

		/// <summary>
		///  The connection timeout in milliseconds
		/// </summary>
		public const int CONNECTION_TIMEOUT_MS = 360000;
	}
}
