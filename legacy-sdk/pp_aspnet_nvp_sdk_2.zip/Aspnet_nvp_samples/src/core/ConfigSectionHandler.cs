using System.Configuration;
using System.Xml;

namespace com.paypal.sdk.core
{
	/// <summary>
	/// Used to load custom paypal config section in web.config/console.exe.config
	/// </summary>
	public class ConfigSectionHandler : IConfigurationSectionHandler
	{
		#region IConfigurationSectionHandler Members

		/// <summary>
		/// Gets the paypal config setting.
		/// </summary>
		/// <param name="parent"></param>
		/// <param name="configContext"></param>
		/// <param name="section"></param>
		/// <returns>simple returns the section argument</returns>
		public object Create(object parent, object configContext, XmlNode section)
		{
			return section;
		}

		#endregion
	}
}
