using System;

namespace com.paypal.sdk.core
{
	/// <summary>
	/// Summary description for Endpoint.
	/// </summary>
	public class Endpoint
	{
		private readonly string environment;
		private readonly string port;
		private readonly bool isThreeToken;
		private readonly string url;

		/// <summary>
		/// 
		/// </summary>
		public string Environment
		{
			get { return environment; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string Port
		{
			get { return port; }
		}

		/// <summary>
		/// 
		/// </summary>
		public bool IsThreeToken
		{
			get { return isThreeToken; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string Url
		{
			get { return url; }
		}

		/// <summary>
		/// 
		/// </summary>
		public string WebHost
		{
			get
			{
				return "www" + new Uri(this.url).Host.Substring("api".Length);
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="environment"></param>
		/// <param name="port"></param>
		/// <param name="isThreeToken"></param>
		/// <param name="url"></param>
		public Endpoint(string environment, string port, bool isThreeToken, string url)
		{
			this.environment = environment;
			this.port = port;
			this.isThreeToken = isThreeToken;
			this.url = url;
		}

	}
}
