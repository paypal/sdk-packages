/*
 * Copyright 2005 PayPal, Inc. All Rights Reserved.
 */

using System;
using com.paypal.sdk.exceptions;
using com.paypal.sdk.util;

namespace com.paypal.sdk.profiles
{
	/// <summary>
	/// PermissionAPIProfile implementation BaseAPIProfile and IAPIProfile
	/// </summary>
	[Serializable]
	public class PermissionAPIProfile : BaseAPIProfile,IAPIProfile 
	{
		/// <summary>
		/// The API signature used in three-token authentication
		/// </summary>
		[NonSerialized] private string oauth_Signature;
		[NonSerialized] private string oauth_Token;
		[NonSerialized] private string oauth_Timestamp;

		/// <summary>
		/// The certificate used to access the PayPal API
		/// </summary>
		private string certificateFile = string.Empty;

		/// <summary>
		/// The privateKeyPassword used
		/// </summary>
		private string privateKeyPassword = "";

		/// <summary>
		/// The file-name of the certificate to be used.
		/// Not implemented yet.
		/// </summary>
		public override string CertificateFile
		{
			get
			{
				return this.certificateFile;
			}
			set
			{
				this.certificateFile = value;
			}
		}

		/// <summary>
		/// API Signature used to access the PayPal API.  Only used for
		/// profiles set to Three-Token Authentication instead of Client-Side SSL Certificates.
		/// </summary>
		public override string APISignature
		{
			get
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
			set
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
		}
		public override string getFirstPartyEmail
		{
			get
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
			set
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
		}
		/// <summary>
		/// The private key password
		/// </summary>
		public override string PrivateKeyPassword
		{
			get
			{
				return this.privateKeyPassword;
			}
			set
			{
				this.privateKeyPassword = value;
			}
		}


		/// <summary>
		/// Oauth_Signature implemented
		/// </summary>
		public override string Oauth_Signature
		{
			get
			{
				return this.oauth_Signature;
			}
			set
			{
				this.oauth_Signature = value;
			}
		}

		/// <summary>
		/// Oauth_Token implemented
		/// </summary>
		public override string Oauth_Token
		{
			get
			{
				return this.oauth_Token;
			}
			set
			{
				this.oauth_Token = value;
			}
		}

		/// <summary>
		/// Oauth_Timestamp implemented
		/// </summary>
		public override string Oauth_Timestamp
		{
			get
			{
				return this.oauth_Timestamp;
			}
			set
			{
				this.oauth_Timestamp = value;
			}
		}





	} // PermissionAPIProfile
} // profiles namespace