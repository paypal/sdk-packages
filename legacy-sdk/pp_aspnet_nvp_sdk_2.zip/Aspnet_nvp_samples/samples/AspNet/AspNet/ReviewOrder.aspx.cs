using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.core;
using com.paypal.sdk.util;
namespace ASPDotNetSamples.AspNet
{
	/// <summary>
	/// Summary description for DoExpressCheckoutPayment.
	/// </summary>
	public class ReviewOrder : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{

			
			string url=Request.Url.Scheme+ "://"+Request.Url.Host+":"+ Request.Url.Port+"/"; 		
			string cancelURL = url + ResolveUrl("SetExpressCheckout.aspx")+"?=paymentType=" + Request.QueryString["paymentType"] ;

			com.paypal.sdk.services.NVPCallerServices caller =PayPalAPI.PayPalAPIInitialize();
			NVPCodec encoder= new NVPCodec();
			encoder["METHOD"] =  "SetExpressCheckout";			
			encoder["CANCELURL"] =  cancelURL;	
			encoder["PAYMENTACTION"] =  Request.QueryString["paymentType"];
			encoder["CURRENCYCODE"] =  Request.QueryString["currency"];
			encoder["CURRENCYCODE"] = Request.QueryString["currency"];
			//encoder["NAME"] = Request.QueryString["NAME"];
			encoder["SHIPTONAME"] = Request.QueryString["NAME"];
			encoder["SHIPTOSTREET"] = Request.QueryString["SHIPTOSTREET"];
			encoder["SHIPTOCITY"] = Request.QueryString["SHIPTOCITY"];
			encoder["SHIPTOSTATE"]= Request.QueryString["SHIPTOSTATE"];
			encoder["SHIPTOCOUNTRYCODE"]= Request.QueryString["SHIPTOCOUNTRYCODE"];
			encoder["SHIPTOZIP"] = Request.QueryString["SHIPTOZIP"];

			encoder["ADDROVERRIDE"]="1";


			encoder["L_NAME0"] = Request.QueryString["L_NAME0"];
			encoder["L_NUMBER0"] = "1000";
			encoder["L_DESC0"] = "Size: 8.8-oz";
			encoder["L_AMT0"] = Request.QueryString["L_AMT0"];
			encoder["L_QTY0"] = Request.QueryString["L_QTY0"];
			encoder["L_NAME1"] = Request.QueryString["L_NAME1"];
			encoder["L_NUMBER1"] = "10001";
			encoder["L_DESC1"] =  "Size: Two 24-piece boxes";
			encoder["L_AMT1"] =  Request.QueryString["L_AMT1"];
			encoder["L_QTY1"] =  Request.QueryString["L_QTY1"];
			encoder["L_ITEMWEIGHTVALUE1"] = "0.5";
			encoder["L_ITEMWEIGHTUNIT1"] = "lbs";
			// add up all line amount, L_AMTns 
			double ft = double.Parse(Request.QueryString["L_QTY0"]) * double.Parse(Request.QueryString["L_AMT0"]) + double.Parse(Request.QueryString["L_QTY1"]) * double.Parse(Request.QueryString["L_AMT1"]);
			encoder["ITEMAMT"] = ft.ToString();
			encoder["TAXAMT"] = "2.00";
			//amount = itemamount+ shippingamt+shippingdisc+taxamt+insuranceamount;
			double amt = System.Math.Round( ft + 5.00f + 2.00f + 1.00f, 2);
			// string amtstr = String.Format("Float
			double maxamt = System.Math.Round(amt + 25.00f, 2);
			encoder["SHIPDISCAMT"] = "-3.00";
			encoder["AMT"] = amt.ToString();
			string returnURL = url + ResolveUrl("GetExpressCheckoutDetails.aspx")+ "?currency=" + Request.QueryString["currency"] + "&paymentType="+ Request.QueryString["paymentType"]+"&amount="+amt.ToString();
			encoder["RETURNURL"] =  returnURL;
			encoder["SHIPPINGAMT"] = "8.00";
			encoder["MAXAMT"] = maxamt.ToString();
			encoder["CALLBACK"] = "https://www.ppcallback.com/callback.pl";
			encoder["INSURANCEOPTIONOFFERED"] = "true";
			encoder["INSURANCEAMT"] =  "1.00";

			encoder["L_SHIPPINGOPTIONISDEFAULT0"] = "false";
			encoder["L_SHIPPINGOPTIONNAME0"] = "Ground";
			encoder["L_SHIPPINGOPTIONLABEL0"] = "UPS Ground 7 Days";
			encoder["L_SHIPPINGOPTIONAMOUNT0"] = "3.00";
			encoder["L_SHIPPINGOPTIONISDEFAULT1"] = "true";
			encoder["L_SHIPPINGOPTIONNAME1"] = "UPS Air";
			encoder["L_SHIPPINGOPTIONlABEL1"] = "UPS Next Day Air";
			encoder["L_SHIPPINGOPTIONAMOUNT1"] = "8.00";
			
			encoder["CALLBACKTIMEOUT"] =  "4";
			string pStrrequestforNvp= encoder.Encode();
			string pStresponsenvp=caller.Call(pStrrequestforNvp);

			NVPCodec decoder = new NVPCodec();
			decoder.Decode(pStresponsenvp);

			string strAck = decoder["ACK"]; 
			if(strAck !=null && (strAck=="Success" || strAck=="SuccessWithWarning"))
			{	
				Session["TOKEN"]= decoder["TOKEN"];
				string host = "www." + Session["stage"].ToString() + ".paypal.com";
				string ECURL="https://" + host + "/cgi-bin/webscr?cmd=_express-checkout" + "&token="+ decoder["TOKEN"];
				Response.Redirect(ECURL);
				
			}
			else
			{
				Session["errorresult"]=decoder;
				string pStrResQue=	"API="+ "Error Detail "; 
				Response.Redirect("APIError.aspx?"+pStrResQue);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
