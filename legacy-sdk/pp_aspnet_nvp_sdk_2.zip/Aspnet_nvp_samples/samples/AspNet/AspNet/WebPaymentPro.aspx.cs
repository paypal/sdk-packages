using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ASPDotNetSamples;
namespace ASPDotNetSamples.AspNet
{
	/// <summary>
	/// Summary description for Index.
	/// </summary>
	public class Default : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlInputText Password3;
		protected System.Web.UI.HtmlControls.HtmlInputButton custom;
		protected System.Web.UI.HtmlControls.HtmlInputText apiUsername;
		protected System.Web.UI.HtmlControls.HtmlInputText apiPassword;
		protected System.Web.UI.HtmlControls.HtmlInputText signature;
		protected System.Web.UI.HtmlControls.HtmlInputText subject;
		protected System.Web.UI.HtmlControls.HtmlInputButton DefaultButton;
		protected System.Web.UI.HtmlControls.HtmlInputRadioButton Radio1;
		protected System.Web.UI.HtmlControls.HtmlInputRadioButton Radio2;
		protected System.Web.UI.HtmlControls.HtmlInputText File1;
		protected System.Web.UI.HtmlControls.HtmlInputRadioButton Radio3;
		protected System.Web.UI.WebControls.TextBox OAUTH_SIGNATURE;
		protected System.Web.UI.WebControls.TextBox OAUTH_TOKEN;
		protected System.Web.UI.WebControls.TextBox OAUTH_TIMESTAMP;
		protected System.Web.UI.HtmlControls.HtmlInputRadioButton Radio4;
		
		protected System.Web.UI.HtmlControls.HtmlInputText stagename;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DefaultButton.ServerClick += new System.EventHandler(this.UseDefaultAccountButton_ServerClick);
			this.custom.ServerClick += new System.EventHandler(this.custom_ServerClick);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void UseDefaultAccountButton_ServerClick(object sender, System.EventArgs e)
		{
			Global.is3token=true;
			Session["stage"]=Constants.ENVIRONMENT;
			SetProfile.SessionProfile = SetProfile.CreateAPIProfile(Constants.API_USERNAME,  Constants.API_PASSWORD, Constants.API_SIGNATURE,"","",Constants.ENVIRONMENT,Constants.SUBJECT,Constants.OAUTH_SIGNATURE,Constants.OAUTH_TOKEN,Constants.OAUTH_TIMESTAMP);
			this.RedirectToMainPage();
		}

		private void custom_ServerClick(object sender, System.EventArgs e)
		{
			if (Radio1.Checked==true)
			{
				Global.is3token=false;
				Global.isunipay=false;
				Global.ispermission=false;
			}
			else if(Radio3.Checked==true)
			{
				Global.is3token=false;
				Global.isunipay=true;
				Global.ispermission=false;
			}
			else if(Radio4.Checked==true)
			{
				Global.is3token=false;
				Global.isunipay=false;
				Global.ispermission=true;
			}
			else
			{
				Global.isunipay=false;
				Global.is3token=true;
				Global.ispermission=false;
			}
                        Session["stage"]=this.stagename.Value;
			SetProfile.SessionProfile = SetProfile.CreateAPIProfile(this.apiUsername.Value,  this.apiPassword.Value, this.signature.Value,this.File1.Value,this.Password3.Value,this.stagename.Value,this.subject.Value,this.OAUTH_SIGNATURE.Text,this.OAUTH_TOKEN.Text,this.OAUTH_TIMESTAMP.Text);
			this.RedirectToMainPage();
		}

		
		private void RedirectToMainPage()
		{
			this.Response.Redirect("Calls.aspx");
		}


		public string EnvironmentLiteralText
		{
			get
			{
				return Constants.ENVIRONMENT;
			}
		}


	}
}
