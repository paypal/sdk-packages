using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.util;
namespace ASPDotNetSamples.AspNet
{
	/// <summary>
	/// Summary description for TransactionSearchResults.
	/// </summary>
	public class TransactionSearchResults : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			NVPCodec decoder = (NVPCodec) Session["NVPResp"];
			int intCount = 0;
			string htm="";

			htm="<center> <table class=api>"+
				"<tr>"+
				"<td colspan=6 class=header>"+
				"<b> Transaction Search Results </b> <br>"+
				" Results 1 - " + "REPLACECOUNTXXX"+
				"</td>"+
				"</tr>"+
				"<tr>"+
				"<td class=field>"+
				"</td>"+
				"<td class=field>"+
				"<b>ID</b></td>"+
				"<td class=field>"+
				"<b>Time</b></td>"+
				"<td class=field>"+
				"<b>Status</b></td>"+
				"<td class=field>"+
				"<b>Payer Name</b></td>"+
				"<td class=field>"+
				"<b>Gross Amount</b></td>"+
				"</tr>";

			while(decoder["L_TRANSACTIONID"+intCount]!=null && decoder["L_TRANSACTIONID"+intCount].Length>0 )
			{

				htm=htm+"<tr>" +

					"<td>" + intCount + "</td>" +

					"<td>"+ "<A id=TransactionDetailsLink0 href=GetTransactionDetails.aspx?transactionID=" + decoder["L_TRANSACTIONID"+intCount]+">"+decoder["L_TRANSACTIONID"+intCount] +"</A>"+ "</td>"+

					"<td>"+	decoder["L_TIMESTAMP"+intCount].Substring(0,10)+ " " +decoder["L_TIMESTAMP"+intCount].Substring(12,7)+ "</td>"+
					//decoder["L_TIMESTAMP"+intCount].Substring(0,10)+
					"<td>"+decoder["L_STATUS"+intCount]+"</td>"+

					"<td>"+decoder["L_NAME"+intCount]+"</td>"+

					"<td>"+decoder["L_CURRENCYCODE"+intCount]+decoder["L_AMT"+intCount] +"</td>"+

					"</tr>";

				intCount++;
			}
			htm=htm+"</table> </center>";
			htm=htm.Replace("REPLACECOUNTXXX",intCount.ToString());
			Response.Write(htm);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
