using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.core;
using com.paypal.sdk.util;
using ASPDotNetSamples;
namespace ASPDotNetSamples.AspNet
{	
	/// <summary>
	/// Summary description for ThreeDSecureRequest.
	/// </summary>
	public class ThreeDSecureRequest : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlInputText firstName;
		protected System.Web.UI.HtmlControls.HtmlInputText lastName;
		protected System.Web.UI.WebControls.DropDownList creditCardType;
		protected System.Web.UI.HtmlControls.HtmlInputText creditCardNumber;
		protected System.Web.UI.HtmlControls.HtmlSelect expdate_month;
		protected System.Web.UI.HtmlControls.HtmlSelect expdate_year;
		protected System.Web.UI.HtmlControls.HtmlInputText address1;
		protected System.Web.UI.HtmlControls.HtmlInputText address2;
		protected System.Web.UI.HtmlControls.HtmlInputText city;
		protected System.Web.UI.HtmlControls.HtmlInputText zip;
		protected System.Web.UI.HtmlControls.HtmlInputText amount;
		protected System.Web.UI.HtmlControls.HtmlSelect currency;
		protected System.Web.UI.HtmlControls.HtmlInputText cvv2Number;
		protected System.Web.UI.HtmlControls.HtmlSelect startdate_month;
		protected System.Web.UI.HtmlControls.HtmlSelect startdate_year;
		protected System.Web.UI.HtmlControls.HtmlInputText state;
		protected System.Web.UI.HtmlControls.HtmlInputText eciFlag;
		protected System.Web.UI.HtmlControls.HtmlInputText cavv;
		protected System.Web.UI.HtmlControls.HtmlInputText enrolled;
		protected System.Web.UI.HtmlControls.HtmlInputText pAResStatus;
		protected System.Web.UI.HtmlControls.HtmlInputText xid;
		protected System.Web.UI.WebControls.Button PayButton;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				if (creditCardType.SelectedItem.Value!="Maestro")
					creditCardNumber.Value=Util.GenerateCreditCardNumber(creditCardType.SelectedItem.Value);
				else
					creditCardNumber.Value="6759380010646905";
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.creditCardType.SelectedIndexChanged += new System.EventHandler(this.creditCardType_SelectedIndexChanged);
			this.PayButton.Click += new System.EventHandler(this.PayButton_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void PayButton_Click(object sender, System.EventArgs e)
		{

				com.paypal.sdk.services.NVPCallerServices caller =PayPalAPI.PayPalAPIInitialize();
				NVPCodec encoder= new NVPCodec();
				encoder["METHOD"] =  "DoDirectPayment";
				encoder["PAYMENTACTION"] =  "Sale";
				encoder["AMT"] =  amount.Value;
				encoder["CREDITCARDTYPE"] =  creditCardType.SelectedItem.Value;		
				encoder["ACCT"] =  creditCardNumber.Value;						
				encoder["EXPDATE"] =  expdate_month.Value.ToString() +expdate_year.Value;
				encoder["STARTDATE"] =  startdate_month.Value.ToString() +startdate_year.Value;
				encoder["CVV2"] =  cvv2Number.Value;
				encoder["FIRSTNAME"] =  firstName.Value;
				encoder["LASTNAME"] =  lastName.Value;										
				encoder["STREET"] =  address1.Value;
				encoder["CITY"] =  city.Value;	
				encoder["STATE"] =  state.Value;			
				encoder["ZIP"] =  zip.Value;	
				encoder["COUNTRYCODE"] =  "GB";	
				encoder["CURRENCYCODE"] =  currency.Value;	

				//For 3D Secure
				encoder["ECI3DS"] =  eciFlag.Value;	
				encoder["CAVV"] =  cavv.Value;	
				encoder["XID"] =  xid.Value;	
				encoder["MPIVENDOR3DS"] =  enrolled.Value;	
				encoder["AUTHSTATUS3DS"] = pAResStatus.Value;	






				string pStrrequestforNvp= encoder.Encode();
				string pStresponsenvp=caller.Call(pStrrequestforNvp);

				NVPCodec decoder = new NVPCodec();
				decoder.Decode(pStresponsenvp);

				string strAck = decoder["ACK"]; 
				if(strAck !=null && (strAck=="Success" || strAck=="SuccessWithWarning"))
				{
					Session["result"]=decoder;
					string pStrResQue=	"API="+ "3D Secure DDP"; 
					Response.Redirect("ResponseThreeD.aspx?"+pStrResQue);
				}
				else
				{
					Session["errorresult"]=decoder;
					string pStrResQue=	"API="+ "Error Detail "; 
					Response.Redirect("..\\APIError.aspx?"+pStrResQue);
					
				}
			
		}



		private void creditCardType_SelectedIndexChanged(object sender, System.EventArgs e)
		{			
			if (creditCardType.SelectedItem.Value!="Maestro")
				creditCardNumber.Value=Util.GenerateCreditCardNumber(creditCardType.SelectedItem.Value);
			else
				creditCardNumber.Value="6759380010646905";

		}
	}
}
