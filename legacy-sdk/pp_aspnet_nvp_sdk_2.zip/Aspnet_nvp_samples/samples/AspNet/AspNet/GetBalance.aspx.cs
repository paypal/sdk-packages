using System;
using System.Web.UI;
using com.paypal.sdk.core;
using com.paypal.sdk.util;
namespace ASPDotNetSamples.AspNet
{
	/// <summary>
	/// Summary description for _Default.
	/// </summary>
	public class GetBalance : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button GetButton;
	
		private void Page_Load(object sender, EventArgs e)
		{

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.GetButton.Click += new System.EventHandler(this.GetButton_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		public void GetButton_Click(object sender, System.EventArgs e)
		{
			com.paypal.sdk.services.NVPCallerServices caller =PayPalAPI.PayPalAPIInitialize();
			NVPCodec encoder= new NVPCodec();
			encoder["METHOD"] =  "GetBalance";

			string pStrrequestforNvp= encoder.Encode();
			string pStresponsenvp=caller.Call(pStrrequestforNvp);

			NVPCodec decoder = new NVPCodec();
			decoder.Decode(pStresponsenvp);

			string strAck = decoder["ACK"]; 
			if(strAck !=null && (strAck=="Success" || strAck=="SuccessWithWarning"))
			{
				Session["result"]=decoder;
				string pStrResQue=	"API="+ "GetBalance Response"; 
				Response.Redirect("GetBalanceResponse.aspx?"+pStrResQue); 

			}
			else
			{
				Session["errorresult"]=decoder;
				string pStrResQue=	"API="+ "Error Detail "; 
				Response.Redirect("APIError.aspx?"+pStrResQue);
			}			


		}
	}
}
