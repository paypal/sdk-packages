using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.core;
using com.paypal.sdk.util;
namespace ASPDotNetSamples.AspNet
{
	/// <summary>
	/// Summary description for GetExpressCheckoutDetails.
	/// </summary>
	public class GetExpressCheckoutDetails : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlInputHidden Street1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden Street2;
		protected System.Web.UI.HtmlControls.HtmlInputHidden City;
		protected System.Web.UI.HtmlControls.HtmlInputHidden State;
		protected System.Web.UI.HtmlControls.HtmlInputHidden Code;
		protected System.Web.UI.HtmlControls.HtmlInputButton ECReceiptLink;
		protected System.Web.UI.HtmlControls.HtmlInputHidden Country;
        protected System.Web.UI.HtmlControls.HtmlInputHidden ShippingCalculationMode;
        protected System.Web.UI.HtmlControls.HtmlInputHidden ShippingOptionAmount;
        protected System.Web.UI.HtmlControls.HtmlInputHidden ShippingOptionName;
		protected System.Web.UI.HtmlControls.HtmlInputHidden OrderTotal;
      
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			com.paypal.sdk.services.NVPCallerServices caller =PayPalAPI.PayPalAPIInitialize();
			NVPCodec encoder= new NVPCodec();
			encoder["METHOD"] =  "GetExpressCheckoutDetails";
			encoder["TOKEN"] =  Session["TOKEN"].ToString();

			string pStrrequestforNvp= encoder.Encode();
			string pStresponsenvp=caller.Call(pStrrequestforNvp);

			NVPCodec decoder = new NVPCodec();
			decoder.Decode(pStresponsenvp);
			
			
			string strAck = decoder["ACK"]; 
			if(strAck !=null && (strAck=="Success" || strAck=="SuccessWithWarning"))
			{
				string res=Util.BuildResponse(decoder,"Review Order","Step 3: DoExpressCheckoutPayment");									
				Response.Write(res);

				Session["PAYERID"]= decoder["PAYERID"];
				Session["Amount"]=decoder["AMT"];

			}
			else
			{
				Session["errorresult"]=decoder;
				string pStrResQue=	"API="+ "Error Detail "; 
				Response.Redirect("APIError.aspx?"+pStrResQue);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ECReceiptLink.ServerClick += new System.EventHandler(this.ECReceiptLink_ServerClick);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void ECReceiptLink_ServerClick(object sender, System.EventArgs e)
		{
			com.paypal.sdk.services.NVPCallerServices caller =PayPalAPI.PayPalAPIInitialize();
			NVPCodec encoder= new NVPCodec();
			encoder["METHOD"] =  "DoExpressCheckoutPayment";
			encoder["TOKEN"] =  Session["TOKEN"].ToString();
			encoder["PAYERID"] =  Session["PAYERID"].ToString();
			encoder["AMT"] =  Session["Amount"].ToString();
			encoder["PAYMENTACTION"] =  Request.QueryString["paymentType"];
			encoder["CURRENCYCODE"] =  Request.QueryString["currency"];

			string pStrrequestforNvp= encoder.Encode();
			string pStresponsenvp=caller.Call(pStrrequestforNvp);

			NVPCodec decoder = new NVPCodec();
			decoder.Decode(pStresponsenvp);
			
			
			string strAck = decoder["ACK"]; 
			if(strAck !=null && (strAck=="Success" || strAck=="SuccessWithWarning"))
			{
				Session["result"]=decoder;
				string pStrResQue=	"API="+ "DoExpressCheckoutPayment"; 
				Response.Redirect("DoExpressCheckoutPayment.aspx?"+pStrResQue);
			}
			else
			{
				Session["errorresult"]=decoder;
				string pStrResQue=	"API="+ "Error Detail "; 
				Response.Redirect("APIError.aspx?"+pStrResQue);
			}
		
		}
	}
}
