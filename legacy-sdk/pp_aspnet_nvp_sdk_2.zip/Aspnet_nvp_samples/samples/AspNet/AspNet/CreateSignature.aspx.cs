using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.core;

namespace ASPDotNetSamples.AspNet
{
    public  class CreateSignature : System.Web.UI.Page
    {
		OauthSignature.HTTPMethod method;
		protected System.Web.UI.HtmlControls.HtmlInputText TextUserName;
		protected System.Web.UI.HtmlControls.HtmlInputText TextPassword;
		protected System.Web.UI.HtmlControls.HtmlInputText TextAccessToken;
		protected System.Web.UI.HtmlControls.HtmlInputText TextTokenSecret;
		protected System.Web.UI.HtmlControls.HtmlSelect TextHttpMethod;
		protected System.Web.UI.HtmlControls.HtmlInputText TextScriptURI;
		protected System.Web.UI.HtmlControls.HtmlInputButton Submit1;

		private void InitializeComponent()
		{
		
		}
				   
        protected void Submit2_ServerClick(object sender, EventArgs e)
        {

           string apiUserName=TextUserName.Value;
		   string apiPsw=TextPassword.Value;	
           string accessToken=TextAccessToken.Value;
           string tokenSecret=TextTokenSecret.Value;
           string  httpMethod=TextHttpMethod.Value;
		   string scriptURI=TextScriptURI.Value;
           
			
			if("POST"==httpMethod)
			{
				method=OauthSignature.HTTPMethod.POST;
			}
			else if("GET"==httpMethod)
			{
				method=OauthSignature.HTTPMethod.GET;
			}
			else if("HEAD"==httpMethod)
			{
				method=OauthSignature.HTTPMethod.HEAD;
			}
			else if("PUT"==httpMethod)
			{
				method=OauthSignature.HTTPMethod.PUT;
			}
			else if("UPDATE"==httpMethod)
			{
				method=OauthSignature.HTTPMethod.UPDATE;
			}
          
			try
			{

				Hashtable map=OauthSignature.getAuthHeader(apiUserName, apiPsw,
					accessToken, tokenSecret,method, scriptURI, null);
				
				Session["OauthParamMap"]=map;
				Response.Redirect("CreateSignatureReceipt.aspx"); 
			}
			catch(OAuthException oae)
			{

				Session["OauthException"]=oae;
				Response.Redirect("CreateSignatureReceipt.aspx");
			} 
          
        }
    }
}
