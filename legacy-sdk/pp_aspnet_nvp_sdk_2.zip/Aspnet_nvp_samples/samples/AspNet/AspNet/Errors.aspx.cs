using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.util;
namespace ASPDotNetSamples.AspNet
{
	/// <summary>
	/// Summary description for Error Page.
	/// </summary>
	public class Errors : System.Web.UI.Page
	{


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)	
		{
			
			NVPCodec decoder = new NVPCodec();
			decoder= (NVPCodec)Session["errorresult"];


			string res="<center>";
			res=res+ "<font size=2 color=black face=Verdana><b>" +"PayPal API Error" + "</b></font>";
			res=res+ "<br>";
			res=res+ "<br>";

			
				res=res+ "<b>"+"A PayPal API has returned an error!"+"</b><br>";

			res=res+ "<br>";

			res=res+"<table width=400 class=api>";




			for (int i=0; i<decoder.Keys.Count;i++)
			{
				res=res+ "<tr><td class=field> " +decoder.Keys[i].ToString() +":</td>";
				res=res+"<td>" +decoder.GetValues(i)[0] +"</td>";
				res=res+"</tr>";
				res=res+"<tr>";
			}
					 			
			res=res+"</table>";
			res=res+"</center>";
			
			Response.Write(res);


		}
	}
}
