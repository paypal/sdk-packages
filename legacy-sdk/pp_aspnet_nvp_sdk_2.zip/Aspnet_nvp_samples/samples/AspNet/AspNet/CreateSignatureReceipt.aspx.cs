using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.core;

namespace ASPDotNetSamples.AspNet
{
	/// <summary>
	/// Summary description for DoCaptureReceipt.
	/// </summary>
	public class CreateSignatureReceipt : System.Web.UI.Page
	{
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string res=null;
			if(!IsPostBack)
			{
				Hashtable map=(Hashtable)Session["OauthParamMap"];
				if(map!=null)
				{
					res="<center>";
					res=res+ "<font size=2 color=black face=Verdana><b>" +"Generate Signature" + "</b></font>";
					res=res+ "<br>";
					res=res+ "<br>";
		
					res=res+ "<b>"+"Signature"+"</b><br>";
					res=res+ "<br>";
					res=res+"<table width=400 class=api>";
					foreach(string name in map.Keys)
					{
						res=res+"<tr><td class=field>" +name +":</td>";
						res=res+"<td>" +(string)map[name]+"</td>";
						res=res+"</tr>";
						res=res+"<tr>";
					}
	               				 			
					res=res+"</table>";
					res=res+"</center>";
					
				}
				OAuthException exception=(OAuthException)Session["OauthException"];
				if(exception!=null)
				{
					res="<center>";
					res=res+ "<font size=2 color=black face=Verdana><b>" +"PayPal Signature Error" + "</b></font>";
					res=res+ "<br>";
					res=res+ "<br>";
			
					res=res+ "<b>"+"A PayPal Signature has returned an error!"+"</b><br>";
					res=res+ "<br>";
					res=res+"<table width=400 class=api>";
					res=res+ "<tr><td class=field> " +exception.GetType()+":</td>";
					res=res+"<td>" +exception.Message+"</td>";
					res=res+"</tr>";
					res=res+"<tr>";
				}		
			}
			Session.Remove("OauthParamMap");
			Session.Remove("OauthException");

			Response.Write(res);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
