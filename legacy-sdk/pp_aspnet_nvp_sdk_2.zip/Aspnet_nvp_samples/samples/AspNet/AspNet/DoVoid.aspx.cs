using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.core;
using com.paypal.sdk.util;

namespace ASPDotNetSamples.AspNet
{
	/// <summary>
	/// Summary description for DoVoid.
	/// </summary>
	public class DoVoid : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlInputButton Submit;
		protected System.Web.UI.HtmlControls.HtmlTextArea note;
		protected System.Web.UI.HtmlControls.HtmlForm DoVoidForm;
		protected System.Web.UI.HtmlControls.HtmlInputText authorization_id;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Request.QueryString.Get("TRANSACTIONID")!=null)
				authorization_id.Value=Request.QueryString.Get("TRANSACTIONID");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Submit.ServerClick += new System.EventHandler(this.Submit_ServerClick);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Submit_ServerClick(object sender, System.EventArgs e)
		{

				com.paypal.sdk.services.NVPCallerServices caller =PayPalAPI.PayPalAPIInitialize();
				NVPCodec encoder= new NVPCodec();
				encoder["METHOD"] =  "DoVoid";
				encoder["AUTHORIZATIONID"] =  authorization_id.Value;
				encoder["NOTE"] =  note.Value;
				encoder["TRXTYPE"] =  "V";		

				string pStrrequestforNvp= encoder.Encode();
				string pStresponsenvp=caller.Call(pStrrequestforNvp);

				NVPCodec decoder = new NVPCodec();
				decoder.Decode(pStresponsenvp);

				string strAck = decoder["ACK"]; 
			if(strAck !=null && (strAck=="Success" || strAck=="SuccessWithWarning"))
			{
				Session["result"]=decoder;
				string pStrResQue=	"API="+ "Do Void"; 
				Response.Redirect("DoVoidReceipt.aspx?"+pStrResQue); 

			}
			else
			{
				Session["errorresult"]=decoder;
				string pStrResQue=	"API="+ "Error Detail "; 
				Response.Redirect("APIError.aspx?"+pStrResQue);
			}			
		}
	}
}
