using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.core;
using com.paypal.sdk.util;
using ASPDotNetSamples;

namespace ASPDotNetSamples.AspNet.BillOutstandingAmount
{
	/// <summary>
	/// Summary description for Error Page.
	/// </summary>
	public class BillOutstandingAmount : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button PayButton;		
		protected System.Web.UI.HtmlControls.HtmlInputText Text2;
		protected System.Web.UI.HtmlControls.HtmlInputText profileID;
		protected System.Web.UI.HtmlControls.HtmlInputText amount;
		protected System.Web.UI.HtmlControls.HtmlInputText Text1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{

			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.PayButton.Click += new System.EventHandler(this.PayButton_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		private void PayButton_Click(object sender, System.EventArgs e)
		{
			com.paypal.sdk.services.NVPCallerServices caller =PayPalAPI.PayPalAPIInitialize();
			NVPCodec encoder= new NVPCodec();
			encoder["METHOD"] =  "BillOutstandingAmount";						
			encoder["PROFILEID"]=profileID.Value;
			encoder["AMT"] =amount.Value;			

			string pStrrequestforNvp= encoder.Encode();
			string pStresponsenvp=caller.Call(pStrrequestforNvp);

			NVPCodec decoder = new NVPCodec();
			decoder.Decode(pStresponsenvp);

			string strAck = decoder["ACK"]; 
			if(strAck !=null && (strAck=="Success" || strAck=="SuccessWithWarning"))
			{
				Session["result"]=decoder;
				string pStrResQue=	"API="+ "Bill OutStanding"; 
					Response.Redirect("Response.aspx?"+pStrResQue);
			}
			else
			{
				Session["errorresult"]=decoder;
				string pStrResQue=	"API="+ "Error Detail "; 				
				Response.Redirect("..\\APIError.aspx?"+pStrResQue);
			}
		}

	}
}