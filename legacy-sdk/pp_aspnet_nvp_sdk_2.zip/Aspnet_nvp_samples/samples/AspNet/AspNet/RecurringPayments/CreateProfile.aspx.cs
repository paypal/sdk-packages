using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.core;
using com.paypal.sdk.util;
using ASPDotNetSamples;

namespace ASPDotNetSamples.AspNet
{
	/// <summary>
	/// Summary description for Error Page.
	/// </summary>
	public class CreateProfile : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList creditCardType;
		protected System.Web.UI.WebControls.Button PayButton;
		protected System.Web.UI.HtmlControls.HtmlInputText lastName;
		protected System.Web.UI.HtmlControls.HtmlInputText creditCardNumber;
		protected System.Web.UI.HtmlControls.HtmlSelect expdate_month;
		protected System.Web.UI.HtmlControls.HtmlSelect expdate_year;
		protected System.Web.UI.HtmlControls.HtmlInputText cvv2Number;
		protected System.Web.UI.HtmlControls.HtmlInputText address1;
		protected System.Web.UI.HtmlControls.HtmlInputText address2;
		protected System.Web.UI.HtmlControls.HtmlInputText city;
		protected System.Web.UI.HtmlControls.HtmlSelect state;
		protected System.Web.UI.HtmlControls.HtmlInputText zip;
		protected System.Web.UI.HtmlControls.HtmlInputText amount;
		protected System.Web.UI.HtmlControls.HtmlSelect currency;
		//protected System.Web.UI.HtmlControls.HtmlSelect Select1;
		protected System.Web.UI.HtmlControls.HtmlInputText Text2;
		protected System.Web.UI.HtmlControls.HtmlInputText firstName;
		protected System.Web.UI.HtmlControls.HtmlInputText ProfileDescription;
		protected System.Web.UI.HtmlControls.HtmlSelect BillingPeriod;
		protected System.Web.UI.HtmlControls.HtmlSelect pMonth;
		protected System.Web.UI.HtmlControls.HtmlSelect pYear;
		protected System.Web.UI.HtmlControls.HtmlSelect pDate;
		protected System.Web.UI.HtmlControls.HtmlInputText Text1;
		protected System.Web.UI.HtmlControls.HtmlInputText BillingFrequency;
		protected System.Web.UI.HtmlControls.HtmlInputText totalBillingCycles;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				creditCardNumber.Value=Util.GenerateCreditCardNumber(creditCardType.SelectedItem.Value);
				pDate.SelectedIndex=System.DateTime.Today.Day-1;
				pMonth.SelectedIndex=System.DateTime.Today.Month-1;
				pYear.Value= System.DateTime.Today.Year.ToString();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.creditCardType.SelectedIndexChanged += new System.EventHandler(this.creditCardType_SelectedIndexChanged);
			this.PayButton.Click += new System.EventHandler(this.PayButton_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		private void PayButton_Click(object sender, System.EventArgs e)
		{
			com.paypal.sdk.services.NVPCallerServices caller =PayPalAPI.PayPalAPIInitialize();
			NVPCodec encoder= new NVPCodec();
			encoder["METHOD"] =  "CreateRecurringPaymentsProfile";			
			encoder["AMT"] =amount.Value;
			encoder["CREDITCARDTYPE"] =  creditCardType.SelectedItem.Value;		
			encoder["ACCT"] =  creditCardNumber.Value;						
			encoder["EXPDATE"] =  expdate_month.Value.ToString() +expdate_year.Value;
			encoder["CVV2"] =  cvv2Number.Value;
			encoder["FIRSTNAME"] =  firstName.Value;
			encoder["LASTNAME"] =  lastName.Value;										
			encoder["STREET"] =  address1.Value;
			encoder["CITY"] =  city.Value;	
			encoder["STATE"] =  state.Value;			
			encoder["ZIP"] =  zip.Value;	
			encoder["COUNTRYCODE"] =  "US";	
			encoder["CURRENCYCODE"] =  currency.Value; 
			string pdates=pYear.Value+"-" +pMonth.Value +"-" +pDate.Value+"T0:0:0";//Date format from server expects Ex: 2006-9-6T0:0:0;
			encoder["PROFILESTARTDATE"] = pdates;
			encoder["BILLINGPERIOD"] =BillingPeriod.Value;	
			encoder["BILLINGFREQUENCY"] =BillingFrequency.Value;
			encoder["TOTALBILLINGCYCLES"]=totalBillingCycles.Value;
			encoder["DESC"]=ProfileDescription.Value;

			string pStrrequestforNvp= encoder.Encode();
			string pStresponsenvp=caller.Call(pStrrequestforNvp);

			NVPCodec decoder = new NVPCodec();
			decoder.Decode(pStresponsenvp);

			string strAck = decoder["ACK"]; 
			if(strAck !=null && (strAck=="Success" || strAck=="SuccessWithWarning"))
			{
				Session["result"]=decoder;
				string pStrResQue=	"API="+ "Create Recurring Payments Profile"; 
					Response.Redirect("Response.aspx?"+pStrResQue);
			}
			else
			{
				Session["errorresult"]=decoder;
				string pStrResQue=	"API="+ "Error Detail "; 				
				Response.Redirect("..\\APIError.aspx?"+pStrResQue);
			}
		}
		private void creditCardType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			creditCardNumber.Value=Util.GenerateCreditCardNumber(creditCardType.SelectedItem.Value);
		}
	}
}