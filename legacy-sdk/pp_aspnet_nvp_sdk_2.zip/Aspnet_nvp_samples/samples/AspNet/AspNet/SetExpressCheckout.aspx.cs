using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace ASPDotNetSamples.AspNet
{
	/// <summary>
	/// Summary description for SetExpressCheckout.
	/// </summary>
	public class SetExpressCheckout : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlInputText paymentAmount;
		protected System.Web.UI.HtmlControls.HtmlSelect currencyCodeType;
		protected System.Web.UI.HtmlControls.HtmlForm ExpressCheckoutForm;
		protected System.Web.UI.HtmlControls.HtmlInputText NAME;
		protected System.Web.UI.HtmlControls.HtmlInputText SHIPTOSTREET;
		protected System.Web.UI.HtmlControls.HtmlInputText SHIPTOCITY;
		protected System.Web.UI.HtmlControls.HtmlInputText SHIPTOSTATE;
		protected System.Web.UI.HtmlControls.HtmlInputText SHIPTOCOUNTRYCODE;
		protected System.Web.UI.HtmlControls.HtmlInputText SHIPTOZIP;
		protected System.Web.UI.HtmlControls.HtmlInputText L_NAME1;
		protected System.Web.UI.HtmlControls.HtmlInputText L_AMT1;
		protected System.Web.UI.HtmlControls.HtmlInputText L_QTY1;
		protected System.Web.UI.HtmlControls.HtmlInputText L_NAME0;
		protected System.Web.UI.HtmlControls.HtmlInputText L_AMT0;
		protected System.Web.UI.HtmlControls.HtmlInputText L_QTY0;
		
		protected System.Web.UI.HtmlControls.HtmlInputImage submit;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.submit.ServerClick += new System.Web.UI.ImageClickEventHandler(this.submit_ServerClick);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void submit_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
		
		{
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			
			sb.Append(Request.QueryString[Constants.PAYMENT_TYPE_PARAM]);
			sb.Append("&currency=");
			sb.Append(currencyCodeType.Value);
			sb.Append("&NAME=");
			sb.Append(NAME.Value);
			sb.Append("&SHIPTOSTREET=");
			sb.Append(SHIPTOSTREET.Value);
			sb.Append("&SHIPTOCITY=");
			sb.Append(SHIPTOCITY.Value);
			sb.Append("&SHIPTOSTATE=");
			sb.Append(SHIPTOSTATE.Value);
			sb.Append("&SHIPTOCOUNTRYCODE=");
			sb.Append(SHIPTOCOUNTRYCODE.Value);
			sb.Append("&SHIPTOZIP=");
			sb.Append(SHIPTOZIP.Value);
			sb.Append("&L_NAME1=");
			sb.Append(L_NAME1.Value);
			sb.Append("&L_AMT1=");
			sb.Append(L_AMT1.Value);
			sb.Append("&L_QTY1=");
			sb.Append(L_QTY1.Value);
			sb.Append("&L_NAME0=");
			sb.Append(L_NAME0.Value);
			sb.Append("&L_AMT0=");
			sb.Append(L_AMT0.Value);
			sb.Append("&L_QTY0=");
			sb.Append(L_QTY0.Value);
			
			Response.Redirect("ReviewOrder.aspx?paymentType="+ sb.ToString());
		}


	}
}
