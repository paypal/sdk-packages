/*
 * Copyright 2010 PayPal, Inc. All Rights Reserved.
 */

package com.paypal.platform.adaptiveAccount;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;

import com.paypal.platform.common.PlatformBase;
import com.paypal.platform.common.ResponseBuilder;
import com.paypal.platform.common.SampleNVPConstants;
import com.paypal.platform.sdk.core.CallerServices;
import com.paypal.platform.sdk.core.Constants;
import com.paypal.platform.sdk.core.Decoder;
import com.paypal.platform.sdk.core.Encoder;
import com.paypal.platform.sdk.core.SerializeFactory;
import com.paypal.platform.sdk.exception.FatalException;

/**
 *
 * @author tkanta
 * The Class executes all Adaptive Account api operation, loads credentials from property files.
 */
public class AdaptiveAccountAction extends PlatformBase{
	private static final long serialVersionUID = 7047317567784238957L;
	private static Log log = LogFactory.getLog(AdaptiveAccountAction.class);
	private String serverResponse =Constants.EMPTYSTRING;
	private Map credentials=new HashMap();
    
	/**
	 * Loads API credentials from properties file and initialize PayPal Host URI
	 */
	{
		  loadPropertiesFromDefaultLocation();
	}

	/**
	 * Create Account
	 * @return
	 */
	public String createAccount(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		Decoder decoder= SerializeFactory.getInstance().getDecoder();
		ResponseBuilder responseBuilder=new ResponseBuilder();
		String apiName = "/AdaptiveAccounts/CreateAccount";
    	String header1="Create Account";
		String header2="";
		String result="";
		HashMap payLinks=new HashMap();
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			String sandboxDeveloperEmail=getServletRequest().getParameter("sandboxDeveloperEmail");
			credentials.put("X-PAYPAL-SANDBOX-EMAIL-ADDRESS", sandboxDeveloperEmail);

			String returnUrl=getContextUrl()+"/jsp/public/WebflowReturnPage.jsp";

			encoder.add(SampleNVPConstants.CreateAccount.createAccountWebOptionsReturnUrl,returnUrl);
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.CreateAccount.preferredLanguageCode,"en_US");
			encoder.add(SampleNVPConstants.CreateAccount.accountType,getServletRequest().getParameter("accountType"));
			encoder.add(SampleNVPConstants.CreateAccount.nameSalutation,getServletRequest().getParameter("name.salutation"));
			encoder.add(SampleNVPConstants.CreateAccount.nameFirstName,getServletRequest().getParameter("name.firstName"));
			encoder.add(SampleNVPConstants.CreateAccount.nameMiddleName,getServletRequest().getParameter("name.middleName"));
			encoder.add(SampleNVPConstants.CreateAccount.nameLastName,getServletRequest().getParameter("name.lastName"));
			encoder.add(SampleNVPConstants.CreateAccount.dateOfBirth,getServletRequest().getParameter("dateOfBirth"));
			encoder.add(SampleNVPConstants.CreateAccount.addressLine1,getServletRequest().getParameter("address.line1"));
			encoder.add(SampleNVPConstants.CreateAccount.addressLine1,getServletRequest().getParameter("address.line2"));
			encoder.add(SampleNVPConstants.CreateAccount.addressCity,getServletRequest().getParameter("address.city"));
			encoder.add(SampleNVPConstants.CreateAccount.addressState,getServletRequest().getParameter("address.state"));
			encoder.add(SampleNVPConstants.CreateAccount.addressPostalCode,getServletRequest().getParameter("address.postalCode"));
			encoder.add(SampleNVPConstants.CreateAccount.addressCountryCode,getServletRequest().getParameter("address.countryCode"));
			encoder.add(SampleNVPConstants.CreateAccount.citizenshipCountryCode,getServletRequest().getParameter("citizenshipCountryCode"));
			encoder.add(SampleNVPConstants.CreateAccount.contactPhoneNumber,getServletRequest().getParameter("contactPhoneNumber"));
			encoder.add(SampleNVPConstants.CreateAccount.notificationURL,getServletRequest().getParameter("notificationURL"));
			encoder.add(SampleNVPConstants.CreateAccount.partnerField1,getServletRequest().getParameter("partnerField1"));
			encoder.add(SampleNVPConstants.CreateAccount.partnerField2,getServletRequest().getParameter("partnerField2"));
			encoder.add(SampleNVPConstants.CreateAccount.partnerField3,getServletRequest().getParameter("partnerField3"));
			encoder.add(SampleNVPConstants.CreateAccount.partnerField4,getServletRequest().getParameter("partnerField4"));
			encoder.add(SampleNVPConstants.CreateAccount.partnerField5,getServletRequest().getParameter("partnerField5"));
			encoder.add(SampleNVPConstants.CreateAccount.currencyCode,getServletRequest().getParameter("currencyCode"));
			encoder.add(SampleNVPConstants.CreateAccount.emailAddress,getServletRequest().getParameter("email"));
			encoder.add(SampleNVPConstants.CreateAccount.registrationType,"WEB");

			if("BUSINESS".equalsIgnoreCase(getServletRequest().getParameter("accountType"))){
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoBusinessName,getServletRequest().getParameter("biz_name"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoBusinessAddressLine1,getServletRequest().getParameter("biz_address_line1"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoBusinessAddressLine2,getServletRequest().getParameter("biz_address_line2"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoBusinessAddressCity,getServletRequest().getParameter("biz_address_city"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoBusinessAddressState,getServletRequest().getParameter("biz_address_state"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoBusinessAddressPostalCode,getServletRequest().getParameter("biz_address_postalCode"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoBusinessAddressCountryCode,getServletRequest().getParameter("biz_address_countryCode"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoWorkPhone,getServletRequest().getParameter("biz_contactPhoneNumber"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoCategory,getServletRequest().getParameter("biz_CategoryCode"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoSubCategory,getServletRequest().getParameter("biz_subCategoryCode"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoCustomerServicePhone,getServletRequest().getParameter("biz_customerServicePhone"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoCustomerServiceEmail,getServletRequest().getParameter("biz_customerServiceEmail"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoWebSite,getServletRequest().getParameter("biz_webSite"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoDateOfEstablishment,getServletRequest().getParameter("biz_dateOfEstablishment"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoBusinessType,getServletRequest().getParameter("businessType"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoAveragePrice,getServletRequest().getParameter("biz_averagePrice"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoAverageMonthlyVolume,getServletRequest().getParameter("biz_averageMonthlyVolume"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoPercentageRevenueFromOnline,getServletRequest().getParameter("biz_percentageRevenueFromOnline"));
				encoder.add(SampleNVPConstants.CreateAccount.businessInfoSalesVenue,getServletRequest().getParameter("biz_salesVenue"));
			}
			String request = encoder.encode();
			String  response = CallerServices.call(request, endPointURL, credentials);
			decoder.decode(response);
			String redirectURL=decoder.get("redirectURL");
			String ack= decoder.get("responseEnvelope.ack");

			if("SUCCESS".equalsIgnoreCase(ack) && (redirectURL != null && redirectURL.length()>0)){
				payLinks.put("redirectURL",redirectURL);
				serverResponse = responseBuilder.createHtmlResponse(decoder,header1,header2,payLinks);
			}else{
				serverResponse=responseBuilder.createHtmlResponse(decoder,header1,header2,null);
			}
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * Add Bank Account
	 * @return
	 */
	public String addBankAccount(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		Decoder decoder= SerializeFactory.getInstance().getDecoder();
		ResponseBuilder responseBuilder=new ResponseBuilder();
		String apiName = "/AdaptiveAccounts/AddBankAccount";
    	String header1="Add Bank Account";
		String header2="";
		String result="";
		HashMap payLinks=new HashMap();
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.AddBankAccount.emailAddress,getServletRequest().getParameter("emailID"));
			encoder.add(SampleNVPConstants.AddBankAccount.bankCountryCode,getServletRequest().getParameter("bankCountryCode"));
			encoder.add(SampleNVPConstants.AddBankAccount.bankName,getServletRequest().getParameter("bankName"));
			encoder.add(SampleNVPConstants.AddBankAccount.routingNumber,getServletRequest().getParameter("routingNumber"));
			encoder.add(SampleNVPConstants.AddBankAccount.bankAccountNumber,getServletRequest().getParameter("bankAccountNumber"));
			encoder.add(SampleNVPConstants.AddBankAccount.bankAccountType,getServletRequest().getParameter("accounttype"));
			encoder.add(SampleNVPConstants.AddBankAccount.confirmationType,getServletRequest().getParameter("confirmationType"));

			String createAccountKey=getServletRequest().getParameter("createAccountKey");
			  if(createAccountKey != null && createAccountKey.length()>0){
				  encoder.add(SampleNVPConstants.AddBankAccount.createAccountKey,getServletRequest().getParameter("createAccountKey"));
			  }
			String confirmationType=getServletRequest().getParameter("confirmationType");
			  if(confirmationType != null && !"NONE".equalsIgnoreCase(confirmationType)){
				    String returnUrl=getContextUrl()+"/jsp/public/WebflowReturnPage.jsp";
				  	String cancelUrl=getContextUrl()+"/jsp/public/Calls.jsp";
					encoder.add(SampleNVPConstants.AddBankAccount.webOptionsReturnUrl,returnUrl);
					encoder.add(SampleNVPConstants.AddBankAccount.webOptionsReturnUrlDescription,"return URL");
					encoder.add(SampleNVPConstants.AddBankAccount.webOptionsCancelUrl,cancelUrl);
					encoder.add(SampleNVPConstants.AddBankAccount.webOptionsCancelUrlDescription,"cancel URL");
			  }

			String request = encoder.encode();
			String  response = CallerServices.call(request, endPointURL, credentials);
			decoder.decode(response);
			String redirectURL=decoder.get("redirectURL");
			String ack= decoder.get("responseEnvelope.ack");
			if("SUCCESS".equalsIgnoreCase(ack) && (redirectURL != null && redirectURL.length()>0)){
				payLinks.put("redirectURL",redirectURL);
				serverResponse = responseBuilder.createHtmlResponse(decoder,header1,header2,payLinks);
			}else{
				serverResponse=responseBuilder.createHtmlResponse(decoder,header1,header2,null);
			}
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * Get Verified Status of  Account
	 * @return
	 */
	public String getVerifiedStatus(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		String apiName = "/AdaptiveAccounts/GetVerifiedStatus";
    	String header1="Get Verified Status";
		String header2="";

		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.GetVerifiedStatus.emailAddress,getServletRequest().getParameter("emailID"));
			encoder.add(SampleNVPConstants.GetVerifiedStatus.firstName,getServletRequest().getParameter("firstName"));
			encoder.add(SampleNVPConstants.GetVerifiedStatus.lastName,getServletRequest().getParameter("lastName"));
			encoder.add(SampleNVPConstants.GetVerifiedStatus.matchCriteria,getServletRequest().getParameter("matchCrieteria"));
			dispatch(encoder,endPointURL,header1,header2);
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * This will add the credit card to your account.
	 * @return
	 */
	public String addPaymentCard(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		Decoder decoder= SerializeFactory.getInstance().getDecoder();
		String apiName = "/AdaptiveAccounts/AddPaymentCard";
    	String header1="Add Payment Card";
		String header2="";
		String result="";
		ResponseBuilder responseBuilder=new ResponseBuilder();
		HashMap payLinks=new HashMap();
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.AddPaymentCard.emailAddress,getServletRequest().getParameter("emailID"));
			encoder.add(SampleNVPConstants.AddPaymentCard.cardType,getServletRequest().getParameter("creditCardType"));
			encoder.add(SampleNVPConstants.AddPaymentCard.cardNumber,getServletRequest().getParameter("cardNumber"));
			encoder.add(SampleNVPConstants.AddPaymentCard.nameOnCardFirstName,getServletRequest().getParameter("firstName"));
			encoder.add(SampleNVPConstants.AddPaymentCard.nameOnCardLastName,getServletRequest().getParameter("lastName"));
			encoder.add(SampleNVPConstants.AddPaymentCard.expirationDateMonth,getServletRequest().getParameter("expDateMonth"));
			encoder.add(SampleNVPConstants.AddPaymentCard.expirationDateYear,getServletRequest().getParameter("expDateYear"));

			encoder.add(SampleNVPConstants.AddPaymentCard.billingAddressLine1,getServletRequest().getParameter("address1"));
			encoder.add(SampleNVPConstants.AddPaymentCard.billingAddressLine2,getServletRequest().getParameter("address2"));
			encoder.add(SampleNVPConstants.AddPaymentCard.billingAddressCity,getServletRequest().getParameter("city"));
			encoder.add(SampleNVPConstants.AddPaymentCard.billingAddressState,getServletRequest().getParameter("state"));
			encoder.add(SampleNVPConstants.AddPaymentCard.billingAddressPostalCode,getServletRequest().getParameter("zip"));
			encoder.add(SampleNVPConstants.AddPaymentCard.billingAddressCountryCode,getServletRequest().getParameter("countryCode"));

			String confirmationType=getServletRequest().getParameter("confirmationType");
			encoder.add("confirmationType",confirmationType);
			if(confirmationType != null && "NONE".equalsIgnoreCase(confirmationType)){
				  encoder.add(SampleNVPConstants.AddPaymentCard.cardVerificationNumber,getServletRequest().getParameter("cardVerificationNumber"));
				  encoder.add(SampleNVPConstants.AddPaymentCard.createAccountKey,getServletRequest().getParameter("createAccountKey"));
			}else if(confirmationType != null && !"NONE".equalsIgnoreCase(confirmationType)){
				  String returnURL = getContextUrl()+ "/jsp/public/WebflowReturnPage.jsp";
				  String cancelURL = getContextUrl()+ "/jsp/public/Calls.jsp";
				  encoder.add(SampleNVPConstants.AddPaymentCard.webOptionsCancelUrl,cancelURL);
				  encoder.add(SampleNVPConstants.AddPaymentCard.webOptionsReturnUrl,returnURL);
				  encoder.add(SampleNVPConstants.AddPaymentCard.webOptionsCancelUrlDescription,"Cancel URL");
				  encoder.add(SampleNVPConstants.AddPaymentCard.webOptionsReturnUrlDescription,"Return URL");
			  }

			  String request = encoder.encode();
			  String  response = CallerServices.call(request, endPointURL, credentials);
			  decoder.decode(response);
			  String redirectURL=decoder.get("redirectURL");
			  String ack= decoder.get("responseEnvelope.ack");

			if("SUCCESS".equalsIgnoreCase(ack) && (redirectURL != null && redirectURL.length()>0)){
				payLinks.put("redirectURL",redirectURL);
				serverResponse = responseBuilder.createHtmlResponse(decoder,header1,header2,payLinks);
			}else{
				serverResponse=responseBuilder.createHtmlResponse(decoder,header1,header2,null);
			}
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * This will confirm the funding source(bank,creditcard) which was added to your account.
	 * @return
	 */

	public String setFundingSourceConfirmed(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		String apiName = "/AdaptiveAccounts/SetFundingSourceConfirmed";
    	String header1="Set Funding Source Confirmed";
		String header2="";

		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.SetFundingSource.emailAddress,getServletRequest().getParameter("emailID"));
			encoder.add(SampleNVPConstants.SetFundingSource.fundingSourceKey,getServletRequest().getParameter("fundingSourceKey"));
			dispatch(encoder,endPointURL,header1,header2);
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}
	/**
	 *  It will dispatch all API calls to CallerServices.
	 * @param encoder
	 * @param apiName - required to build API end point URL
	 * @param header1 - API header
	 * @param header2 - API header
	 * @throws Exception
	 */
	private void dispatch(Encoder encoder,String endpointURL,String header1,String header2) throws Exception{
		Decoder decoder= SerializeFactory.getInstance().getDecoder();
		ResponseBuilder responseBuilder=new ResponseBuilder();
		String request = encoder.encode();
		String  response = CallerServices.call(request, endpointURL, credentials);
		decoder.decode(response);
		serverResponse= responseBuilder.createHtmlResponse(decoder, header1, header2,null);

    }

	/**
	 * It will create context path for returnURL and cancelURL, required in API calls
	 * @return
	 */
	private String getContextUrl(){
		StringBuilder url = new StringBuilder();
		url.append("http://");
		url.append(getServletRequest().getServerName());
		url.append(":");
		url.append(getServletRequest().getServerPort());
		url.append(getServletRequest().getContextPath());
		return url.toString();
	}
	/**
	 *  It loads properties from default location WEB-INF/config
	 */
	private void loadPropertiesFromDefaultLocation(){
		Properties clientprops = new Properties();
		try {
			InputStream inputStream = ServletActionContext.getServletContext()
					.getResourceAsStream("/WEB-INF/config/paypal_sdk_client.properties");
			clientprops.load(inputStream);
			log.debug("API Credentials :");
			for (Map.Entry<Object, Object> entry : clientprops.entrySet())
			{
				credentials.put(entry.getKey(), entry.getValue());
			    log.debug(entry.getKey() + "/" + entry.getValue());
			}

		}catch (Exception e) {
			log.error("No Property files found or error reading them, fix it to call PayPal APIs", e);
		} 
	}
	
	/**
	 * Generate EndPointURL. 
	 * @param apiName
	 * @return
	 * @throws FatalException
	 */
	private String getEndPointUrl(String apiName)throws FatalException{
		String endPointURL=Constants.EMPTYSTRING;
		if (credentials.containsKey("API_BASE_ENDPOINT")) {
			String endPoint = (String) credentials.get("API_BASE_ENDPOINT");
			if (endPoint == null || endPoint.length() == 0) {
			  throw new FatalException("End point value is blank.");
			}
			endPointURL = endPoint + apiName;
		} else {
			throw new FatalException("End point is not provided.");
		}
		return endPointURL;
	}
	
	/**
	 * Generate Exception Message.
	 * @param FatalException
	 */
	private void generateExceptionMsg(FatalException ex){
	   try{	
		Decoder decoder= SerializeFactory.getInstance().getDecoder();
		ResponseBuilder responseBuilder=new ResponseBuilder();
		String exMsg="FATALExceptionMessage"+"="+ex.getMessage();
		decoder.decode(exMsg);
		String header1="SDK Error Page";
		String header2="";
		serverResponse = responseBuilder.createHtmlResponse(decoder,header1,header2,null);
	   }catch (Exception e) {
		   log.debug("Exception :",e);
	   }
	}
	/**
	 * Get formatted html response to be displayed
	 * @return
	 */
	public String getServerResponse() {
		return serverResponse;
	}
	/**
	 * Set formatted html response to be displayed
	 * @return
	 */
	public void setServerResponse(String serverResponse) {
		this.serverResponse = serverResponse;
	}
}
