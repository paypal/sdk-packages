/*
 * Copyright 2010 PayPal, Inc. All Rights Reserved.
 */

package com.paypal.platform.common;

import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.util.ServletContextAware;

import com.opensymphony.xwork2.ActionSupport;
/**
 * 
 * @author tkanta
 *  It is a base class to be extended by action classes. It provides Request,Response,ServletContext,Session Objects  
 */
public class PlatformBase extends ActionSupport implements ServletRequestAware,
		ServletResponseAware, SessionAware, ServletContextAware {

	private static final long serialVersionUID = 12241241241245L;
	private HttpServletRequest servletRequest;
	private ServletContext servletContext;
	private HttpServletResponse servletResponse;
	private Map session;

	public HttpServletResponse getServletResponse() {
		return servletResponse;
	}

	public void setServletResponse(HttpServletResponse servletResponse) {
		this.servletResponse = servletResponse;
	}

	public ServletContext getServletContext() {
		return servletContext;
	}

	public HttpServletRequest getServletRequest() {
		return servletRequest;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public Map getSession() {
		return session;
	}

	public void setServletContext(ServletContext arg0) {
		this.servletContext = arg0;

	}

	public void setServletRequest(HttpServletRequest servletRequest) {
		this.servletRequest = servletRequest;
	}
}
