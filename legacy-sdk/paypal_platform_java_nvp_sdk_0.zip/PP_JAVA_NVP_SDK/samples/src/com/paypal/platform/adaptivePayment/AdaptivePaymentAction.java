/*
 * Copyright 2010 PayPal, Inc. All Rights Reserved.
 */

package com.paypal.platform.adaptivePayment;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;

import com.paypal.platform.common.PlatformBase;
import com.paypal.platform.common.ResponseBuilder;
import com.paypal.platform.common.SampleNVPConstants;
import com.paypal.platform.sdk.core.CallerServices;
import com.paypal.platform.sdk.core.Constants;
import com.paypal.platform.sdk.core.Decoder;
import com.paypal.platform.sdk.core.Encoder;
import com.paypal.platform.sdk.core.SerializeFactory;
import com.paypal.platform.sdk.exception.FatalException;

/**
 *
 * @author tkanta
 * The Class executes all Adaptive Payment api operation, loads credentials from property files.
 */
public class AdaptivePaymentAction extends PlatformBase {
	private static final long serialVersionUID = 7047317819789938957L;
	private static Log log = LogFactory.getLog(AdaptivePaymentAction.class);
	private String serverResponse = Constants.EMPTYSTRING;
	private Map credentials=new HashMap();

	/**
	 * Loads API credentials from properties file and initialize PayPal Host URI
	 */
	{
			  loadPropertiesFromDefaultLocation();
	}
	
	/**
	 * Pay (Parallel,Chained)
	 * @return
	 */
    public String pay(){
    	Encoder encoder= SerializeFactory.getInstance().getEncoder();
		Decoder decoder= SerializeFactory.getInstance().getDecoder();
    	ResponseBuilder responseBuilder=new ResponseBuilder();
    	String apiName = "/AdaptivePayments/Pay";
    	String header1="Pay";
		String header2="";
		HashMap payLinks=new HashMap();
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			String returnUrl=getContextUrl()+"/jsp/public/WebflowReturnPage.jsp";
			String cancelUrl=getContextUrl()+"/jsp/public/Calls.jsp";
			encoder.add(SampleNVPConstants.Pay.actionType, getServletRequest().getParameter("actionType"));
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.Pay.currencyCode, getServletRequest().getParameter("currencyCode"));
			encoder.add(SampleNVPConstants.Pay.returnUrl,returnUrl);
			encoder.add(SampleNVPConstants.Pay.cancelUrl,cancelUrl);
			
		    String[] receivers = getServletRequest().getParameterValues("receiveremail");
			String[] amounts = getServletRequest().getParameterValues("amount");
			String[] primaryReceivers = getServletRequest().getParameterValues("primaryReceiver");
			
			for(int count=0;count<receivers.length;count++){
				encoder.add("receiverList.receiver["+count+"].email", receivers[count]);
			}
			for(int count=0;count<amounts.length;count++){
				encoder.add("receiverList.receiver["+count+"].amount", amounts[count]);
			}
			for(int count=0;count<primaryReceivers.length;count++){
				encoder.add("receiverList.receiver["+count+"].primary["+count+"]", primaryReceivers[count]);
			}
			
			encoder.add(SampleNVPConstants.Pay.memo, getServletRequest().getParameter("memo"));
			String email=getServletRequest().getParameter("email");
			if(email!=null && !email.equals(""))
			{
			    encoder.add(SampleNVPConstants.Pay.senderEmail, email);
			}   
			encoder.add(SampleNVPConstants.Pay.feesPayer, getServletRequest().getParameter("feesPayer"));

			String preapprovalkey=getServletRequest().getParameter("preapprovalkey");
			if(preapprovalkey != null && preapprovalkey.length()>0){
			 encoder.add(SampleNVPConstants.Pay.preapprovalKey,preapprovalkey);
			}

			String request = encoder.encode();
			String  response = CallerServices.call(request, endPointURL, credentials);
			decoder.decode(response);

			//Condition for Pay flow Link(Create,Set,Execute) to be shown in response page
			String actionType=getServletRequest().getParameter("actionType");
			String paymentExecStatus = decoder.get("paymentExecStatus");
			String ack= decoder.get("responseEnvelope.ack");
			String redirectURL="https://www." +Constants.ENVIRONMENT+ ".paypal.com/cgi-bin/webscr?cmd=_ap-payment&paykey="+decoder.get("payKey");

			if("SUCCESS".equalsIgnoreCase(ack) && "PAY".equalsIgnoreCase(actionType) && "CREATED".equalsIgnoreCase(paymentExecStatus))
			{
				payLinks.put("redirectURL",redirectURL);

			}else if("SUCCESS".equalsIgnoreCase(ack)&& (preapprovalkey != null && preapprovalkey.length()>0) && "CREATE".equalsIgnoreCase(actionType) && "CREATED".equalsIgnoreCase(paymentExecStatus))
			{
				payLinks.put("redirectURL",redirectURL);
				payLinks.put("setPayKey",decoder.get("payKey"));
				payLinks.put("executePayKey",decoder.get("payKey"));
			}else if("SUCCESS".equalsIgnoreCase(ack)&& "CREATE".equalsIgnoreCase(actionType) && "CREATED".equalsIgnoreCase(paymentExecStatus))
			{
				String senderApiEmail=(String)credentials.get("X-PAYPAL-SECURITY-USERID");
				String senderEmail=getServletRequest().getParameter("email");
				String senderApiTruncatedEmail=senderApiEmail.substring(0, senderApiEmail.indexOf("_api"));
				String senderTruncatedEmail=senderEmail.substring(0,senderEmail.indexOf("@"));
				if(senderApiTruncatedEmail.equalsIgnoreCase(senderTruncatedEmail)){
					payLinks.put("redirectURL",redirectURL);
					payLinks.put("setPayKey",decoder.get("payKey"));
					payLinks.put("executePayKey",decoder.get("payKey"));
				}
				payLinks.put("redirectURL",redirectURL);
			}

			serverResponse= responseBuilder.createHtmlResponse(decoder,header1,header2,payLinks);

		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
    	return SUCCESS;
    }

    /**
     *  Get Payment Details
     * @return
     */
	public String paymentDetails() {
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		String apiName = "/AdaptivePayments/PaymentDetails";
		String header1="Payment Details";
		String header2="";
		try {
			String endPointURL=getEndPointUrl(apiName);
			
			String payKey = getServletRequest().getParameter("payKey");
			encoder.add(SampleNVPConstants.PaymentDetails.payKey, payKey);
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");

			dispatch(encoder,endPointURL,header1,header2);
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * Create PreApproval
	 * @return
	 */
	public String preApproval(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		Decoder decoder= SerializeFactory.getInstance().getDecoder();
		ResponseBuilder responseBuilder=new ResponseBuilder();
		String apiName = "/AdaptivePayments/Preapproval";
		String header1="Preapproval";
		String header2="";
		String result="";
		HashMap payLinks=new HashMap();
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			String returnUrl=getContextUrl()+"/jsp/public/WebflowReturnPage.jsp";
			String cancelUrl=getContextUrl()+"/jsp/public/Calls.jsp";
			encoder.add(SampleNVPConstants.Preapproval.returnUrl,returnUrl);
			encoder.add(SampleNVPConstants.Preapproval.cancelUrl,cancelUrl);
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");

			encoder.add(SampleNVPConstants.Preapproval.requestEnvelopeSenderEmail,getServletRequest().getParameter("senderEmail"));
			encoder.add(SampleNVPConstants.Preapproval.startingDate,getServletRequest().getParameter("startingDate"));
			encoder.add(SampleNVPConstants.Preapproval.endingDate,getServletRequest().getParameter("endingDate"));
			encoder.add(SampleNVPConstants.Preapproval.maxNumberOfPayments,getServletRequest().getParameter("maxNumberOfPayments"));
			encoder.add(SampleNVPConstants.Preapproval.maxTotalAmountOfAllPayments,getServletRequest().getParameter("maxTotalAmountOfAllPayments"));
			encoder.add(SampleNVPConstants.Preapproval.currencyCode,getServletRequest().getParameter("currencyCode"));

			String request = encoder.encode();
			String  response = CallerServices.call(request, endPointURL, credentials);
			decoder.decode(response);
			String acknowledge=decoder.get("responseEnvelope.ack");
			if("SUCCESS".equalsIgnoreCase(acknowledge)){
				String redirectURL="https://www."+Constants.ENVIRONMENT+".paypal.com/cgi-bin/webscr?cmd=_ap-preapproval&preapprovalkey="+decoder.get("preapprovalKey");
				payLinks.put("redirectURL",redirectURL);
				serverResponse = responseBuilder.createHtmlResponse(decoder,header1,header2,payLinks);
			}else{
				serverResponse=responseBuilder.createHtmlResponse(decoder,header1,header2,null);
			}
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * Get preApproval Detail
	 * @return
	 */
	public String preApprovalDetail(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		String apiName = "/AdaptivePayments/PreapprovalDetails";
		String header1="Pre Approval Detail";
		String header2="";
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.PreapprovalDetail.preapprovalKey, getServletRequest().getParameter("preapprovalKey"));

			dispatch(encoder,endPointURL,header1,header2);
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return SUCCESS;
	}

	/**
	 * Refund Payment
	 * @return
	 */
	public String refund(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		String apiName = "/AdaptivePayments/Refund";
		String header1="Refund";
		String header2="";
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.Refund.payKey, getServletRequest().getParameter("payKey"));
			encoder.add(SampleNVPConstants.Refund.currencyCode, getServletRequest().getParameter("currencyCode"));
			encoder.add(SampleNVPConstants.Refund.receiverListreceiveremail_0, getServletRequest().getParameter("receiveremail"));
			encoder.add(SampleNVPConstants.Refund.receiverListreceiveramount_0, getServletRequest().getParameter("amount"));

			dispatch(encoder,endPointURL,header1,header2);
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * Cancel PreApproval
	 * @return
	 */
	public String cancelPreapproval(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		String apiName = "/AdaptivePayments/CancelPreapproval";
		String header1="Cancel Preapproval";
		String header2="";
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.CancelPreapproval.preapprovalKey, getServletRequest().getParameter("preapprovalKey"));

			dispatch(encoder,endPointURL,header1,header2);
	    }catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		 return SUCCESS;
	}

	/**
	 * Convert amount from one Currency  to different currencies
	 * @return
	 */
	public String converCurrency(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		String apiName = "/AdaptivePayments/ConvertCurrency";
		String header1="Convert Currency";
		String header2="";
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.SetConvertCurrency.baseAmountListCurrencyAmount_0, getServletRequest().getParameter("baseamount"));
			encoder.add(SampleNVPConstants.SetConvertCurrency.baseAmountListCurrencyCode_0, getServletRequest().getParameter("fromcurrencyCode"));

			encoder.add(SampleNVPConstants.SetConvertCurrency.convertToCurrencyListCurrencyCode_0, getServletRequest().getParameter("tocurrencyCode1"));
			encoder.add(SampleNVPConstants.SetConvertCurrency.convertToCurrencyListCurrencyCode_1, getServletRequest().getParameter("tocurrencyCode2"));
			encoder.add(SampleNVPConstants.SetConvertCurrency.convertToCurrencyListCurrencyCode_2, getServletRequest().getParameter("tocurrencyCode3"));

			dispatch(encoder,endPointURL,header1,header2);
	    }catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return SUCCESS;
	}

	/**
	 * Get Payment option.
	 * @return
	 */
	public String getPaymentOption(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		String apiName = "/AdaptivePayments/GetPaymentOptions";
		String header1="Get PaymentOptions";
		String header2="";
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.GetPaymentOptions.payKey, getServletRequest().getParameter("payKey"));

			dispatch(encoder,endPointURL,header1,header2);
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * Set Payment option for PayKey
	 * @return
	 */
	public String setPaymentOption(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		Decoder decoder= SerializeFactory.getInstance().getDecoder();
		ResponseBuilder responseBuilder=new ResponseBuilder();
		String apiName = "/AdaptivePayments/SetPaymentOptions";
		String header1="Set PaymentOptions";
		String header2="";
		HashMap payLinks=new HashMap();
		String payKey=getServletRequest().getParameter("payKey");
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.SetPaymentOption.payKey, payKey);

			String countryCode=getServletRequest().getParameter("countryCode");
			if(countryCode !=null && countryCode.length()>0){
				encoder.add(SampleNVPConstants.SetPaymentOption.initiatingEntityinstitutionCustomerCountryCode,countryCode);
			}

			String displayName=getServletRequest().getParameter("displayName");
			if(displayName !=null && displayName.length()>0){
				encoder.add(SampleNVPConstants.SetPaymentOption.initiatingEntityinstitutionCustomerDisplayName,displayName);
			}

			String email=getServletRequest().getParameter("email");
			if(email !=null && email.length()>0){
				encoder.add(SampleNVPConstants.SetPaymentOption.initiatingEntityinstitutionCustomerEmail,email);
			}

			String firstName=getServletRequest().getParameter("firstName");
			if(firstName !=null && firstName.length()>0){
				encoder.add(SampleNVPConstants.SetPaymentOption.initiatingEntityinstitutionCustomerFirstName,firstName);
			}

			String lastName=getServletRequest().getParameter("lastName");
			if(lastName !=null && lastName.length()>0){
				encoder.add(SampleNVPConstants.SetPaymentOption.initiatingEntityinstitutionCustomerLastName,lastName);
			}

			String customerId=getServletRequest().getParameter("customerId");
			if(customerId !=null && customerId.length()>0){
				encoder.add(SampleNVPConstants.SetPaymentOption.initiatingEntityinstitutionCustomerinstitutionCustomerId,customerId);
			}

			String institutionId=getServletRequest().getParameter("institutionId");
			if(institutionId !=null && institutionId.length()>0){
				encoder.add(SampleNVPConstants.SetPaymentOption.initiatingEntityinstitutionCustomerInstitutionId,institutionId);
			}

			encoder.add(SampleNVPConstants.SetPaymentOption.payKey, getServletRequest().getParameter("payKey"));
			String headerImage=getServletRequest().getParameter("headerImage");
			if(headerImage !=null && headerImage.length()>0){
				encoder.add(SampleNVPConstants.SetPaymentOption.displayOptionsEmailHeaderImageUrl, getServletRequest().getParameter("headerImage"));
			}
			String marketingImage=getServletRequest().getParameter("marketingImage");
			if(marketingImage != null && marketingImage.length()>0){
				encoder.add(SampleNVPConstants.SetPaymentOption.displayOptionsEmailMarketingImageUrl, getServletRequest().getParameter("marketingImage"));
			}


			String request = encoder.encode();
			String  response = CallerServices.call(request, endPointURL, credentials);
			decoder.decode(response);

			payLinks.put("executePayKey",payKey);
			serverResponse= responseBuilder.createHtmlResponse(decoder,header1,header2,payLinks);
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * Execute Payment for a PayKey
	 * @return
	 */
	public String executePaymentOption(){
		Encoder encoder= SerializeFactory.getInstance().getEncoder();
		String apiName = "/AdaptivePayments/ExecutePayment";
		String header1="Execute PaymentOptions";
		String header2="";
		try{
			String endPointURL=getEndPointUrl(apiName);
			
			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,"en_US");
			encoder.add(SampleNVPConstants.ExecutePayment.payKey, getServletRequest().getParameter("payKey"));

			dispatch(encoder,endPointURL,header1,header2);
		}catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 *  It will dispatch all API calls to CallerServices.
	 * @param encoder
	 * @param apiName - required to build API end point URL
	 * @param header1 - API header
	 * @param header2 - API header
	 * @throws Exception
	 */
	private void dispatch(Encoder encoder,String endPointURL,String header1,String header2) throws Exception{
			Decoder decoder= SerializeFactory.getInstance().getDecoder();
		    ResponseBuilder responseBuilder=new ResponseBuilder();
			String request = encoder.encode();
			String  response = CallerServices.call(request, endPointURL, credentials);
			decoder.decode(response);
			serverResponse= responseBuilder.createHtmlResponse(decoder,header1,header2,null);
			System.out.println(serverResponse);
	}

	/**
	 * It will create context path for returnURL and cancelURL, required in API calls
	 * @return
	 */
	private String getContextUrl(){
		StringBuilder url = new StringBuilder();
		url.append("http://");
		url.append(getServletRequest().getServerName());
		url.append(":");
		url.append(getServletRequest().getServerPort());
		url.append(getServletRequest().getContextPath());
		return url.toString();
	}


	/**
	 *  It loads properties from default location WEB-INF/config
	 */
	private void loadPropertiesFromDefaultLocation(){
		Properties clientprops = new Properties();
		try {
			InputStream inputStream = ServletActionContext.getServletContext()
					.getResourceAsStream("/WEB-INF/config/paypal_sdk_client.properties");
			clientprops.load(inputStream);
			log.debug("API Credentials :");
			for (Map.Entry<Object, Object> entry : clientprops.entrySet())
			{
				credentials.put(entry.getKey(), entry.getValue());
			    log.debug(entry.getKey() + "/" + entry.getValue());
			}

		}catch (Exception e) {
			log.error("No Property files found or error reading them, fix it to call PayPal APIs", e);
		} 
	}

    
	/**
	 * Generate EndPointURL. 
	 * @param apiName
	 * @return
	 * @throws FatalException
	 */
	private String getEndPointUrl(String apiName)throws FatalException{
		String endPointURL=Constants.EMPTYSTRING;
		if (credentials.containsKey("API_BASE_ENDPOINT")) {
			String endPoint = (String) credentials.get("API_BASE_ENDPOINT");
			if (endPoint == null || endPoint.length() == 0) {
			  throw new FatalException("End point value is blank.");
			}
			endPointURL = endPoint + apiName;
		} else {
			throw new FatalException("End point is not provided.");
		}
		return endPointURL;
	}
   
	/**
	 * Generate Exception Message.
	 * @param FatalException
	 */
	private void generateExceptionMsg(FatalException ex){
		   try{	
			Decoder decoder= SerializeFactory.getInstance().getDecoder();
			ResponseBuilder responseBuilder=new ResponseBuilder();
			String exMsg="FATALExceptionMessage"+"="+ex.getMessage();
			decoder.decode(exMsg);
			String header1="SDK Error Page";
			String header2="";
			serverResponse = responseBuilder.createHtmlResponse(decoder,header1,header2,null);
		   }catch (Exception e) {
			   log.debug("Exception :",e);
		   }
		}
	
	/**
	 * Get formatted html response to be displayed
	 * @return
	 */
	public String getServerResponse() {
		return serverResponse;
	}
	/**
	 * Set formatted html response to be displayed
	 * @return
	 */
	public void setServerResponse(String serverResponse) {
		this.serverResponse = serverResponse;
	}

}
