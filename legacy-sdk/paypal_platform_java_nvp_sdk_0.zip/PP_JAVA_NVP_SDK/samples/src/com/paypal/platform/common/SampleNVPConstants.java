/*
 * Copyright 2010 PayPal, Inc. All Rights Reserved.
 */

package com.paypal.platform.common;

public class SampleNVPConstants {
	    public static final String requestEnvelopeErrorLanguage = "requestEnvelope.errorLanguage";
	
	public class CancelPreapproval{
		public static final String preapprovalKey = "preapprovalKey";
	}
	
	public class SetConvertCurrency{
		public static final String baseAmountListCurrencyAmount_0 = "baseAmountList.currency(0).amount";
        public static final String baseAmountListCurrencyCode_0 = "baseAmountList.currency(0).code";
        public static final String convertToCurrencyListCurrencyCode_0 = "convertToCurrencyList.currencyCode(0)";
        public static final String convertToCurrencyListCurrencyCode_1 = "convertToCurrencyList.currencyCode(1)";
        public static final String convertToCurrencyListCurrencyCode_2 = "convertToCurrencyList.currencyCode(2)";
	}
	
	public class ExecutePayment
    {
        public static final String payKey = "payKey";
    }
    public class GetPaymentOptions
    {
        public static final String payKey = "payKey";
    }
    public class Pay
    {
        public static final String payKey = "payKey";
        public static final String actionType = "actionType";
        public static final String currencyCode = "currencyCode";
        public static final String feesPayer = "feesPayer";
        public static final String memo = "memo";
        public static final String receiverListreceiveramount_0 = "receiverList.receiver[0].amount";
        public static final String receiverListreceiveremail_0 = "receiverList.receiver[0].email";
        public static final String receiverListreceiverprimary_0 = "receiverList.receiver[0].primary[0]";
        public static final String receiverListreceiveramount_1 = "receiverList.receiver[1].amount";
        public static final String receiverListreceiveremail_1 = "receiverList.receiver[1].email";
        public static final String receiverListreceiverprimary_1 = "receiverList.receiver[1].primary[1]";
        public static final String senderEmail = "senderEmail";
        public static final String cancelUrl = "cancelUrl";
        public static final String returnUrl = "returnUrl";
        public static final String preapprovalKey = "preapprovalKey";
    }


    public class PaymentDetails
    {
        public static final String payKey = "payKey";
    }


    public class Preapproval
    {
        public static final String currencyCode = "currencyCode";
        public static final String startingDate = "startingDate";
        public static final String endingDate = "endingDate";
        public static final String maxNumberOfPayments = "maxNumberOfPayments";
        public static final String maxTotalAmountOfAllPayments = "maxTotalAmountOfAllPayments";
        public static final String requestEnvelopeSenderEmail = "requestEnvelope.senderEmail";
        public static final String cancelUrl = "cancelUrl";
        public static final String returnUrl = "returnUrl";
    }


    public class PreapprovalDetail
    {
        public static final String preapprovalKey = "preapprovalKey";
    }
    public class Refund
    {
        public static final String payKey = "payKey";
        public static final String currencyCode = "currencyCode";
        public static final String receiverListreceiveremail_0 = "receiverList.receiver[0].email";
        public static final String receiverListreceiveramount_0 = "receiverList.receiver[0].amount";
    }

    public class SetPaymentOption
    {
        public static final String displayOptionsEmailHeaderImageUrl = "displayOptions.emailHeaderImageUrl";
        public static final String displayOptionsEmailMarketingImageUrl = "displayOptions.emailMarketingImageUrl";
        public static final String initiatingEntityinstitutionCustomerCountryCode = "initiatingEntity.institutionCustomer.countryCode";
        public static final String initiatingEntityinstitutionCustomerDisplayName = "initiatingEntity.institutionCustomer.displayName";
        public static final String initiatingEntityinstitutionCustomerEmail = "initiatingEntity.institutionCustomer.email";
        public static final String initiatingEntityinstitutionCustomerFirstName = "initiatingEntity.institutionCustomer.firstName";
        public static final String initiatingEntityinstitutionCustomerLastName = "initiatingEntity.institutionCustomer.lastName";
        public static final String initiatingEntityinstitutionCustomerinstitutionCustomerId = "initiatingEntity.institutionCustomer.institutionCustomerId";
        public static final String initiatingEntityinstitutionCustomerInstitutionId = "initiatingEntity.institutionCustomer.institutionId";
        public static final String payKey = "payKey";
    }


    //AdaptiveAccounts
    public class AddBankAccount
    {
        public static final String bankAccountNumber = "bankAccountNumber";
        public static final String bankAccountType = "bankAccountType";
        public static final String bankCountryCode = "bankCountryCode";
        public static final String bankName = "bankName";
        public static final String confirmationType = "confirmationType";
        public static final String emailAddress = "emailAddress";
        public static final String routingNumber = "routingNumber";
        public static final String webOptionsCancelUrl = "webOptions.cancelUrl";
        public static final String webOptionsCancelUrlDescription = "webOptions.cancelUrlDescription";
        public static final String webOptionsReturnUrl = "webOptions.returnUrl";
        public static final String webOptionsReturnUrlDescription = "webOptions.returnUrlDescription";
        public static final String createAccountKey = "createAccountKey";

    }
    public class AddPaymentCard
    {
        public static final String cardNumber = "cardNumber";
        public static final String cardType = "cardType";
        public static final String confirmationType = "confirmationType";
        public static final String emailAddress = "emailAddress";
        public static final String expirationDateMonth = "expirationDate.month";
        public static final String expirationDateYear = "expirationDate.year";
        public static final String billingAddressLine1 = "billingAddress.line1";
        public static final String billingAddressLine2 = "billingAddress.line2";
        public static final String billingAddressCity = "billingAddress.city";
        public static final String billingAddressState = "billingAddress.state";
        public static final String billingAddressPostalCode = "billingAddress.postalCode";
        public static final String billingAddressCountryCode = "billingAddress.countryCode";
        public static final String nameOnCardFirstName = "nameOnCard.firstName";
        public static final String nameOnCardLastName = "nameOnCard.lastName";
        public static final String webOptionsCancelUrl = "webOptions.cancelUrl";
        public static final String webOptionsCancelUrlDescription = "webOptions.cancelUrlDescription";
        public static final String webOptionsReturnUrl = "webOptions.returnUrl";
        public static final String webOptionsReturnUrlDescription = "webOptions.returnUrlDescription";
        public static final String createAccountKey = "createAccountKey";
        public static final String cardVerificationNumber = "cardVerificationNumber";
    }
    public class CreateAccount
    {
    	public static final String accountType="accountType";
        public static final String addressCity="address.city";
        public static final String addressCountryCode="address.countryCode";
        public static final String addressLine1="address.line1";
        public static final String addressLine2="address.line2";
        public static final String addressPostalCode="address.postalCode";
        public static final String addressState="address.state";
        public static final String citizenshipCountryCode="citizenshipCountryCode";
        public static final String contactPhoneNumber="contactPhoneNumber";
        public static final String currencyCode="currencyCode";
        public static final String dateOfBirth="dateOfBirth";
        public static final String nameFirstName="name.firstName";
        public static final String nameLastName="name.lastName";
        public static final String nameMiddleName="name.middleName";
        public static final String nameSalutation="name.salutation";
        public static final String notificationURL="notificationURL";
        public static final String partnerField1="partnerField1";
        public static final String partnerField2="partnerField2";
        public static final String partnerField3="partnerField3";
        public static final String partnerField4="partnerField4";
        public static final String partnerField5="partnerField5";
        public static final String preferredLanguageCode="preferredLanguageCode";
        public static final String createAccountWebOptionsReturnUrl="createAccountWebOptions.returnUrl";
        public static final String registrationType="registrationType";
        public static final String sandboxEmailAddress="sandboxEmailAddress";
        public static final String emailAddress="emailAddress";
        //For Business Account
        public static final String businessInfoAverageMonthlyVolume="businessInfo.averageMonthlyVolume";
        public static final String businessInfoAveragePrice = "businessInfo.averagePrice";
        public static final String businessInfoBusinessAddressCity = "businessInfo.businessAddress.city";
        public static final String businessInfoBusinessAddressCountryCode = "businessInfo.businessAddress.countryCode";
        public static final String businessInfoBusinessAddressLine1 = "businessInfo.businessAddress.line1";
        public static final String businessInfoBusinessAddressLine2 = "businessInfo.businessAddress.line2";
        public static final String businessInfoBusinessAddressPostalCode = "businessInfo.businessAddress.postalCode";
        public static final String businessInfoBusinessAddressState = "businessInfo.businessAddress.state";
        public static final String businessInfoBusinessName = "businessInfo.businessName";
        public static final String businessInfoBusinessType = "businessInfo.businessType";
        public static final String businessInfoCustomerServiceEmail = "businessInfo.customerServiceEmail";
        public static final String businessInfoCustomerServicePhone = "businessInfo.customerServicePhone";
        public static final String businessInfoDateOfEstablishment = "businessInfo.dateOfEstablishment";
        public static final String businessInfoPercentageRevenueFromOnline = "businessInfo.percentageRevenueFromOnline";
        public static final String businessInfoSalesVenue = "businessInfo.salesVenue";
        public static final String businessInfoCategory = "businessInfo.category";
        public static final String businessInfoSubCategory = "businessInfo.subCategory";
        public static final String businessInfoWebSite = "businessInfo.webSite";
        public static final String businessInfoWorkPhone = "businessInfo.workPhone";
    }
    public class GetVerifiedStatus
    {
        public static final String emailAddress="emailAddress";
        public static final String matchCriteria="matchCriteria";
        public static final String firstName="firstName";
        public static final String lastName = "lastName";
        
    }
    public class SetFundingSource
    {
        public static final String emailAddress="emailAddress";
        public static final String fundingSourceKey = "fundingSourceKey";
    }
    
  //Permissions

    public class RequestPermissions
    {
        public static final String callback = "callback";
        public static final String scope = "scope";


    }
    public class GetAccessToken
    {
        public static final String token = "token";
        public static final String verifier = "verifier";
        public static final String subjectAlias = "subjectAlias";
    }
    public class GetPermissions
    {
        public static final String token = "token";            
    }
    public class CancelPermissions
    {
        public static final String token = "token";            
    }
    public class GetBasicPersonalData{
    public static final String attributeList="attributeList.attribute";
    }
    public class GetAdvancedPersonalData{
        public static final String attributeList="attributeList.attribute";
        }
}
