/*
 * Copyright 2010 PayPal, Inc. All Rights Reserved.
 */

package com.paypal.platform.common;

import java.util.Iterator;
import java.util.Map;

import com.paypal.platform.sdk.core.NVPDecoder;

/**
 * 
 * @author tkanta
 *  It Creates formatted html  for API call response.  
 */
public class ResponseBuilder{
	/**
	 *  Create HTML response for API call Response
	 * @param object -  Response Object
	 * @param header1 - API header
	 * @param header2 - API header
	 *  @param pageLinks - redirect Links
	 * @return
	 */
	public  String createHtmlResponse(Object response, String header1,
			String header2,Map pageLinks)throws Exception
	{
		 
		String header01=header1;
		String header02=header2;
		
		if (response != null)
		{
			NVPDecoder resultValues=null;
			try{
			  resultValues =(NVPDecoder)response;
			}catch(Exception ex){
				throw ex;
			}
			if("Failure".equalsIgnoreCase(resultValues.get("responseEnvelope.ack"))){
			   header01="PayPal API Error";
			   header02="A PayPal API has returned an error!";
		    }
			
			StringBuilder res=new StringBuilder();
			res.append("<center>");

			if (header01 != null)
				res.append("<h3>"+ header01 + "</h3></center>");
				res.append("<br><br>");				

			if (header02 != null)
				res.append("<b><p class='header2'>" + header02 + "</p></b><br/>");				
				res.append("<table width='70%' align='center'>");
            
		    Iterator itr=resultValues.getMap().keySet().iterator();	    
			while(itr.hasNext()){
				String key=(String)itr.next();
				res.append("<tr><td class='thinfield' align='left'> "+ key + ":</td>");
				res.append("<td align='left'>" + resultValues.getMap().get(key).toString() + "</td>");
				res.append("</tr>");				
			}
			res.append("<br/><br/>");
			if(pageLinks !=null && pageLinks.containsKey("redirectURL")){
				res.append("<tr><td class=thinfield colspan=2> <a href="+pageLinks.get("redirectURL")+ "><b>* Redirect URL to Complete the Web Flow </b></a></td></tr>");
			}
			if(pageLinks !=null && pageLinks.containsKey("setPayKey")){
				res.append("<tr><td class=thinfield colspan=2> <a href=SetPaymentOptions.jsp?payKey="+pageLinks.get("setPayKey")+ "><b>* Set Payment Options (optional)</b></a></td></tr>");
			}
			if(pageLinks !=null && pageLinks.containsKey("executePayKey")){
				res.append("<tr><td class=thinfield colspan=2> <a href=ExecutePaymentOption.jsp?payKey="+pageLinks.get("executePayKey")+ "><b>* Execute Payment</b></a></td></tr>");
			}
			res.append("</table>");			
			return res.toString();
		}
		else
		{
			return "Requested action not allowed";
		}

	}

}
