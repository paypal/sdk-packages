package com.paypal.platform.permissions;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;

import com.paypal.platform.common.PlatformBase;
import com.paypal.platform.common.ResponseBuilder;
import com.paypal.platform.common.SampleNVPConstants;

import com.paypal.platform.sdk.core.CallerServices;
import com.paypal.platform.sdk.core.Constants;
import com.paypal.platform.sdk.core.Decoder;
import com.paypal.platform.sdk.core.Encoder;
import com.paypal.platform.sdk.core.SerializeFactory;
import com.paypal.platform.sdk.exception.FatalException;

public class PermissionAction extends PlatformBase {

	private static final long serialVersionUID = 7047311236774238957L;
	private static Log log = LogFactory.getLog(PermissionAction.class);
	private String serverResponse = Constants.EMPTYSTRING;
	private Map credentials = new HashMap();

	/**
	 * Loads API credentials from properties file and initialize PayPal Host URI
	 */
	{
		loadPropertiesFromDefaultLocation();
	}

	/**
	 * Request Permission for API's
	 * 
	 * @return
	 */
	public String requestPermission() {
		Encoder encoder = SerializeFactory.getInstance().getEncoder();
		Decoder decoder = SerializeFactory.getInstance().getDecoder();
		ResponseBuilder responseBuilder = new ResponseBuilder();
		String apiName = "/Permissions/RequestPermissions";
		String header1 = "Permissions";
		String header2 = "RequestPermission";
		HashMap payLinks = new HashMap();
		try {
			String endPointURL = getEndPointUrl(apiName);

			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,
					"en_US");
			encoder.add(SampleNVPConstants.RequestPermissions.callback,
					getServletRequest().getParameter("callback"));
			String select[] = getServletRequest().getParameterValues("api");
			if (select != null && select.length != 0) {
				for (int i = 0; i < select.length; i++) {
					encoder.add(SampleNVPConstants.RequestPermissions.scope
							+ "(" + i + ")", select[i]);
				}
			}
			String request = encoder.encode();
			String response = CallerServices.call(request, endPointURL,
					credentials);
			decoder.decode(response);
			String acknowledge = decoder.get("responseEnvelope.ack");

			if ("SUCCESS".equalsIgnoreCase(acknowledge)) {
				String redirectURL = "https://www."
						+ Constants.ENVIRONMENT
						+ ".paypal.com/cgi-bin/webscr?cmd=_grant-permission&request_token="
						+ decoder.get("token");
				payLinks.put("redirectURL", redirectURL);
				serverResponse = responseBuilder.createHtmlResponse(decoder,
						header1, header2, payLinks);
			} else {
				serverResponse = responseBuilder.createHtmlResponse(decoder,
						header1, header2, null);
			}
		} catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * Get Access Token for API permission
	 * 
	 * @return
	 */

	public String getAccessToken() {
		Encoder encoder = SerializeFactory.getInstance().getEncoder();
		String apiName = "/Permissions/GetAccessToken";
		String header1 = "Permissions";
		String header2 = "GetAccessToken";
		try {
			String endPointURL = getEndPointUrl(apiName);

			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,
					"en_US");

			encoder.add(SampleNVPConstants.GetAccessToken.token,
					getServletRequest().getParameter("token"));
			encoder.add(SampleNVPConstants.GetAccessToken.verifier,
					getServletRequest().getParameter("verifier"));
			// encoder.add(SampleNVPConstants.GetAccessToken.subjectAlias,getServletRequest().getParameter("subjectAlias"));

			dispatch(encoder, endPointURL, header1, header2);
		} catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * Get API whose permission has granted
	 * 
	 * @return
	 */

	public String getPermission() {
		Encoder encoder = SerializeFactory.getInstance().getEncoder();
		String apiName = "/Permissions/GetPermissions";
		String header1 = "Permissions";
		String header2 = "GetPermissions";
		try {
			String endPointURL = getEndPointUrl(apiName);

			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,
					"en_US");
			encoder.add(SampleNVPConstants.GetPermissions.token,
					getServletRequest().getParameter("token"));

			dispatch(encoder, endPointURL, header1, header2);
		} catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	/**
	 * Cancel API permission
	 * 
	 * @return
	 */

	public String cancelPermission() {
		Encoder encoder = SerializeFactory.getInstance().getEncoder();
		String apiName = "/Permissions/CancelPermissions";
		String header1 = "Permissions";
		String header2 = "CancelPermissions";
		try {
			String endPointURL = getEndPointUrl(apiName);

			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,
					"en_US");
			encoder.add(SampleNVPConstants.CancelPermissions.token,
					getServletRequest().getParameter("token"));

			dispatch(encoder, endPointURL, header1, header2);
		} catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}

	public String getBasicPersonalData() {
		Encoder encoder = SerializeFactory.getInstance().getEncoder();
		Decoder decoder = SerializeFactory.getInstance().getDecoder();
		ResponseBuilder responseBuilder = new ResponseBuilder();
		String apiName = "/Permissions/GetBasicPersonalData";
		String header1 = "Permissions";
		String header2 = "GetBasicPersonalData";
		HashMap payLinks = new HashMap();
		try {
			String endPointURL = getEndPointUrl(apiName);

			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,
					"en_US");

			String select[] = getServletRequest().getParameterValues("attr");
			if (select != null && select.length != 0) {
				for (int i = 0; i < select.length; i++) {
					encoder.add(SampleNVPConstants.GetBasicPersonalData.attributeList
							+ "(" + i + ")", select[i]);
				}
			}
			String request = encoder.encode();
			String response = CallerServices.call(request, endPointURL,
					credentials);
			decoder.decode(response);
			String acknowledge = decoder.get("responseEnvelope.ack");

			if ("SUCCESS".equalsIgnoreCase(acknowledge)) {

				serverResponse = responseBuilder.createHtmlResponse(decoder,
						header1, header2, payLinks);
			} else {
				serverResponse = responseBuilder.createHtmlResponse(decoder,
						header1, header2, null);
			}
		} catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}
	
	public String getAdvancedPersonalData() {
		Encoder encoder = SerializeFactory.getInstance().getEncoder();
		Decoder decoder = SerializeFactory.getInstance().getDecoder();
		ResponseBuilder responseBuilder = new ResponseBuilder();
		String apiName = "/Permissions/GetAdvancedPersonalData";
		String header1 = "Permissions";
		String header2 = "GetAdvancedPersonalData";
		HashMap payLinks = new HashMap();
		try {
			String endPointURL = getEndPointUrl(apiName);

			encoder.add(SampleNVPConstants.requestEnvelopeErrorLanguage,
					"en_US");

			String select[] = getServletRequest().getParameterValues("attr");
			if (select != null && select.length != 0) {
				for (int i = 0; i < select.length; i++) {
					encoder.add(SampleNVPConstants.GetAdvancedPersonalData.attributeList
							+ "(" + i + ")", select[i]);
				}
			}
			String request = encoder.encode();
			String response = CallerServices.call(request, endPointURL,
					credentials);
			decoder.decode(response);
			String acknowledge = decoder.get("responseEnvelope.ack");

			if ("SUCCESS".equalsIgnoreCase(acknowledge)) {

				serverResponse = responseBuilder.createHtmlResponse(decoder,
						header1, header2, payLinks);
			} else {
				serverResponse = responseBuilder.createHtmlResponse(decoder,
						header1, header2, null);
			}
		} catch (FatalException fx) {
			generateExceptionMsg(fx);
			log.error(fx.getMessage(), fx);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return SUCCESS;
	}


	/**
	 * It will dispatch all API calls to CallerServices.
	 * 
	 * @param encoder
	 * @param apiName
	 *            - required to build API end point URL
	 * @param header1
	 *            - API header
	 * @param header2
	 *            - API header
	 * @throws Exception
	 */
	private void dispatch(Encoder encoder, String endPointURL, String header1,
			String header2) throws Exception {
		Decoder decoder = SerializeFactory.getInstance().getDecoder();
		ResponseBuilder responseBuilder = new ResponseBuilder();
		String request = encoder.encode();
		String response = CallerServices
				.call(request, endPointURL, credentials);
		decoder.decode(response);
		serverResponse = responseBuilder.createHtmlResponse(decoder, header1,
				header2, null);
	}

	/**
	 * Generate Exception Message.
	 * 
	 * @param FatalException
	 */
	private void generateExceptionMsg(FatalException ex) {
		try {
			Decoder decoder = SerializeFactory.getInstance().getDecoder();
			ResponseBuilder responseBuilder = new ResponseBuilder();
			String exMsg = "FATALExceptionMessage" + "=" + ex.getMessage();
			decoder.decode(exMsg);
			String header1 = "SDK Error Page";
			String header2 = "";
			serverResponse = responseBuilder.createHtmlResponse(decoder,
					header1, header2, null);
		} catch (Exception e) {
			log.debug("Exception :", e);
		}
	}

	/**
	 * Generate EndPointURL.
	 * 
	 * @param apiName
	 * @return
	 * @throws FatalException
	 */
	private String getEndPointUrl(String apiName) throws FatalException {
		String endPointURL = Constants.EMPTYSTRING;
		if (credentials.containsKey("API_BASE_ENDPOINT")) {
			String endPoint = (String) credentials.get("API_BASE_ENDPOINT");
			if (endPoint == null || endPoint.length() == 0) {
				throw new FatalException("End point value is blank.");
			}
			endPointURL = endPoint + apiName;
		} else {
			throw new FatalException("End point is not provided.");
		}
		return endPointURL;
	}

	/**
	 * It will create context path for returnURL and cancelURL, required in API
	 * calls
	 * 
	 * @return
	 */
	private String getContextUrl() {
		StringBuilder url = new StringBuilder();
		url.append("http://");
		url.append(getServletRequest().getServerName());
		url.append(":");
		url.append(getServletRequest().getServerPort());
		url.append(getServletRequest().getContextPath());
		return url.toString();
	}

	/**
	 * It loads properties from default location WEB-INF/config
	 */
	private void loadPropertiesFromDefaultLocation() {
		Properties clientprops = new Properties();
		try {
			InputStream inputStream = ServletActionContext.getServletContext()
					.getResourceAsStream(
							"/WEB-INF/config/paypal_sdk_client.properties");
			clientprops.load(inputStream);
			log.debug("API Credentials :");
			for (Map.Entry<Object, Object> entry : clientprops.entrySet()) {
				credentials.put(entry.getKey(), entry.getValue());
				log.debug(entry.getKey() + "/" + entry.getValue());
			}

		} catch (Exception e) {
			log.error(
					"No Property files found or error reading them, fix it to call PayPal APIs",
					e);
		}
	}

	/**
	 * Get formatted html response to be displayed
	 * 
	 * @return
	 */
	public String getServerResponse() {
		return serverResponse;
	}

	/**
	 * Set formatted html response to be displayed
	 * 
	 * @return
	 */
	public void setServerResponse(String serverResponse) {
		this.serverResponse = serverResponse;
	}

}
