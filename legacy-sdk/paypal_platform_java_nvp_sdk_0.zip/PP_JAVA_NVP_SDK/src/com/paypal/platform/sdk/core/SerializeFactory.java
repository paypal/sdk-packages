package com.paypal.platform.sdk.core;

public class SerializeFactory {
    private static SerializeFactory serialize=null;
    
    private SerializeFactory(){
    	
    }
    public static SerializeFactory getInstance() {
		if (serialize == null) {
			synchronized (SerializeFactory.class) {
				serialize = new SerializeFactory();
			}
		}
		return serialize;
	}
    
    public Encoder getEncoder(){
           return new NVPEncoder();
    }
    
    public Decoder getDecoder(){
           return new NVPDecoder();
    }
    
	
}
