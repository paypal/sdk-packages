/*
 * Copyright 2010 PayPal, Inc. All Rights Reserved.
 */

package com.paypal.platform.sdk.core;

public class Constants {
    public static final String ENVIRONMENT="sandbox";
    public static final String EMPTYSTRING="";
    public static final String XPAYPALSOURCE = "JAVA_NVP_SDK_V1.1";
    public static final String XPAYPAL_REQUEST_DATAFORMAT = "X-PAYPAL-REQUEST-DATA-FORMAT";
    public static final String XPAYPAL_RESPONSE_DATAFORMAT = "X-PAYPAL-RESPONSE-DATA-FORMAT";
    public static final String XPAY_FORMAT = "NV";
    
    //ERROR Constants
    public static final String REQUEST_STRING = "Request string can't be empty. ";
    public static final String END_POINT = "End point can't be empty. ";
    public static final String HEADERS = "Headers can't be empty. ";
}
