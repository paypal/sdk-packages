package com.paypal.platform.sdk.core;

import com.paypal.platform.sdk.exception.PayPalException;

public interface Encoder {
	/**
	 * Encoding type
	 */
    String ENCODE_TYPE = "UTF-8";
   
    void add(String name, String value);
    
    void remove(String name);
    
    void clear();
    
    String encode() throws PayPalException;
    
}