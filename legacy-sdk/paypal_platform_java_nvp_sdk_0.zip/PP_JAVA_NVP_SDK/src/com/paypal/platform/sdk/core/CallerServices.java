/*
 * Copyright 2010 PayPal, Inc. All Rights Reserved.
 */

package com.paypal.platform.sdk.core;

import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.util.EntityUtils;

import com.paypal.platform.sdk.exception.FatalException;

public class CallerServices {
	private static Log log = LogFactory.getLog(CallerServices.class);

	/**
	 * This method invokes all the API calls depending on the request string
	 * sent in as parameter in this method which has to be in NVP format.
	 * 
	 * @param payload
	 *            Payload String
	 * @param apiName
	 *            apiname to construct Endpoint URL
	 * @param credentials
	 * @return
	 * @throws FatalException
	 */
	public static synchronized String call(String payload, String endPointURL,
			Map credentials) throws FatalException {
		HttpEntity entity = null;
		String response = Constants.EMPTYSTRING;
		try {
			validate(payload, endPointURL, credentials);
			Map credentialClone = new HashMap(credentials);
			log.debug("End Point URL : " + endPointURL);
			log.debug(credentialClone.get("X-PAYPAL-REQUEST-DATA-FORMAT")
					+ " request : " + payload.toString());
			SSLSocketFactory socketFactory = null;
			socketFactory = SSLSocketFactory.getSocketFactory();
			socketFactory.setHostnameVerifier(SSLSocketFactory.STRICT_HOSTNAME_VERIFIER);
			URL url = new URL(endPointURL);
			HttpHost target = new HttpHost(url.getHost(),
					(url.getPort() != -1) ? url.getPort() : 443, "https");
			SchemeRegistry supportedSchemes = new SchemeRegistry();

			// required by the default operator to look up socket factories.
			supportedSchemes.register(new Scheme("https", socketFactory, (url
					.getPort() != -1) ? url.getPort() : 443));

			// prepare parameters
			HttpParams params = new BasicHttpParams();
			HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
			HttpProtocolParams.setContentCharset(params, "UTF-8");
			HttpProtocolParams.setUseExpectContinue(params, true);
			ClientConnectionManager ccm = new ThreadSafeClientConnManager(
					params, supportedSchemes);
			DefaultHttpClient httpclient = new DefaultHttpClient(ccm, params);
			HttpPost req = new HttpPost(url.toString());
			HttpEntity reqEntity = new StringEntity(payload, "UTF-8");
			req.setEntity(reqEntity);
			addHeaders(req, credentialClone);
			HttpResponse rsp = httpclient.execute(target, req);
			int statusCode = rsp.getStatusLine().getStatusCode();
			if (statusCode != 200) {
				throw new FatalException("HTTP Error code " + statusCode
						+ " received, transaction not submitted");
			}
			entity = rsp.getEntity();
			response = EntityUtils.toString(entity);
			log.debug(credentialClone.get("X-PAYPAL-RESPONSE-DATA-FORMAT")
					+ " response : " + response.toString());
		} catch (FatalException fx) {
			throw fx;
		} catch (Exception e) {
			throw new FatalException(e.getMessage(), e);
		}
		return response;
	}

	/**
	 * Add API Credentials as HTTP Post Header
	 * 
	 * @param httppost
	 * @param credentials
	 */
	private static void addHeaders(HttpPost httppost, Map credentials) {
		if (credentials.containsKey("X-PAYPAL-REQUEST-SOURCE")) {
			String value = (String) credentials.get("X-PAYPAL-REQUEST-SOURCE");
			String newValue = Constants.EMPTYSTRING;
			if (value != null && value.length() > 0) {
				newValue = Constants.XPAYPALSOURCE + "-" + value;
				credentials.put("X-PAYPAL-REQUEST-SOURCE", newValue);
			} else {
				credentials.put("X-PAYPAL-REQUEST-SOURCE",
						Constants.XPAYPALSOURCE);
			}
		} else {
			credentials.put("X-PAYPAL-REQUEST-SOURCE", Constants.XPAYPALSOURCE);
		}

		if (credentials.containsKey(Constants.XPAYPAL_REQUEST_DATAFORMAT)) {
			String value = (String) credentials
					.get(Constants.XPAYPAL_REQUEST_DATAFORMAT);
			if (value == null && value.length() == 0) {
				credentials.put(Constants.XPAYPAL_REQUEST_DATAFORMAT,
						Constants.XPAY_FORMAT);
			}
		} else {
			credentials.put(Constants.XPAYPAL_REQUEST_DATAFORMAT,
					Constants.XPAY_FORMAT);
		}

		if (credentials.containsKey(Constants.XPAYPAL_RESPONSE_DATAFORMAT)) {
			String value = (String) credentials
					.get(Constants.XPAYPAL_RESPONSE_DATAFORMAT);
			if (value == null && value.length() == 0) {
				credentials.put(Constants.XPAYPAL_RESPONSE_DATAFORMAT,
						Constants.XPAY_FORMAT);
			}
		} else {
			credentials.put(Constants.XPAYPAL_RESPONSE_DATAFORMAT,
					Constants.XPAY_FORMAT);
		}
		Iterator itr = credentials.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry pairs = (Map.Entry) itr.next();
			String key = (String) pairs.getKey();
			String value = (String) pairs.getValue();
			httppost.addHeader(key, value);
		}
	}

	private static void validate(String payload, String endPointURL,
			Map credentials) throws FatalException {
		boolean exception = false;
		String errors = Constants.EMPTYSTRING;
		if (payload == null || payload.length() == 0) {
			exception = true;
			errors = errors + Constants.REQUEST_STRING;
		}
		if (endPointURL == null || endPointURL.length() == 0) {
			exception = true;
			errors = errors + Constants.END_POINT;
		}
		if (credentials == null || credentials.size() == 0) {
			exception = true;
			errors = errors + Constants.HEADERS;
		}

		if (exception) {
			throw new FatalException(errors);
		}
	}
}
