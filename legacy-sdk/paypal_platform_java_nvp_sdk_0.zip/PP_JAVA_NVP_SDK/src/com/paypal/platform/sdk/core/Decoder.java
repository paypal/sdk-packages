package com.paypal.platform.sdk.core;

import java.util.Map;

import com.paypal.platform.sdk.exception.PayPalException;

public interface Decoder {
	/**
	 * Encoding type
	 */
    String ENCODE_TYPE = "UTF-8";
    
    String get(String pName);
    
    Map getMap();
    
    void decode(String payload) throws PayPalException;
}
