module AdaptivePaymentsSamples
  VERSION = "1.100.0"
end
