module AdaptivePaymentsSamples
  module AdaptivePaymentsHelper
  end
end
