module AdaptivePaymentsSamples
  VERSION = "1.110.0"
end
