require "paypal-sdk/adaptive_payments"

