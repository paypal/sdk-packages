module PayPal
  module SDK
    module AdaptivePayments
      VERSION = "1.110.0"
    end
  end
end
