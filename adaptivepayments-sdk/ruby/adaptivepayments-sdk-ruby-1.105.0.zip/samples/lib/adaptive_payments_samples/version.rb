module AdaptivePaymentsSamples
  VERSION = "1.105.0"
end
