require "paypal-sdk-adaptivepayments"
require "adaptive_payments_samples/engine"
require "simple_form"
require "haml"
require "twitter-bootstrap-rails"
require "coderay"
require "jquery-rails"

module AdaptivePaymentsSamples
end
