Install gem:

    gem install gem/paypal-sdk-core-0.1.2.gem
    gem install gem/paypal-sdk-adaptivepayments-1.96.2.gem
	
    #To try samples
    gem install gem/adaptive_payments_samples-1.96.2.gem
	
Add library to you project `Gemfile`:

    gem 'paypal-sdk-adaptivepayments'

    #To try samples
    gem 'adaptive_payments_samples', :group => :development

Generate configuration in rails application:

    rails g paypal:sdk:install

Configure routes(`config/routes.rb`) for access samples:

    mount AdaptivePaymentsSamples::Engine => "/samples" if Rails.env.development?
