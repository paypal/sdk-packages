module AdaptivePaymentsSamples
  VERSION = "1.96.2"
end
