The repository contains the PayPal Adaptive Payments SDK C#.NET Class Library Application and the AdaptivePaymentsSampleApp Sample ASP.NET C# Web Application.


SDK Integration
---------------
*	Integrate the PayPal Adaptive Payments SDK with an ASP.NET Web Application

*	Use NuGet to install the 'PayPalAdaptivePaymentsSDK' package 

*	The NuGet package installs the dependencies to the solution and automatically updates the project

*	Dependent library references:
	�	'log4net.dll'
	�	'PayPalCoreSDK.dll'	
	�	'PayPalAdaptivePaymentsSDK.dll'

*	Namespaces:
	�	PayPal
	�	PayPal.AdaptivePayments
	�	PayPal.AdaptivePayments.Model
	�	PayPal.Util
	�	PayPal.Exception

	
Help
----
*	AdaptivePayments.bat - Automation script that builds the PayPal Adaptive Payments SDK C#.NET Class Library Application in release mode and copies the built dlls to the lib folder in the AdaptivePaymentsSampleApp Sample ASP.NET C# Web Application

*	Changelog.txt - Release Notes

*	DotNetSDK.SandcastleGUI - Tool to create the documentation of the PayPal Adaptive Payments SDK

*	LICENSE.txt - PayPal, Inc. SDK License

