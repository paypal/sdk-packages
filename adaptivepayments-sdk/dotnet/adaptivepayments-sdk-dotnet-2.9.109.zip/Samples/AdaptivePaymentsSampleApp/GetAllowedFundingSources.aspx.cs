using System;

namespace AdaptivePaymentsSampleApp
{
    public partial class GetAllowedFundingSources : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
