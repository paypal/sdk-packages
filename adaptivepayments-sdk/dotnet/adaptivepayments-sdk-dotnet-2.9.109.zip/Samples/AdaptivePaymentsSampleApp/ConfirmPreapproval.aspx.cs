using System;

namespace AdaptivePaymentsSampleApp
{
    public partial class ConfirmPreapproval : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
