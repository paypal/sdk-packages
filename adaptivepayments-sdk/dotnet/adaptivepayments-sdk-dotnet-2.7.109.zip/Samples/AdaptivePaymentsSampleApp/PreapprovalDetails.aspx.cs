using System;

namespace AdaptivePaymentsSampleApp
{
    public partial class PreapprovalDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
