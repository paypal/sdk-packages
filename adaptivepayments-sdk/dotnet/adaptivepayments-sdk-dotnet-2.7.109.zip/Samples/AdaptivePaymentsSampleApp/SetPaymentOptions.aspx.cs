using System;

namespace AdaptivePaymentsSampleApp
{
    public partial class SetPaymentOptions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
