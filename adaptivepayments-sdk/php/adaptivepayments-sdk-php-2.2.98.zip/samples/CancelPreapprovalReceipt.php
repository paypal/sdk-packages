<?php
require_once('PPBootStrap.php');

$logger = new PPLoggingManager('CancelPreapproval');

// create request
$requestEnvelope = new RequestEnvelope("en_US");
$cancelPreapprovalReq = new CancelPreapprovalRequest($requestEnvelope, $_POST['preapprovalKey']);
$logger->log("Created CancelPreapprovalRequest Object");


$service = new AdaptivePaymentsService();
try {
	$response = $service->CancelPreapproval($cancelPreapprovalReq);
} catch(Exception $ex) {
	require_once 'Common/Error.php';
	exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>PayPal Adaptive Payments - Cancel Preapproval</title>
<link href="Common/sdk.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="Common/sdk_functions.js"></script>
</head>

<body>
<div id="wrapper">
<div id="response_form">
<h3>Cancel Preapproval</h3>
<?php
$logger->error("Received CancelPreapprovalResponse:");
$ack = strtoupper($response->responseEnvelope->ack);
if($ack != "SUCCESS"){
	echo "<b>Error </b>";
	echo "<pre>";
	print_r($response);
	echo "</pre>";
} else {
	echo "<pre>";
	print_r($response);
	echo "</pre>";
	echo "</pre>";
	echo "<table>";
	echo "<tr><td>Ack :</td><td><div id='Ack'>$ack</div> </td></tr>";
	echo "</table>";
}
require_once 'Common/Response.php';
?></div>
</div>
</body>
</html>