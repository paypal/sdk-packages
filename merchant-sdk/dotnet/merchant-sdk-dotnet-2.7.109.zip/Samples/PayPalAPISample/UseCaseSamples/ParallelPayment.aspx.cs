﻿using System;

namespace PayPalAPISample.UseCaseSamples
{
    public partial class ParallelPayment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}