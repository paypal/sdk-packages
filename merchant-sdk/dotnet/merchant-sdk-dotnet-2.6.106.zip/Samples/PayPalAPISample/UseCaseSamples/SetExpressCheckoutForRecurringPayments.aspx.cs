﻿using System;
using System.Collections.Generic;
using System.Web;
using PayPal.PayPalAPIInterfaceService.Model;
using PayPal.PayPalAPIInterfaceService;

namespace PayPalAPISample.UseCaseSamples
{
    public partial class SetExpressCheckoutForRecurringPayments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }       
    }
}