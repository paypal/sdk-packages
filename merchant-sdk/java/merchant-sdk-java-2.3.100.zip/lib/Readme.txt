This folder contains jar files for,
		
	1. SDK	
	2. PayPal Core library
	4. Commons-Codec