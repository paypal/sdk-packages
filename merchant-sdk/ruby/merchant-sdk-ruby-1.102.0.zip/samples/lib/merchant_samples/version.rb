module MerchantSamples
  VERSION = "1.102.0"
end
