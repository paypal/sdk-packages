module MerchantSamples
  module MerchantHelper
  end
end
