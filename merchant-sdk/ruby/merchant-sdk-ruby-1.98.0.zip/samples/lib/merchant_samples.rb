require "paypal-sdk-merchant"
require "merchant_samples/engine"
require "simple_form"
require "haml"
require "twitter-bootstrap-rails"
require "coderay"
require "jquery-rails"

module MerchantSamples
end
