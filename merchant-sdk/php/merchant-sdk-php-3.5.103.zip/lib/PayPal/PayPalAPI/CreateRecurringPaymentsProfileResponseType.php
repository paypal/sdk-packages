<?php 
namespace PayPal\PayPalAPI;
use PayPal\EBLBaseComponents\AbstractResponseType; 
/**
 * 
 */
class CreateRecurringPaymentsProfileResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var PayPal\EBLBaseComponents\CreateRecurringPaymentsProfileResponseDetailsType	 
	 */ 
	public $CreateRecurringPaymentsProfileResponseDetails;


}
