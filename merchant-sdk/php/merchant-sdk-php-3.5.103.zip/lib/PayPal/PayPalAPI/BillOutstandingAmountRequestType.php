<?php 
namespace PayPal\PayPalAPI;
use PayPal\EBLBaseComponents\AbstractRequestType; 
/**
 * 
 */
class BillOutstandingAmountRequestType  extends AbstractRequestType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var PayPal\EBLBaseComponents\BillOutstandingAmountRequestDetailsType	 
	 */ 
	public $BillOutstandingAmountRequestDetails;


   
}
