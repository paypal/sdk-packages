<?php 
namespace PayPal\PayPalAPI;
use PayPal\EBLBaseComponents\AbstractResponseType; 
/**
 * 
 */
class CompleteRecoupResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ed
	 
	 	 	 	 
	 * @var PayPal\EnhancedDataTypes\EnhancedCompleteRecoupResponseDetailsType	 
	 */ 
	public $EnhancedCompleteRecoupResponseDetails;


}
