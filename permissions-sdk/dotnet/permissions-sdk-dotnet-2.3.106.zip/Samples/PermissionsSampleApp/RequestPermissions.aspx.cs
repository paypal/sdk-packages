using System;

namespace PermissionsSampleApp
{
    public partial class RequestPermissions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
