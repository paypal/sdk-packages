Install gem:

    gem install gem/paypal-sdk-core-0.1.2.gem
    gem install gem/paypal-sdk-permissions-1.96.1.gem
	
    #To try samples
    gem install gem/permissions_samples-1.96.1.gem
	
Add library to you project `Gemfile`:

    gem 'paypal-sdk-permissions'

    #To try samples
    gem 'permissions_samples', :group => :development

Generate configuration in rails application:

    rails g paypal:sdk:install

Configure routes(`config/routes.rb`) for access samples:

    mount PermissionsSamples::Engine => "/samples" if Rails.env.development?
