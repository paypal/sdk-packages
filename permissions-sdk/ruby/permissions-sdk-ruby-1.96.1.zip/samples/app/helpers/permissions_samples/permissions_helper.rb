module PermissionsSamples
  module PermissionsHelper
  end
end
