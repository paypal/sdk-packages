require "paypal-sdk-permissions"
require "permissions_samples/engine"
require "simple_form"
require "haml"
# require "less-rails"
# require "therubyracer"
require "twitter-bootstrap-rails"
require "coderay"
require "jquery-rails"

module PermissionsSamples
end
