# Permissions Samples

