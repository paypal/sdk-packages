<?php 
namespace PayPal\Types\Perm;
use PayPal\Core\PPMessage;  
/**
 * List of Personal Attributes to be sent as a request. 
 */
class PersonalAttributeList  
  extends PPMessage   {

	/**
	 * 
     * @array
	 * @access public
	 
	 	 	 	 
	 * @var string 	 
	 */ 
	public $attribute;


}
