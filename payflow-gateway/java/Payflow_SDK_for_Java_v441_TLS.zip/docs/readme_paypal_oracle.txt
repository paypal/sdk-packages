To test java application standalone on windows:
==================================

steps:

1.  download and extract 'Java SDK for Payflow Pro' from the following link 

    https://www.paypal.com/IntegrationCenter/ic_downloads.html#PayflowPro

2.  Locate and modify sample file 'DOSaleComplete.java' in the samples\paypal\samples\dataobjects\basictransactions folder
    
    //confirm this is correct 
    SDKProperties.setHostAddress("pilot-payflowpro.paypal.com");

    //set these for your paypal account    
    UserInfo user = new UserInfo("<user>", "<vendor>", "<Partner>", "<Password>");

    // Set timeout accordingly
    SDKProperties.setTimeOut(30);

    // UNcomment these lines and set proxy details if necessary
    SDKProperties.setProxyAddress("<proxy host here>");
    SDKProperties.setProxyPort(<proxy server port>);

3.  locate and modify the payflow_test batch file: 

    change references of DOCapture to DOSaleComplete

4.  run the batch file and you should get the following result (should get a Transaction ID):

        Result Code (RESULT) = 0
        Transaction ID (PNREF) = V18E0CC9A143
        Response Message (RESPMSG) = Approved
        Authorization (AUTHCODE) = 010101
        Street Address Match (AVSADDR) = Y
        Streep Zip Match (AVSZIP) = Y
        International Card (IAVS) = N
        CVV2 Match (CVV2MATCH) = Y
        ------------------------------------------------------
        Verbosity Response:
        Processor AVS (PROCAVS) = Y
        Processor CSC (PROCCVV2) = X
        Fraud Response:
        Pre-Filters (PREFPSMSG) = null
        Post-Filters (POSTFPSMSG) = null
        ------------------------------------------------------
        Duplicate Response:
        Duplicate Transaction (DUPLICATE) = Not a Duplicate Transaction
        ------------------------------------------------------
        User/System Response:
        User Message (RESPMSG) = Your transaction was approved. Will ship in 24 hours.
        System Message (TRXNRESPONSE.RESPMSG) = Approved
        ------------------------------------------------------
        Overall Transaction Status: Transaction Successful.
        ------------------------------------------------------
        Press Enter to Exit ...
        Press any key to continue . . .



To test as java stored procedure in 10.2.0.3. database on Solaris:   
============================================================

1.  load the \lib\Payflow.jar  file into the database

    loadjava -u scott/tiger -r -v -f -s -grant public -genmissing payflow.jar

2. Make a copy of the DOSaleComplete.java as PayPalTest.java and then change it to load from the database.

< package paypal.payments.samples.dataobjects.basictransactions;
---
> //package paypal.payments.samples.dataobjects.basictransactions;


< public class DOSaleComplete {
<     public DOSaleComplete() {
<     }
---
> public class PayPalTest {
>  //   public DOSaleComplete() {
>  //   }


<     public static void main(String args[]) {
---
>     public static String PaypalTest() {


<   SDKProperties.setLogFileName("payflow_java.log");
--
> //SDKProperties.setLogFileName("payflow_java.log");


3.  Compile PayPalTest.java

    javac PayPalTest.java 


4.  load the PayPalTest.class file into the database

    loadjava -u scott/tiger -r PayPalTest.class


5.  create the following plsql wrapper function

    CREATE or REPLACE FUNCTION PAYPAL_TEST_FUNC
          RETURN VARCHAR2 AS LANGUAGE JAVA
          NAME 'PayPalTest.PayPalTest() return java.lang.String';

6.  connect as sys and grant the following privs to scott

    exec dbms_java.grant_permission( 'SCOTT','SYS:java.io.FilePermission', 'payflow_java_sdk.log', 'read' )
    exec dbms_java.grant_permission( 'SCOTT','SYS:java.io.FilePermission', 'payflow_java_sdk.log', 'write' )

7.  test using the following sql or plsql statements:
    

    set serveroutput on
    call dbms_java.set_output(2000);

	  select PAYPAL_TEST_FUNC from dual;

          DECLARE
          v_QUERYRESULT VARCHAR(4000);
          BEGIN
          v_QUERYRESULT := PAYPAL_TEST_FUNC;
          DBMS_OUTPUT.PUT_LINE('v_QUERYRESULT is ' || v_QUERYRESULT);
          END;
          

    Currently getting the following result (no transaction ID):

    ------------------------------------------------------
    Executing Sample from File: DOSaleComplete.java
    ------------------------------------------------------
    Transaction Response:
    Result Code (RESULT) = -12
    Transaction ID (PNREF) = null
    Response Message (RESPMSG) = Timeout waiting for response Exceeded Reconnect
    attempts, check context for error, Current reconnect attempt = 4
    Authorization (AUTHCODE) = null
    Street Address Match (AVSADDR) = null
    Streep Zip Match (AVSZIP) = null
    International Card (IAVS) = null
    CVV2 Match (CVV2MATCH) = null
    ------------------------------------------------------
    Verbosity Response:
    Processor AVS (PROCAVS) = null
    Processor CSC (PROCCVV2) = null




