CHANGELOG
========= 

V0.5.2 (March 07, 2013)
-----------------------

   * Initial Release

V0.6.0 (April 26, 2013)
-----------------------

   * Added dynamic configuration support for API calls

