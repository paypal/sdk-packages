CHANGE LOG
==========

V0.7.2 (July 24, 2013)
-----------------------
   * Fixed bug for extended types in stubs #7.
	
You can see source code of this release in github under https://github.com/paypal/rest-api-sdk-dotnet/tree/v0.7.2.0.

V0.7.1 (June 2, 2013)
-----------------------

   * Bug fix release for "internal server error" issues in OAuth calls.
   
V0.7.0 (May 30, 2013)
-----------------------
   * Added support for Auth and Capture APIs
   * Types Modified to match the API Spec
   
V0.6.0 (April 26, 2013)
-----------------------
   * Added support for dynamic configuration of SDK (Upgraded sdk-core-dotnet dependency to V1.3.0)
   * Deprecated the setCredential method and changed resource class methods to take an ApiContext argument 
instead of an OauthTokenCredential argument

V0.5.2 (March 07, 2013)
-----------------------

   * Initial Release
