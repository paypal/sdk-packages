<?php

namespace PayPal\Rest;

interface IResource {
	
}