CHANGELOG
========= 

V0.6.0 (April 26, 2013)
-----------------------

   * Adding support for dynamic configuration of SDK (Upgrading sdk-core-php dependency to V1.4.0)
   * Deprecating the setCredential method and changing resource class methods to take an ApiContext argument instead of a OauthTokenCredential argument.

V0.5.0 (March 07, 2013)
-----------------------

   * Initial Release
