<?php 

namespace PayPal\Api;
/**
 * 
 */
class Resource extends \PPModel {



}