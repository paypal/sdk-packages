
#import <UIKit/UIKit.h>
#import "PayPal.h"


@interface PaymentSuccessViewController : UIViewController {

}

@property (nonatomic, readonly) NSString *successSummary;

@end
