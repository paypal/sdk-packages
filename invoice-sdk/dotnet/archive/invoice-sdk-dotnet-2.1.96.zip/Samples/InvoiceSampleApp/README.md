This ASP.NET Web Application (C#) contains PayPal Invoice API based samples. 

Prerequisites:
--------------
*	Visual Studio 2005 or higher

Overview
--------
The InvoicingSampleApp sample application is an API scratch pad application that allows you to play around with the Invoice APIs. 

This application is a handy complement to the API reference guides available on x.com. 

All forms are provided with default values for the mandatory parameters for each API.

The samples also demonstrate how you can use the SDK to call the API methods in your own application.