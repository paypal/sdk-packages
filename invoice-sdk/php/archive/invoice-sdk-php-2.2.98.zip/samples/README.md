PayPal PHP Invoice API sample scripts using the sdk
======================

Prerequisites
-------------

 * Invoice API PHP SDK (see the README.md in the parent directory for instructions on how to install it - you essentially need to copy the lib and config directories into your applications path). 

Sample php scripts
-------------

The three PHP scripts (createInvoice.php, sendInvoice.php and createAndSendInvoice.php) demonstrate how the 3 API calls can be executed using the SDK. Please make sure the sdk_config.ini in the config folder is updated with the correct set of API credentials. 
  
 
