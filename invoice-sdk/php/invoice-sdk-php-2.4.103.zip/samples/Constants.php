<?php
/*
 * used as dynamic credential in thirdparty API calls
 * ex: masspay with permissions
 */
define('USERNAME', 'jb-us-seller_api1.paypal.com');
define('PASSWORD', 'WX4WTU3S8MY44S7F');
define('SIGNATURE', 'AFcWxV21C7fd0v3bYYYRCpSSRl31A7yDhhsPUU2XhtMoZXsWHFxu-RWy');
