module InvoiceSamples
  VERSION = "1.96.1"
end
