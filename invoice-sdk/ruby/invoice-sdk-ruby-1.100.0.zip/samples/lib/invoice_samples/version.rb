module InvoiceSamples
  VERSION = "1.100.0"
end
