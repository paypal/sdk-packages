module InvoiceSamples
  module InvoiceHelper
  end
end
