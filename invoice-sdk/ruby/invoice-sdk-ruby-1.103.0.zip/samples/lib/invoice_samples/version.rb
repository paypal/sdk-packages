module InvoiceSamples
  VERSION = "1.103.0"
end
