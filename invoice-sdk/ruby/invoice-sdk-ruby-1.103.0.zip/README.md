Install gem:

    gem install gem/paypal-sdk-core-0.2.4.gem
    gem install gem/paypal-sdk-invoice-1.103.0.gem
	
    #To try samples
    gem install gem/invoice_samples-1.103.0.gem
	
Add library to you project `Gemfile`:

    gem 'paypal-sdk-invoice'

    #To try samples
    gem 'invoice_samples', :group => :development

Generate configuration in rails application:

    rails g paypal:sdk:install

Configure routes(`config/routes.rb`) for access samples:

    mount InvoiceSamples::Engine => "/samples" if Rails.env.development?
