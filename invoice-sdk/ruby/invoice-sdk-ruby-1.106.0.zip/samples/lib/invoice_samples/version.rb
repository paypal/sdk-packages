module InvoiceSamples
  VERSION = "1.106.0"
end
