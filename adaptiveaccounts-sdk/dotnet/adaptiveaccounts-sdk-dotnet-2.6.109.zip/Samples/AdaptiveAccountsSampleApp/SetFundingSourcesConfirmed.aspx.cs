using System;

namespace AdaptiveAccountsSampleApp
{
    public partial class SetFundingSourcesConfirmed : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
