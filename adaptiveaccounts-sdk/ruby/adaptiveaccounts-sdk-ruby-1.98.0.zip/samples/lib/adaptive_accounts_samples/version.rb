module AdaptiveAccountsSamples
  VERSION = "1.98.0"
end
