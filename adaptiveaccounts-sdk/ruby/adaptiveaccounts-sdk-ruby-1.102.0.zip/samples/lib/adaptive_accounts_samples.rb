require "paypal-sdk-adaptiveaccounts"
require "adaptive_accounts_samples/engine"
require "simple_form"
require "haml"
require "twitter-bootstrap-rails"
require "coderay"
require "jquery-rails"

module AdaptiveAccountsSamples
end
