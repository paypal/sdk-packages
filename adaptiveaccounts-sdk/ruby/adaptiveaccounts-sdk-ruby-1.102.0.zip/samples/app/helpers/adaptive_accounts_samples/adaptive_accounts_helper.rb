module AdaptiveAccountsSamples
  module AdaptiveAccountsHelper
  end
end
