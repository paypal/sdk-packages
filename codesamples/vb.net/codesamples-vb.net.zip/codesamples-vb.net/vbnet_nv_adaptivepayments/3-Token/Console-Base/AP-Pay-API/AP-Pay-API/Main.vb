﻿'****************************************************************
'THIS IS STRICTLY EXAMPLE SOURCE CODE. IT IS ONLY MEANT TO
'QUICKLY DEMONSTRATE THE CONCEPT AND THE USAGE OF THE ADAPTIVE
'PAYMENTS API. PLEASE NOTE THAT THIS IS *NOT* PRODUCTION-QUALITY
'CODE AND SHOULD NOT BE USED AS SUCH.
'
'THIS EXAMPLE CODE IS PROVIDED TO YOU ONLY ON AN "AS IS"
'BASIS WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER
'EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY WARRANTIES
'OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR
'FITNESS FOR A PARTICULAR PURPOSE. PAYPAL MAKES NO WARRANTY THAT
'THE SOFTWARE OR DOCUMENTATION WILL BE ERROR-FREE. IN NO EVENT
'SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY
'DIRECT, INDIRECT, INCIDENTAL, SPECIAL,  EXEMPLARY, OR
'CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
'OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
'OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
'LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
'THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
'OF SUCH DAMAGE.
'****************************************************************

' **************************************************************
' Sample Visual Basic Console Application 
' Adaptive Payment Pay API request using NVP payload.
' Platform: Windows XP SP3
' Compiler: Microsoft Visual Basic 2008 Express Edition
' PayPal Authentication: 3-Token Signature
' **************************************************************

' **************************************************************
' TO DO:  
' The data contained in the request body and http headers are 
' sample test data.  Change the sample data with valid data 
' applicable to your application.
' **************************************************************

Imports System.IO
Imports System.Net
Imports System.Text

Module Main

    Sub Main()

        ' Initialize Adaptive Payments HTTP headers.
        ' Use 3-Token Authentication and NVP payload.
        Dim valHeader As WebHeaderCollection = New WebHeaderCollection()
        valHeader.Add("X-PAYPAL-SECURITY-USERID:s1_1267233049_biz_api1.hotmail.com")
        valHeader.Add("X-PAYPAL-SECURITY-PASSWORD:1267233061")
        valHeader.Add("X-PAYPAL-SECURITY-SIGNATURE:AupFS7g3FEMezxo6DzUYh75GAgL.AfIb3IoACaxz8CHNnVmEFvu0BPU1")
        valHeader.Add("X-PAYPAL-REQUEST-DATA-FORMAT:NV")
        valHeader.Add("X-PAYPAL-RESPONSE-DATA-FORMAT:NV")
        valHeader.Add("X-PAYPAL-APPLICATION-ID:APP-80W284485P519543T")

        ' Form NVP data (formatted to be readable).
        Dim postData As String = "requestEnvelope.errorLanguage=en_US"
        postData += "&actionType=PAY"
        postData += "&senderEmail=byr02_1267640704_per@hotmail.com"
        postData += "&receiverList.receiver(0).email=s2_1267478028_biz@hotmail.com"
        postData += "&receiverList.receiver(0).amount=10.00"
        postData += "&receiverList.receiver(0).primary=true"
        postData += "&receiverList.receiver(1).email=slr03_1267641251_biz@hotmail.com"
        postData += "&receiverList.receiver(1).amount=1.00"
        postData += "&receiverList.receiver(1).primary=false"
        postData += "&receiverList.receiver(2).email=slr04_1267641479_biz@hotmail.com"
        postData += "&receiverList.receiver(2).amount=1.00"
        postData += "&receiverList.receiver(2).primary=false"
        postData += "&currencyCode=USD"
        postData += "&cancelUrl=https://www.sandbox.paypal.com/"
        postData += "&returnUrl=https://www.sandbox.paypal.com/"


        Dim byteArray As Byte() = Encoding.UTF8.GetBytes(postData)

        Try
            ' Initialize URI Endpoint
            Dim address As Uri = New Uri("https://svcs.sandbox.paypal.com/AdaptivePayments/Pay")

            ' Create HttpWebRequest
            Dim httpRequest As HttpWebRequest = CType(WebRequest.Create(address), HttpWebRequest)

            ' POST is the recommended PayPal API HTTP request method
            httpRequest.Method = "POST"

            ' Set HTTP headers
            httpRequest.Headers = valHeader

            ' HTTP Content-Type header
            httpRequest.ContentType = "application/x-www-form-urlencoded"
            ' HTTP Content-Length header
            httpRequest.ContentLength = postData.Length

            ' Get the request stream.
            Dim dataStream As Stream = httpRequest.GetRequestStream()
            ' Write the data to the request stream.
            dataStream.Write(byteArray, 0, byteArray.Length)

            ' Handle response.
            Dim httpResponse As HttpWebResponse = CType(httpRequest.GetResponse(), HttpWebResponse)
            Dim reader As StreamReader = New StreamReader(httpResponse.GetResponseStream())

            ' Print response data
            Console.WriteLine(reader.ReadToEnd())

            ' Closing objects
            dataStream.Close()
            reader.Close()
            httpResponse.Close()

        Catch ex As Exception
            Console.WriteLine("Exception: " + ex.ToString)
        End Try

    End Sub

End Module
