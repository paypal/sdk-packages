﻿'****************************************************************
'THIS IS STRICTLY EXAMPLE SOURCE CODE. IT IS ONLY MEANT TO
'QUICKLY DEMONSTRATE THE CONCEPT AND THE USAGE OF THE ADAPTIVE
'PAYMENTS API. PLEASE NOTE THAT THIS IS *NOT* PRODUCTION-QUALITY
'CODE AND SHOULD NOT BE USED AS SUCH.
'
'THIS EXAMPLE CODE IS PROVIDED TO YOU ONLY ON AN "AS IS"
'BASIS WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER
'EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY WARRANTIES
'OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR
'FITNESS FOR A PARTICULAR PURPOSE. PAYPAL MAKES NO WARRANTY THAT
'THE SOFTWARE OR DOCUMENTATION WILL BE ERROR-FREE. IN NO EVENT
'SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY
'DIRECT, INDIRECT, INCIDENTAL, SPECIAL,  EXEMPLARY, OR
'CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
'OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
'OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
'LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
'(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
'THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
'OF SUCH DAMAGE.
'****************************************************************

' **************************************************************
' Sample Visual Basic Form-Based Application
' Adaptive Payment Pay API request using NVP payload.
' Platform: Windows XP SP3
' Compiler: Microsoft Visual Basic 2008 Express Edition
' PayPal Authentication: 3-Token Signature
' **************************************************************

' **************************************************************
' TO DO:  
' The data contained in the request body and http headers are 
' sample test data.  Change the sample data with valid data 
' applicable to your application.
' **************************************************************

Imports System.IO
Imports System.Net
Imports System.Text

Public Class frmMain

    Dim httpRequest As HttpWebRequest
    Dim valHeader As WebHeaderCollection
    Dim address As Uri
    Dim reader As StreamReader
    Dim readRespData As String
    Dim nvpReq As String
    Dim nvpResp As String
    Dim dataStream As Stream

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' Initialize Adaptive Payments HTTP headers
        ' Using 3-Token Authentication and NVP payload
        valHeader = New WebHeaderCollection()
        valHeader.Add("X-PAYPAL-SECURITY-USERID:" + txt_User_ID.Text)
        valHeader.Add("X-PAYPAL-SECURITY-PASSWORD:" + txt_Password.Text)
        valHeader.Add("X-PAYPAL-SECURITY-SIGNATURE:" + txt_Signature.Text)
        valHeader.Add("X-PAYPAL-REQUEST-DATA-FORMAT:" + txt_Request_Format.Text)
        valHeader.Add("X-PAYPAL-RESPONSE-DATA-FORMAT:" + txt_Response_Format.Text)
        valHeader.Add("X-PAYPAL-APPLICATION-ID:" + txt_App_ID.Text)

        ' Initialize URI Endpoint
        address = New Uri(txt_Endpoint.Text + txt_API.Text)

    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click


        btnSubmit.Text = "Waiting.."
        btnSubmit.Enabled = False

        Try

            ' Create HttpWebRequest
            httpRequest = CType(WebRequest.Create(address), HttpWebRequest)

            ' POST is the recommended PayPal API HTTP request method
            httpRequest.Method = "POST"

            httpRequest.ContentType = "application/x-www-form-urlencoded"

            ' Set HTTP headers
            httpRequest.Headers = valHeader

            ' Format NVP data, removing line feed and contatenate with '&'.
            nvpReq = txt_ReqData.Text.Replace(ControlChars.Lf, "&")

            ' HTTP Content-Length header.
            httpRequest.ContentLength = nvpReq.Length

            ' Get the request stream.
            dataStream = httpRequest.GetRequestStream()

            Dim byteArray As Byte() = Encoding.UTF8.GetBytes(nvpReq)

            ' Write the data to the request stream.
            dataStream.Write(byteArray, 0, byteArray.Length)

            ' Send request and wait for response
            Dim httpResponse As HttpWebResponse = CType(httpRequest.GetResponse(), HttpWebResponse)
            'Dim httpResponse As WebResponse = httpRequest.GetResponse()

            reader = New StreamReader(httpResponse.GetResponseStream())

            nvpResp = reader.ReadToEnd()

            ' Display response data.
            ' Formatted with line feed for readability
            txt_Result.Text = nvpResp.Replace("&", ControlChars.Lf)

            ' Close objects.
            httpResponse.Close()
            dataStream.Close()
            reader.Close()

        Catch exp As Exception
            MsgBox("Exception2: " + exp.ToString)
        End Try

        ' Activate and update button.
        btnSubmit.Enabled = True
        btnSubmit.Text = "Submit"

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txt_Result.Clear()
    End Sub

End Class
