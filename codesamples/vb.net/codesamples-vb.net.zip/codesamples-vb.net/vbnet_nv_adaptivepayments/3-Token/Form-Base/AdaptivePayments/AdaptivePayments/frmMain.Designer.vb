﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.btnClear = New System.Windows.Forms.Button
        Me.btnSubmit = New System.Windows.Forms.Button
        Me.l_Response = New System.Windows.Forms.Label
        Me.txt_Result = New System.Windows.Forms.RichTextBox
        Me.l_REQUEST = New System.Windows.Forms.Label
        Me.txt_ReqData = New System.Windows.Forms.RichTextBox
        Me.lbl_Application_ID = New System.Windows.Forms.Label
        Me.txt_App_ID = New System.Windows.Forms.TextBox
        Me.lbl_Response_Format = New System.Windows.Forms.Label
        Me.txt_Response_Format = New System.Windows.Forms.TextBox
        Me.lbl_Request_Format = New System.Windows.Forms.Label
        Me.txt_Request_Format = New System.Windows.Forms.TextBox
        Me.lbl_Signature = New System.Windows.Forms.Label
        Me.txt_Signature = New System.Windows.Forms.TextBox
        Me.lbl_Password = New System.Windows.Forms.Label
        Me.txt_Password = New System.Windows.Forms.TextBox
        Me.lbl_UserID = New System.Windows.Forms.Label
        Me.txt_User_ID = New System.Windows.Forms.TextBox
        Me.grp_Headers = New System.Windows.Forms.GroupBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txt_Endpoint = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txt_API = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.grp_Headers.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(648, 488)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 36
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(22, 488)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmit.TabIndex = 34
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'l_Response
        '
        Me.l_Response.AutoSize = True
        Me.l_Response.Location = New System.Drawing.Point(661, 239)
        Me.l_Response.Name = "l_Response"
        Me.l_Response.Size = New System.Drawing.Size(40, 13)
        Me.l_Response.TabIndex = 33
        Me.l_Response.Text = "Result:"
        '
        'txt_Result
        '
        Me.txt_Result.Location = New System.Drawing.Point(10, 31)
        Me.txt_Result.Name = "txt_Result"
        Me.txt_Result.Size = New System.Drawing.Size(344, 183)
        Me.txt_Result.TabIndex = 32
        Me.txt_Result.Text = ""
        '
        'l_REQUEST
        '
        Me.l_REQUEST.AutoSize = True
        Me.l_REQUEST.Location = New System.Drawing.Point(626, 206)
        Me.l_REQUEST.Name = "l_REQUEST"
        Me.l_REQUEST.Size = New System.Drawing.Size(50, 13)
        Me.l_REQUEST.TabIndex = 31
        Me.l_REQUEST.Text = "Request:"
        '
        'txt_ReqData
        '
        Me.txt_ReqData.Location = New System.Drawing.Point(22, 299)
        Me.txt_ReqData.Name = "txt_ReqData"
        Me.txt_ReqData.Size = New System.Drawing.Size(342, 183)
        Me.txt_ReqData.TabIndex = 30
        Me.txt_ReqData.Text = resources.GetString("txt_ReqData.Text")
        '
        'lbl_Application_ID
        '
        Me.lbl_Application_ID.AutoSize = True
        Me.lbl_Application_ID.Location = New System.Drawing.Point(83, 157)
        Me.lbl_Application_ID.Name = "lbl_Application_ID"
        Me.lbl_Application_ID.Size = New System.Drawing.Size(104, 15)
        Me.lbl_Application_ID.TabIndex = 29
        Me.lbl_Application_ID.Text = "Application ID: "
        '
        'txt_App_ID
        '
        Me.txt_App_ID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_App_ID.Location = New System.Drawing.Point(194, 151)
        Me.txt_App_ID.Name = "txt_App_ID"
        Me.txt_App_ID.ReadOnly = True
        Me.txt_App_ID.Size = New System.Drawing.Size(359, 21)
        Me.txt_App_ID.TabIndex = 28
        Me.txt_App_ID.Text = "APP-80W284485P519543T"
        '
        'lbl_Response_Format
        '
        Me.lbl_Response_Format.AutoSize = True
        Me.lbl_Response_Format.Location = New System.Drawing.Point(60, 131)
        Me.lbl_Response_Format.Name = "lbl_Response_Format"
        Me.lbl_Response_Format.Size = New System.Drawing.Size(128, 15)
        Me.lbl_Response_Format.TabIndex = 27
        Me.lbl_Response_Format.Text = "Response Format: "
        '
        'txt_Response_Format
        '
        Me.txt_Response_Format.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Response_Format.Location = New System.Drawing.Point(194, 124)
        Me.txt_Response_Format.Name = "txt_Response_Format"
        Me.txt_Response_Format.ReadOnly = True
        Me.txt_Response_Format.Size = New System.Drawing.Size(359, 21)
        Me.txt_Response_Format.TabIndex = 26
        Me.txt_Response_Format.Text = "NV"
        '
        'lbl_Request_Format
        '
        Me.lbl_Request_Format.AutoSize = True
        Me.lbl_Request_Format.Location = New System.Drawing.Point(71, 104)
        Me.lbl_Request_Format.Name = "lbl_Request_Format"
        Me.lbl_Request_Format.Size = New System.Drawing.Size(117, 15)
        Me.lbl_Request_Format.TabIndex = 25
        Me.lbl_Request_Format.Text = "Request Format: "
        '
        'txt_Request_Format
        '
        Me.txt_Request_Format.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Request_Format.Location = New System.Drawing.Point(194, 98)
        Me.txt_Request_Format.Name = "txt_Request_Format"
        Me.txt_Request_Format.ReadOnly = True
        Me.txt_Request_Format.Size = New System.Drawing.Size(359, 21)
        Me.txt_Request_Format.TabIndex = 24
        Me.txt_Request_Format.Text = "NV"
        '
        'lbl_Signature
        '
        Me.lbl_Signature.AutoSize = True
        Me.lbl_Signature.Location = New System.Drawing.Point(110, 79)
        Me.lbl_Signature.Name = "lbl_Signature"
        Me.lbl_Signature.Size = New System.Drawing.Size(77, 15)
        Me.lbl_Signature.TabIndex = 23
        Me.lbl_Signature.Text = "Signature: "
        '
        'txt_Signature
        '
        Me.txt_Signature.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Signature.Location = New System.Drawing.Point(194, 73)
        Me.txt_Signature.Name = "txt_Signature"
        Me.txt_Signature.ReadOnly = True
        Me.txt_Signature.Size = New System.Drawing.Size(359, 21)
        Me.txt_Signature.TabIndex = 22
        Me.txt_Signature.Text = "AupFS7g3FEMezxo6DzUYh75GAgL.AfIb3IoACaxz8CHNnVmEFvu0BPU1"
        '
        'lbl_Password
        '
        Me.lbl_Password.AutoSize = True
        Me.lbl_Password.Location = New System.Drawing.Point(110, 53)
        Me.lbl_Password.Name = "lbl_Password"
        Me.lbl_Password.Size = New System.Drawing.Size(77, 15)
        Me.lbl_Password.TabIndex = 21
        Me.lbl_Password.Text = "Password: "
        '
        'txt_Password
        '
        Me.txt_Password.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Password.Location = New System.Drawing.Point(194, 47)
        Me.txt_Password.Name = "txt_Password"
        Me.txt_Password.ReadOnly = True
        Me.txt_Password.Size = New System.Drawing.Size(359, 21)
        Me.txt_Password.TabIndex = 20
        Me.txt_Password.Text = "1267233061"
        '
        'lbl_UserID
        '
        Me.lbl_UserID.AutoSize = True
        Me.lbl_UserID.Location = New System.Drawing.Point(124, 27)
        Me.lbl_UserID.Name = "lbl_UserID"
        Me.lbl_UserID.Size = New System.Drawing.Size(63, 15)
        Me.lbl_UserID.TabIndex = 19
        Me.lbl_UserID.Text = "User ID: "
        '
        'txt_User_ID
        '
        Me.txt_User_ID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_User_ID.Location = New System.Drawing.Point(194, 21)
        Me.txt_User_ID.Name = "txt_User_ID"
        Me.txt_User_ID.ReadOnly = True
        Me.txt_User_ID.Size = New System.Drawing.Size(359, 21)
        Me.txt_User_ID.TabIndex = 35
        Me.txt_User_ID.Text = "s1_1267233049_biz_api1.hotmail.com"
        '
        'grp_Headers
        '
        Me.grp_Headers.Controls.Add(Me.lbl_Application_ID)
        Me.grp_Headers.Controls.Add(Me.txt_App_ID)
        Me.grp_Headers.Controls.Add(Me.lbl_Response_Format)
        Me.grp_Headers.Controls.Add(Me.txt_Response_Format)
        Me.grp_Headers.Controls.Add(Me.lbl_Request_Format)
        Me.grp_Headers.Controls.Add(Me.txt_Request_Format)
        Me.grp_Headers.Controls.Add(Me.lbl_Signature)
        Me.grp_Headers.Controls.Add(Me.txt_Signature)
        Me.grp_Headers.Controls.Add(Me.lbl_Password)
        Me.grp_Headers.Controls.Add(Me.txt_Password)
        Me.grp_Headers.Controls.Add(Me.lbl_UserID)
        Me.grp_Headers.Controls.Add(Me.txt_User_ID)
        Me.grp_Headers.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grp_Headers.Location = New System.Drawing.Point(22, 64)
        Me.grp_Headers.Name = "grp_Headers"
        Me.grp_Headers.Size = New System.Drawing.Size(707, 188)
        Me.grp_Headers.TabIndex = 38
        Me.grp_Headers.TabStop = False
        Me.grp_Headers.Text = "HEADERS"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(74, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(135, 13)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "Environment Endpoint:"
        '
        'txt_Endpoint
        '
        Me.txt_Endpoint.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Endpoint.Location = New System.Drawing.Point(216, 10)
        Me.txt_Endpoint.Name = "txt_Endpoint"
        Me.txt_Endpoint.ReadOnly = True
        Me.txt_Endpoint.Size = New System.Drawing.Size(359, 21)
        Me.txt_Endpoint.TabIndex = 37
        Me.txt_Endpoint.Text = "https://svcs.sandbox.paypal.com/AdaptivePayments/"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label2.Location = New System.Drawing.Point(178, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 39
        Me.Label2.Text = "API:"
        '
        'txt_API
        '
        Me.txt_API.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_API.Location = New System.Drawing.Point(216, 37)
        Me.txt_API.Name = "txt_API"
        Me.txt_API.ReadOnly = True
        Me.txt_API.Size = New System.Drawing.Size(359, 21)
        Me.txt_API.TabIndex = 40
        Me.txt_API.Text = "Pay"
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(12, 268)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(361, 255)
        Me.GroupBox1.TabIndex = 41
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "PayRequest Data"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txt_Result)
        Me.GroupBox2.Location = New System.Drawing.Point(375, 268)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(369, 255)
        Me.GroupBox2.TabIndex = 42
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "PayResponse Data"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(757, 546)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_API)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.grp_Headers)
        Me.Controls.Add(Me.txt_Endpoint)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.l_Response)
        Me.Controls.Add(Me.l_REQUEST)
        Me.Controls.Add(Me.txt_ReqData)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Name = "frmMain"
        Me.Text = "Adaptive Payments Pay API Sample"
        Me.grp_Headers.ResumeLayout(False)
        Me.grp_Headers.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    Friend WithEvents l_Response As System.Windows.Forms.Label
    Friend WithEvents txt_Result As System.Windows.Forms.RichTextBox
    Friend WithEvents l_REQUEST As System.Windows.Forms.Label
    Friend WithEvents txt_ReqData As System.Windows.Forms.RichTextBox
    Friend WithEvents lbl_Application_ID As System.Windows.Forms.Label
    Friend WithEvents txt_App_ID As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Response_Format As System.Windows.Forms.Label
    Friend WithEvents txt_Response_Format As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Request_Format As System.Windows.Forms.Label
    Friend WithEvents txt_Request_Format As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Signature As System.Windows.Forms.Label
    Friend WithEvents txt_Signature As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Password As System.Windows.Forms.Label
    Friend WithEvents txt_Password As System.Windows.Forms.TextBox
    Friend WithEvents lbl_UserID As System.Windows.Forms.Label
    Friend WithEvents txt_User_ID As System.Windows.Forms.TextBox
    Friend WithEvents grp_Headers As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_Endpoint As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_API As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox

End Class
