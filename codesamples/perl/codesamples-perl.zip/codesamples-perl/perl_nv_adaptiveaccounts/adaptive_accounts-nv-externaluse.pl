#!/usr/bin/perl 

# APAPTIVE ACCOUNTS API call using protocol, NV (Named Value Pairs)

###################################################################
# THIS IS STRICTLY EXAMPLE SOURCE CODE. IT IS ONLY MEANT TO
# QUICKLY DEMONSTRATE THE CONCEPT AND THE USAGE OF THE ADAPTIVE
# ACCOUNTS API. PLEASE NOTE THAT THIS IS *NOT* PRODUCTION-QUALITY
# CODE AND SHOULD NOT BE USED AS SUCH.
#
# THIS EXAMPLE CODE IS PROVIDED TO YOU ONLY ON AN "AS IS"
# BASIS WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER
# EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY WARRANTIES
# OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR
# FITNESS FOR A PARTICULAR PURPOSE. PAYPAL MAKES NO WARRANTY THAT
# THE SOFTWARE OR DOCUMENTATION WILL BE ERROR-FREE. IN NO EVENT
# SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL,  EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
# THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.
###################################################################
#TODO
#The http headers and request body contains sample data, please replace the #data with valid data.

use strict;
my $method='POST';

use HTTP::Request::Common;
use LWP;

my $headers = HTTP::Headers->new(
'X-PAYPAL-SECURITY-USERID'=> 'email_biz_domain.com',
'X-PAYPAL-SECURITY-PASSWORD' => 'xxxxxx',
'X-PAYPAL-SECURITY-SIGNATURE' => 'xxxxxxxxxxxxxxx',
'X-PAYPAL-APPLICATION-ID' => 'APP-80W284485P519543T',
'X-PAYPAL-SANDBOX-EMAIL-ADDRESS' => 'email@domain.com',
'X-PAYPAL-DEVICE-IPADDRESS' => '127.0.0.1',
'X-PAYPAL-REQUEST-DATA-FORMAT' => 'NV',
'X-PAYPAL-RESPONSE-DATA-FORMAT' => 'NV');

my $content = sprintf("%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s", 
       'name.firstName=firstname',
       'name.lastName=lastname',
       'address.line1=xxx Any Street',
       'address.city=Somehere',
       'address.state=CA',
       'address.postalCode=xxxxx',
       'address.countryCode=US',
       'contactPhoneNumber=469-252-3526',
       'requestEnvelope.errorLanguage=en_US',
       'emailAddress=email-new@domain.com',
       'currencyCode=USD',
       'preferredLanguageCode=en_US',
       'registrationType=WEB',
       'createAccountWebOptions=http://myreturnurl.html');


my $req = HTTP::Request->new($method,'https://svcs.sandbox.paypal.com/AdaptiveAccounts/CreateAccount',$headers, $content);
my $ua = LWP::UserAgent->new;
  
my $res = $ua->request($req);
if ($res->is_success) {
	print $res->content;}
	else {
		print $res->status_line, "\n";}
