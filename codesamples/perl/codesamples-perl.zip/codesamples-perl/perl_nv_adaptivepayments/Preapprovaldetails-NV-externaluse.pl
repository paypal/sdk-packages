#!/usr/bin/perl 

# To generate PAY PREAPPROVAL DETAILS with a protocol of NV (Named Value Pairs)

# DEVELOPED WITH ACTIVE PERL V5.10.1

###################################################################
# THIS IS STRICTLY EXAMPLE SOURCE CODE. IT IS ONLY MEANT TO
# QUICKLY DEMONSTRATE THE CONCEPT AND THE USAGE OF THE ADAPTIVE
# PAYMENTS API. PLEASE NOTE THAT THIS IS *NOT* PRODUCTION-QUALITY
# CODE AND SHOULD NOT BE USED AS SUCH.
#
# THIS EXAMPLE CODE IS PROVIDED TO YOU ONLY ON AN "AS IS"
# BASIS WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER
# EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY WARRANTIES
# OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR
# FITNESS FOR A PARTICULAR PURPOSE. PAYPAL MAKES NO WARRANTY THAT
# THE SOFTWARE OR DOCUMENTATION WILL BE ERROR-FREE. IN NO EVENT
# SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL,  EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
# THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.
###################################################################
#TODO
#The http headers and request body contains sample data, please replace the #data with valid data.

use strict;
my $method='POST';

use HTTP::Request::Common;
use LWP;
 

my $headers = HTTP::Headers->new(
	'X-PAYPAL-SECURITY-USERID'=> 'email@domain',
	'X-PAYPAL-SECURITY-PASSWORD' => 'xxxxxx',
	'X-PAYPAL-SECURITY-SIGNATURE' => 'xxxxxxxxxxxxxxx',
	'X-PAYPAL-SERVICE-VERSION' => '1.1.0',
	'X-PAYPAL-APPLICATION-ID' => 'APP-80W284485P519543T',
	'X-PAYPAL-REQUEST-DATA-FORMAT' => 'NV',
	'X-PAYPAL-RESPONSE-DATA-FORMAT' => 'NV');
	
###################################################################
# In the above $headers declaration, the USERID, PASSWORD and 
# SIGNATURE need to be replaced with your own.
###################################################################	

my $content = sprintf("%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s&%s",
       'senderEmail=email@domain',
       'actionType=PAY',
       'preapprovalKey=PA-xxxxxxxxxx',
       'currencyCode=USD',
       'feesPayer=EACHRECEIVER',
       'receiverList.receiver(0).email=email@domain',
       'receiverList.receiver(0).primary=false',
       'receiverList.receiver(0).amount=20.00',
       'returnUrl=http:myreturnurl',
       'cancelUrl=http:mycancelurl',
       'requestEnvelope.errorLanguage=en_US',
       'clientDetails.ipAddress=127.0.0.1',
       'clientDetails.deviceId=mydevice',
       'clientDetails.applicationId=PayNvpDemo',
       'maxTotalAmountOfAllPayments=16',
       'startingDate=2009-10-30T00:11:11',
       'endingDate=2009-11-27T00:00:22');


my $req = HTTP::Request->new($method,'https://svcs.sandbox.paypal.com/AdaptivePayments/PreapprovalDetails',$headers, $content);
my $ua = LWP::UserAgent->new;

my $res = $ua->request($req);
if ($res->is_success) {
	print $res->content;}
	else {
		print $res->status_line, "\n";}
