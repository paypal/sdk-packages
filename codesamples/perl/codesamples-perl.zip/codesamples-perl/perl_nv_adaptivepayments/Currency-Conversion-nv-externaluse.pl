#!/usr/bin/perl 
###################################################################
# THIS IS STRICTLY EXAMPLE SOURCE CODE. IT IS ONLY MEANT TO
# QUICKLY DEMONSTRATE THE CONCEPT AND THE USAGE OF THE ADAPTIVE
# PAYMENTS API. PLEASE NOTE THAT THIS IS *NOT* PRODUCTION-QUALITY
# CODE AND SHOULD NOT BE USED AS SUCH.
#
# THIS EXAMPLE CODE IS PROVIDED TO YOU ONLY ON AN "AS IS"
# BASIS WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER
# EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY WARRANTIES
# OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR
# FITNESS FOR A PARTICULAR PURPOSE. PAYPAL MAKES NO WARRANTY THAT
# THE SOFTWARE OR DOCUMENTATION WILL BE ERROR-FREE. IN NO EVENT
# SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL,  EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
# THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.
###################################################################
#TODO
#The http headers and request body contains sample data, please replace the #data with valid data.

# DEVELOPED WITH ACTIVE PERL V5.10.1

# To generate PAY HTML with a protocol of NV (Named Value Pairs)
#######
use strict;
my $method='POST';

use HTTP::Request::Common;
use LWP;
 

my $headers = HTTP::Headers->new
('X-PAYPAL-SECURITY-USERID'=> 'perryl_1251221679_biz_api1.gmail.com',
'X-PAYPAL-SECURITY-PASSWORD' => '1251221690',
'X-PAYPAL-SECURITY-SIGNATURE' => 'An5ns1Kso7MWUdW4ErQKJJJ4qi4-A6vHewqEd.wyp7U4iLkBySrYA6EF',
'X-PAYPAL-APPLICATION-ID' => 'APP-80W284485P519543T',
'X-PAYPAL-REQUEST-DATA-FORMAT' => 'NV',
'X-PAYPAL-RESPONSE-DATA-FORMAT' => 'NV');

my $content = sprintf("%s&%s&%s&%s&%s&%s",
		'requestEnvelope.errorLanguage=en_US',
		'requestEnvelope.detailLevel=ReturnAll',
        'baseAmountList.currency.code=USD',
        'baseAmountList.currency.amount=100.23',
        'convertToCurrencyList.currencyCode=SEK');


my $req = HTTP::Request->new($method,'https://svcs.sandbox.paypal.com/AdaptivePayments/ConvertCurrency',$headers, $content);
my $ua = LWP::UserAgent->new;

  my $res = $ua->request($req);
if ($res->is_success) {
	print $res->content;}
	else {
		print $res->status_line, "\n";}
