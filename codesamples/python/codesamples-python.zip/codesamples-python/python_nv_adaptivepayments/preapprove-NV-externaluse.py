#To generate PAY PREAPPROVE with a protocol of NV

###################################################################
# THIS IS STRICTLY EXAMPLE SOURCE CODE. IT IS ONLY MEANT TO
# QUICKLY DEMONSTRATE THE CONCEPT AND THE USAGE OF THE ADAPTIVE
# PAYMENTS API. PLEASE NOTE THAT THIS IS *NOT* PRODUCTION-QUALITY
# CODE AND SHOULD NOT BE USED AS SUCH.
#
# THIS EXAMPLE CODE IS PROVIDED TO YOU ONLY ON AN "AS IS"
# BASIS WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER
# EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY WARRANTIES
# OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR
# FITNESS FOR A PARTICULAR PURPOSE. PAYPAL MAKES NO WARRANTY THAT
# THE SOFTWARE OR DOCUMENTATION WILL BE ERROR-FREE. IN NO EVENT
# SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL,  EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
# THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.
###################################################################
#TO DO
#The data contained in the request body and http headers are 
#sample test data.  Change the sample data with valid data 
#applicable to your application.

import httplib, urllib, urlparse

#Set our headers
headers = {
            'Content-type':'application/x-www-form-urlencoded',
            'Accept':'text/plain',
            'X-PAYPAL-SECURITY-USERID':'email@domain', 
            'X-PAYPAL-SECURITY-PASSWORD':'xxxxxx', 
            'X-PAYPAL-SECURITY-SIGNATURE':'xxxxxxxxxxxxxxx',
            'X-PAYPAL-APPLICATION-ID':'APP-80W284485P519543T',
            'X-PAYPAL-SERVICE-VERSION':'1.1.0',
            'X-PAYPAL-REQUEST-DATA-FORMAT':'NV',
            'X-PAYPAL-RESPONSE-DATA-FORMAT':'NV'
            }

###################################################################
# In the above $headers declaration, the USERID, PASSWORD and 
# SIGNATURE need to be replaced with your own.
################################################################### 
            
#Set our POST Parameters
params = {
            'requestEnvelope.errorLanguage':'en_US',
            'requestEnvelope.detailLevel':'ReturnAll',
            'returnUrl':'http:myreturnurl',
            'cancelUrl':'http:mycancelurl',
            'currencyCode':'USD',
            'senderEmail':'email@domain',  
          }
            
#Client Details
params.update({
            'clientDetails.applicationId':'PlatformPreview',
            'clientDetails.deviceId':'mydevice',
            'clientDetails.ipAddress':'127.0.0.1',
             })
            
#PreApproval Details
params.update({
            'maxTotalAmountOfAllPayments':'2000',
            'startingDate':'2010-07-25T07:00:00',
            'endingDate':'2011-07-25T07:00:00',
            })
            

            
enc_params = urllib.urlencode(params)
             
#Connect to sand box and POST.
conn = httplib.HTTPSConnection("svcs.sandbox.paypal.com")
conn.request("POST", "/AdaptivePayments/Preapproval/", enc_params, headers)

#Check the response - should be 200 OK.
response = conn.getresponse()
print response.status, response.reason

#Get the reply and print it out.
data = response.read()
print urlparse.parse_qs(data)

#Close the Connection.
conn.close()