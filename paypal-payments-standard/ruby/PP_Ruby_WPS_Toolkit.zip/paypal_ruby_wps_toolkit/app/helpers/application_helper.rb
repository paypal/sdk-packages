# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  
  def currency_select_for(model)
    currencies = %w(USD GBP EUR JPY CAD AUD)
    select(model, :currency, currencies.map { |currency| [currency, currency] }, {:selected => 'USD'})            
  end
  
  
 
end
