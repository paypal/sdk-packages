require 'credentials'
# Controller with action for encrypting Buy Now button and to do form post. 
class CredentialsController < ApplicationController    
  
  def show    
    @identity_token            =  PayPalWPSToolkit::Credentials.MY_BUSINESS_IDENTITY_TOKEN 
    @default_cert_id           =  PayPalWPSToolkit::Credentials.MY_BUSINESS_EWP_CERT_ID 
    @default_email_address     =  PayPalWPSToolkit::Credentials.MY_BUSINESS_EMAIL_ADDRESS             
    @paypal_certificate_path   =  PayPalWPSToolkit::Credentials.PAYPAL_CERTIFICATE_PATH
    @target_env                =  PayPalWPSToolkit::Credentials.TARGET_ENV
    @merchant_certificate_path =  PayPalWPSToolkit::Credentials.MY_BUSINESS_EWP_CERT_PATH
      
  end
 
 
end
