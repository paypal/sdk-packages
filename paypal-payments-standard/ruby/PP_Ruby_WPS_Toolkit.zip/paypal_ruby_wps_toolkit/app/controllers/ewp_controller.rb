
require 'credentials'
require 'EWPServices'
# Controller with action for encrypting Buy Now button and to do form post. 
class EwpController < ApplicationController    
  
  def buy
    @item_name     = params[:buttondata][:item_name]
    @amount        = params[:buttondata][:amount]
    @returnURL     = params[:buttondata][:returnURL]
    @cancelURL     = params[:buttondata][:cancelURL]
    @notifyURL     = params[:buttondata][:notifyURL]
    @currency_code = params[:buttondata][:currency]
    @item_number   = params[:buttondata][:item_number]
    @cmd           = '_xclick'
    
    @business            = PayPalWPSToolkit::Credentials.MY_BUSINESS_EMAIL_ADDRESS
    @cert_id             = PayPalWPSToolkit::Credentials.MY_BUSINESS_EWP_CERT_ID  
    paypal_cert          = PayPalWPSToolkit::Credentials.PAYPAL_CERT
 
    my_business_ewp_cert = PayPalWPSToolkit::Credentials.MY_BUSINESS_EWP_CERT
    my_business_ewp_key  = PayPalWPSToolkit::Credentials.MY_BUSINESS_EWP_KEY
    data                 =  { :cmd            => @cmd,
                              :business       => @business,
                              :cert_id        => @cert_id,
                              :charset        => 'UTF-8',
                              :item_name      => @item_name,
                              :item_number    => @item_number,
                              :amount         => @amount,
                              :currency_code  => @currency_code,
                              :return         => @returnURL,
                              :cancel_return  => @cancelURL,
                              :notify_url     => @notifyURL,
                              :custom         => 'PayPal RoR EWP Sample'     
                              
                            }
    @envURL               = PayPalWPSToolkit::Credentials.TARGET_TEST_ENV
    @button_image         = PayPalWPSToolkit::Credentials.BUTTON_IMAGE    
    password              = PayPalWPSToolkit::Credentials.MY_BUSINESS_PRIVATE_KEY_PWD
    @button               = PayPalWPSToolkit::EWPServices.encrypt_button(paypal_cert, my_business_ewp_cert, my_business_ewp_key,password, data)    
   
 end
 
end
