# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  # Pick a unique cookie name to distinguish our session data from others'
  session :session_key => '_WPS_session_id'
end

def get_server_path(request)
    @host=request.host.to_s
    @port=request.port.to_s   
    @serverURL="http://#{@host}:#{@port}"
  end
  
def get_log_contents(file_name)   
  f= File.new(file_name, 'r')
  contents = f.read
  f.close
  return contents
end