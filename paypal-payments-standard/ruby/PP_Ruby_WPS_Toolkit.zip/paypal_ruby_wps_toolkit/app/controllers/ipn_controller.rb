require 'util'
require 'credentials'
require 'ipn'
# This controler  has a method to listen to notification from PayPal.
class IpnController < ApplicationController    
  
  def show
   #show the IPN log file  
   log_file_name = "./script/../config/../log/paypal-ipn.log"
   @contents = get_log_contents(log_file_name)   
  end
 
  def update    
    @target_url       = PayPalWPSToolkit::Credentials.TARGET_TEST_ENV
    @PayPalLog=PayPalWPSToolkit::Logger.getLogger('paypal-ipn.log')     
    txn_id =    params[:txn_id]    
    # check to see txn_id and other things exist in the notification. If exists log it. 
    if !txn_id.nil?
      @PayPalLog.info "received IPN Notification for #{txn_id}"     
      # post back the notification     
      ipn = PayPalWPSToolkit::Notification.new(request.raw_post)
      if ipn.acknowledge
        ipn.log     
      end
    else
      @PayPalLog.info "Invalid access!!"
    end
    render :text => '', :status=>204
  end
 
  def error
    @status = "INVALID"
  end
end
