require 'credentials'
class GetdataController < ApplicationController
  
  def get_input
    @serverURL = get_server_path(request)
    @cancelURL = "#{@serverURL}#{request.request_uri}"
    @returnURL = "#{@serverURL}/pdt/update"  
    @notifyURL = "#{@serverURL}/ipn/update"   
    @endpoint  = PayPalWPSToolkit::Credentials.TARGET_TEST_ENV
  end
  
  def credentials
      redirect_to :controller => 'credentials', :action => 'show'
  end
end