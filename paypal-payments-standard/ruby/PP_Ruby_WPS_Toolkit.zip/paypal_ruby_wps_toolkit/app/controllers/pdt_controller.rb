require 'caller'
require 'credentials'
require 'util'
require 'cgi'
# Controller with actions for displaying the GET and POST results of PDT from PayPal . 
class PdtController < ApplicationController    
  
  def update    
    @transaction_id          = params[:tx]
    session[:transaction_id] = @transaction_id
    session[:payment_status] = params[:st]
    session[:payment_gross]  = params[:amt]
    session[:mc_currency]    = params[:cc]
    session[:custom]         = params[:cm]
    session[:sig]            = params[:sig]
    @identity_token          = PayPalWPSToolkit::Credentials.MY_BUSINESS_IDENTITY_TOKEN      
    post_data                =  {    
                               :cmd => '_notify-synch',  
                               :tx   => @transaction_id,
                               :at   => @identity_token                             
                               }
          
    pdt = PayPalWPSToolkit::Pdt.new(post_data)
    if pdt.success?
     session[:response]= pdt.get_params
    end   
    redirect_to  :action => 'show'
    rescue Errno::ENOENT => exception
    flash[:error] = exception
    redirect_to :controller => 'wps', :action => 'exception'
  end
 
  def show
    @transaction_id = session[:transaction_id]
    @mc_currency    = session[:mc_currency]
    @payment_status = session[:payment_status]
    @payment_gross  = session[:payment_gross]
    @custom         = session[:custom]
    @signature      = session[:sig]
    @response       = session[:response]    
  end
  
  def show_ipn
    redirect_to :controller => 'ipn', :action => 'show'   
  end
  
end
