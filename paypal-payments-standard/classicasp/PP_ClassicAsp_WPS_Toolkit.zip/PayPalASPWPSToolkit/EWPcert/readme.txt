EWP  Credentials (sandbox and beta-sandbox)
=================================================

This folder contains
--------------------

paypal_cert_pem.txt - PayPal's public certificate downloaded from your account profile
sdk-ewp.p12 - Merchant's p12 file that contains both the merchant's private and public key			 

Info
----

Certificate ID 	: B62GVU8RWNBFC
PKCS12 File	: sdk-ewp.p12
PKCS12 Passowrd : password

	