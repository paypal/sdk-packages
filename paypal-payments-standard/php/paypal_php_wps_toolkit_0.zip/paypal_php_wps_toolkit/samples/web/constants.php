<?php

define("DEFAULT_DEV_CENTRAL", "developer");
define("DEFAULT_ENV", "sandbox");
define("DEFAULT_EMAIL_ADDRESS", "sdk.seller@gmail.com");
define("DEFAULT_IDENTITY_TOKEN", "6vwLEY_ogPGnoQac2a0x4PRsSGrmzJPMkyGbJtpiCSwrkYsNSYxWfPY2ZLO");
define("DEFAULT_EWP_CERT_PATH", "cert/my-pubcert.pem");
define("DEFAULT_EWP_PRIVATE_KEY_PATH", "cert/my-prvkey.pem");
define("DEFAULT_EWP_PRIVATE_KEY_PWD", "password");
define("DEFAULT_CERT_ID", "B62GVU8RWNBFC");
define("PAYPAL_CERT_PATH", "cert/paypal_cert_pem.txt");
define("BUTTON_IMAGE", "https://www.paypal.com/en_US/i/btn/x-click-but23.gif");
define("PAYPAL_IPN_LOG", "paypal-ipn.log");

?>