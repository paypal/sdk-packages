/*
 * Copyright 2005 PayPal, Inc. All Rights Reserved.
 */


using System;
using System.Text;
using CAPICOM;

namespace com.paypal.wps.util
{
	/// <summary>
	/// Wrapper class that communicates with the CAPICOM Component for Public Certificate functionality.
	/// ButtonEncryption Class expose the SignAndEncrypt Method to sign and envelope the incoming Clear text 
	/// and to return the encrypted string using the recipient private certificate 
	/// and paypal�s public certificate.
	/// </summary>
	public class ButtonEncryption
	{
		private Encoding _encoding = Encoding.Default;
		private string _recipientPublicCertPath;
		private Certificate _signerCert;
		private Certificate _recipientCert;

		#region Properties
		/// <summary>
		/// Character encoding, e.g. UTF-8, Windows-1252
		/// </summary>
		public string Charset
		{
			get { return _encoding.WebName; }
			set
			{
				if (value != null && value != "")
				{
					_encoding = Encoding.GetEncoding(value);
				}
			}
		}

		/// <summary>
		/// Path to the recipient's public certificate in PEM format
		/// </summary>
		public string RecipientPublicCertPath
		{
			get
			{
				return _recipientPublicCertPath;
			}
			set 
			{ 
				_recipientPublicCertPath = value;
				_recipientCert = new CertificateClass();
				_recipientCert.Load(_recipientPublicCertPath, "", 
					CAPICOM_KEY_STORAGE_FLAG.CAPICOM_KEY_STORAGE_DEFAULT, 
					CAPICOM_KEY_LOCATION.CAPICOM_CURRENT_USER_KEY);
			}
		}


		#endregion
		
		#region Public Methods
		/// <summary>
		/// Sign a message and Envolpe it for the recipient.
		/// </summary>
		/// <param name="clearText">message to be encrypted.</param>
		/// <param name="sPfxFile">Merchant's Private p12 Certificate File</param>
		/// <param name="sPfxPassword">Merchant's Private p12 Certificate's Password</param>
		/// <param name="sPPCertFile">Merchant's PayPal Public Certificate</param>
		/// <returns>Signed and Envoleped message</returns>
		public string SignAndEncrypt(string clearText,string sPfxFile,string sPfxPassword,string sPPCertFile)
		{
			LoadSignerCredential(sPfxFile, sPfxPassword);
			RecipientPublicCertPath = sPPCertFile;
			IntPtr bstr = UnicodeStringToBinaryString(clearText);
			string signed = Sign(bstr);
			string enveloped = Envelope(signed);
			return FormatForTransport(enveloped);
		}

		#endregion

		#region private Methods
		/// <summary>
		/// Loads the pk12 certificates with its password.
		/// </summary>
		/// <param name="signerPfxCertPath">File path to the signer's public certificate plus private key in PFX (P12) format</param>
		/// <param name="signerPfxCertPassword">Password for signer's private key</param>
		private void LoadSignerCredential(string signerPfxCertPath, string signerPfxCertPassword)
		{
			
			_signerCert = new CertificateClass();
			
			
			//Loads the PKCS12 Certificate in its Default settings.
			
			_signerCert.Load(signerPfxCertPath, signerPfxCertPassword, 
				CAPICOM_KEY_STORAGE_FLAG.CAPICOM_KEY_STORAGE_DEFAULT, 
				CAPICOM_KEY_LOCATION.CAPICOM_CURRENT_USER_KEY);
		}

		/// <summary>
		/// Sign a message it for the recipient.
		/// </summary>
		/// <param name="bstr">message to be signed</param>
		/// <returns>Signed data</returns>
		private string Sign(IntPtr bstr)
		{
			ISigner signer = new SignerClass();
			signer.Certificate = _signerCert;
			SignedData signed = new SignedDataClass();
			signed.set_Content(bstr);
			//create the signed content from the clear text with the message attached and encoded in the Binary format.
			string result = signed.Sign(signer, false, CAPICOM_ENCODING_TYPE.CAPICOM_ENCODE_BINARY);
			return result;
		}
		/// <summary>
		/// Envolpe the signed message for the recipient.
		/// </summary>
		/// <param name="bstr"> signed message </param>
		/// <returns>Envolped data</returns>
		private string Envelope(string bstr)
		{
			EnvelopedData enveloped = new EnvelopedDataClass();
			enveloped.Content = bstr;
			enveloped.Recipients.Add(_recipientCert);
			//Envolpe the signed content using the recipient certificate and encoded in the Binary format.
			string result = enveloped.Encrypt(CAPICOM_ENCODING_TYPE.CAPICOM_ENCODE_BINARY);
			return result;
		}
		/// <summary>
		/// Format the Envolped message as viewable text.
		/// </summary>
		/// <param name="bstr">Envolped message </param>
		/// <returns>viewable text</returns>
		private string FormatForTransport(string bstr)
		{
			const string PKCS7_HEADER ="-----BEGIN PKCS7-----";
			const string PKCS7_FOOTER = "-----END PKCS7-----";

			Utilities utils = new UtilitiesClass();
			string base64 = utils.Base64Encode(bstr);
			StringBuilder formatted = new StringBuilder();
			//Appendes Pkcs7 header.
			formatted.Append(PKCS7_HEADER);
			//Remove all the line feed char in to spaces .
			formatted.Append(base64.Replace("\r\n", ""));
			formatted.Append(PKCS7_FOOTER);
			//returns Human readable encrypted contents formatted in BASE64 Format.
			return formatted.ToString();
		}

		/// <summary>
		/// Transform the UnicodeString To BinaryString.
		/// So it will be used for the other env.
		/// </summary>
		/// <param name="ustr">Unicode String</param>
		/// <returns>64 base Binary String</returns>
		private IntPtr UnicodeStringToBinaryString(string ustr)
		{
			byte[] bytes = _encoding.GetBytes(ustr);
			Utilities utils = new UtilitiesClass();
			IntPtr bstr = utils.ByteArrayToBinaryString(bytes);
			//returns Binary string.
			return bstr;
		}    
		#endregion
	}
}
