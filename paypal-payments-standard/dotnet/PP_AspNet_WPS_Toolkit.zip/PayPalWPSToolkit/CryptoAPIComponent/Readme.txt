Readme
========
1.COM Component : Capicom.dll  version 2.0.1.(downloaded from the Microsoft)
2. Register Capicom.dll using the Regsvr32 command.
