using System;
using System.Net;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.IO;
using System.Collections.Specialized;
using System.Collections;
using com.paypal.wps.util;
using System.Web;

namespace ASPDotNetSamples
{
	/// <summary>
	/// Displays the PDT Response from the PayPal server.Initial PDT Response returned from the PayPal site thru  HTTP GET 
	/// would post back to the PayPal server to get all transaction details
	/// </summary>
	public class PDTResponse : Page
	{
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		private const string AMPERSAND = "\n";
		private const string EQUALS = "=";
		private static readonly char[] AMPERSAND_CHAR_ARRAY = AMPERSAND.ToCharArray();
		protected System.Web.UI.WebControls.Label pdttable;
		protected System.Web.UI.WebControls.Label pdttableGet;
		protected System.Web.UI.WebControls.PlaceHolder PDTPlaceHolder;
		private static readonly char[] EQUALS_CHAR_ARRAY = EQUALS.ToCharArray();
		
		private void Page_Load(object sender, EventArgs e)
		{
			/*
			 * Construct display table for HTTP GET Response.
			 * */
		pdttableGet.Text = "<TABLE cellspacing=1 cellpadding=0 border=1 width=400>"
							+"<tr><td align=left nowrap> <font face=Verdana color=black size=2>Transaction ID:</font></td><td align=left> <font face=Verdana color=black size=2>"+this.TransactionID+"</font></td></tr>"
							+"<tr><td align=left nowrap> <font face=Verdana color=black size=2>Currency Code:</font></td><td align=left> <font face=Verdana color=black size=2>"+this.CurrencyCode+"</td></tr>"
							+"<tr><td align=left nowrap> <font face=Verdana color=black size=2>status:</font></td><td align=left> <font face=Verdana color=black size=2>"+this.Status+"</font></td></tr>"
						    +"<tr><td align=left nowrap> <font face=Verdana color=black size=2>amount :</font></td><td align=left> <font face=Verdana color=black size=2>"+this.Amount+"</font></td></tr>"
							+"<tr><td align=left nowrap> <font face=Verdana color=black size=2>Custom Message :</font></td><td align=left> <font face=Verdana color=black size=2>"+this.CustomMessage+"</font></td></tr>"
							+"<tr><td align=left nowrap> <font face=Verdana color=black size=2>Signature :</font></td><td align=left> <font face=Verdana color=black size=2>"+this.Signature+"</font></td></tr>"
							+ "</table>";

		NVPCodec codec = new NVPCodec();
			foreach(DictionaryEntry de in new DictionaryEntry[]
						{
							new DictionaryEntry("cmd", "_notify-synch"),
							new DictionaryEntry("tx", this.TransactionID),
							new DictionaryEntry("at", Constants.STANDARD_IDENTITY_TOKEN)
						}
				)
			{
				codec.Add((string)de.Key, (string)de.Value);
			}
			string strPost = codec.Encode();
			string result = Utils.HttpPost(Constants.WEBSCR_URL, strPost);
			/*
			* Construct display table for HTTP Post Response.
			* */
			string PDTresult = result;
			pdtvalues = new ArrayList();
			string tablestr="<TABLE cellspacing=1 cellpadding=0 border=0>";
			foreach (string nvp in PDTresult.Split(AMPERSAND_CHAR_ARRAY))
			{
				if (nvp=="SUCCESS")
				{
				tablestr = tablestr + "<tr><td align=left colspan=2> <font face=Verdana color=black size=2>"+nvp+"</font></td></tr>";
				}

				string[] PDTtokens = nvp.Split(EQUALS_CHAR_ARRAY);
				if (PDTtokens.Length >= 2)
				{
					string name =  HttpUtility.UrlDecode(PDTtokens[0]); 
					string valuepair = HttpUtility.UrlDecode(PDTtokens[1]);
					tablestr = tablestr + "<tr><td align=left> <font face=Verdana color=black size=2>"+name+": "+"</font></td><td align=left><font face=Verdana color=black size=2>"+valuepair+"</font></td></tr>";
				}
			}

				pdttable.Text = tablestr+"</table>";
			if (!IsPostBack)
			{
				DataBind();
			}
		}

		protected System.Web.UI.WebControls.Literal DebugLiteral;
		protected System.Web.UI.WebControls.Literal PDTResultLiteral;
		protected System.Web.UI.WebControls.Repeater PDTValuesRepeater;
	
		public bool PDTPlaceHolderVisible
		{
			get
			{
				return null != Constants.STANDARD_IDENTITY_TOKEN && Constants.STANDARD_IDENTITY_TOKEN != string.Empty;
			}
		}

		public bool NoIdentityTokenPlaceHolderVisible
		{
			get
			{
				return !PDTPlaceHolderVisible;
			}
		}


		private IList pdtvalues = new string[0];
		protected System.Web.UI.WebControls.PlaceHolder NoIdentityTokenPlaceHolder;
	
		public IEnumerable PDTValues {	get { return pdtvalues;	} }

	

		public string TransactionID
		{
			get
			{
				return this.Request.QueryString["tx"];
			}
		}
		public string Status
		{
			get
			{
				return this.Request.QueryString["st"];
			}
		}
		public string Amount
		{
			get
			{
				return this.Request.QueryString["amt"];
			}
		}
		public string CurrencyCode
		{
			get
			{
				return this.Request.QueryString["cc"];
			}
		}
		public string Signature
		{
			get
			{
				int _strlen = 50;
				int _strIndex = 0;
				int _formattedstrlen = 0;
				string _tempstring=String.Empty;

				if (this.Request.QueryString["sig"] != null && this.Request.QueryString["sig"].Length>_strlen){
					string formattedsignature = this.Request.QueryString["sig"].ToString();
					_formattedstrlen=formattedsignature.Length;
					while(_formattedstrlen>_strlen)
					{
						_tempstring=_tempstring+formattedsignature.Substring(_strIndex,_strlen)+"\n";
						_strIndex=_strIndex+_strlen;
						_formattedstrlen=_formattedstrlen -_strlen;
					}
				
					_tempstring=_tempstring+formattedsignature.Substring(_strIndex,formattedsignature.Length-_strIndex);
					}
						return _tempstring;
			}
		}
		public string CustomMessage
		{
			get
			{
				return HttpUtility.UrlDecode(this.Request.QueryString["cm"]);
			}
		}
		
	

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
