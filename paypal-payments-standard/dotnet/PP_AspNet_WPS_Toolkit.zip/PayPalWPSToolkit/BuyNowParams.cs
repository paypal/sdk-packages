namespace ASPDotNetSamples
{
	/// <summary>
	/// Handles the parameters for BuyNow Button
	/// </summary>
	public class BuyNowParams
	{
		private string itemName = string.Empty;
		public string ItemName
		{
			get
			{
				return itemName;
			}
			set
			{
				itemName = value;
			}
		}
		
		private string itemNumber = string.Empty;
		public string ItemNumber
		{
			get
			{
				return itemNumber;
			}
			set
			{
				itemNumber = value;
			}
		}
		
		private string amount = string.Empty;
		public string Amount
		{
			get
			{
				return amount;
			}
			set
			{
				amount = value;
			}
		}
		
		private string currency = string.Empty;
		public string Currency
		{
			get
			{
				return currency;
			}
			set
			{
				currency = value;
			}
		}
		
		private string shippingValue = string.Empty;
		public string ShippingValue
		{
			get
			{
				return shippingValue;
			}
			set
			{
				shippingValue = value;
			}
		}

		
		private string noteValue = string.Empty;
		public string NoteValue
		{
			get
			{
				return noteValue;
			}
			set
			{
				noteValue = value;
			}
		}

		private string returnUrl = string.Empty;
		public string ReturnURL
		{
			get
			{
				return returnUrl;
			}
			set
			{
				returnUrl = value;
			}
		}

		private string cancelUrl = string.Empty;
		public string CancelURL
		{
			get
			{
				return cancelUrl;
			}
			set
			{
				cancelUrl = value;
			}
		}
		
		private string notifyUrl = string.Empty;
		public string NotifyUrl
		{
			get
			{
				return notifyUrl;
			}
			set
			{
				notifyUrl = value;
			}
		}
	}
}
