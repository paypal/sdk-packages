EWP  Credentials (sandbox and beta-sandbox)
=================================================

Certificate ID 	: B62GVU8RWNBFC

PKCS12 File	: sdk-ewp.p12
PKCS12 Passowrd : password
