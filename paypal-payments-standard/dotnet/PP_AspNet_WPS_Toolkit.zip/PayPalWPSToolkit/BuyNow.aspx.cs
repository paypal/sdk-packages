using System;
using System.Collections.Specialized;
using System.Web;
using System.Net;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Text;
using com.paypal.wps.services;
using com.paypal.wps.profiles;

namespace ASPDotNetSamples
{
	/// <summary>
	/// Generates the Encrypted BuyNow Button.
	/// </summary>
	public class BuyNow : Page
	{
		protected System.Web.UI.WebControls.Repeater FormValuesDisplayRepeater;
		protected HtmlForm Form1;
		protected System.Web.UI.WebControls.Literal ButtonLiteral;

		private string buttonLiteralText = string.Empty;

		public IEnumerable FormParamsRepeaterDataSource
		{
			get
			{
				return new DictionaryEntry[]
					{
						new DictionaryEntry("cmd", "_xclick"), 
						new DictionaryEntry("business", Constants.STANDARD_EMAIL_ADDRESS), 
						new DictionaryEntry("cert_id", Constants.CERT_ID), 
						new DictionaryEntry("charset", "UTF-8"), 
						new DictionaryEntry("item_name", Global.CurrentBuyNowParams.ItemName), 
						new DictionaryEntry("item_number", Global.CurrentBuyNowParams.ItemNumber), 
						new DictionaryEntry("amount", Global.CurrentBuyNowParams.Amount), 
						new DictionaryEntry("currency_code", Global.CurrentBuyNowParams.Currency),
						new DictionaryEntry("return", Global.CurrentBuyNowParams.ReturnURL), 
						new DictionaryEntry("cancel_return", Global.CurrentBuyNowParams.CancelURL), 
						new DictionaryEntry("notify_url", Global.CurrentBuyNowParams.NotifyUrl), 
						new DictionaryEntry("custom", "PayPal EWP Sample"),
						new DictionaryEntry("no_shipping", "1")

					
					};
			}
		}
		
		private void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				EWPServices EWP	 = new EWPServices();
				/*
				WARNING: Do not embed plaintext credentials in your application code.
				Doing so is insecure and against best practices.
				Your API credentials must be handled securely. Please consider 
				encrypting them for use in any production environment, and ensure
				that only authorized individuals may view or modify them.
				*/
				DefaultEWPProfile EWPProfile =(DefaultEWPProfile)ProfileFactory.CreateEWPProfile();
				//loads Merchants private Certficate to the EWPProfile. 
				EWPProfile.CertificateFile= Request.PhysicalApplicationPath + @"EWPcert\sdk-ewp.p12";	
				//loads Paypal's public Certficate from the Sandbox Account to the EWPProfile.
				EWPProfile.PayPalCertificateFile= Request.PhysicalApplicationPath + @"EWPcert\paypal_cert_pem.txt";	
				EWPProfile.PrivateKeyPassword="password";
				//loads Merchants private Certficate key. 
				EWPProfile.PrivateKey= Request.PhysicalApplicationPath + @"EWPcert\sdk-ewp.p12";//using sdk-ewp.p12 as "Dummy file" for private key.			
				EWPProfile.Url = Constants.PAYPAL_URL;
				EWPProfile.ButtonImage = Constants.PAYPAL_URL +"/en_US/i/btn/x-click-but23.gif";
				EWP.EWPProfile = EWPProfile;

				StringBuilder sb = new StringBuilder();
				foreach (DictionaryEntry de in this.FormParamsRepeaterDataSource)
				{
					string name = (string)de.Key;
					string value = (string)de.Value;
					sb.Append(name).Append("=").Append(value).Append("\n");
				}
				// EncryptButton of EWP services returns the encrypted Html pay Button.
				buttonLiteralText =EWP.EncryptButton(sb.ToString(),Global.CurrentBuyNowParams.ItemName,Global.CurrentBuyNowParams.Amount);
				DataBind();
			}
		}

		public string ButtonLiteralText
		{
			get { return buttonLiteralText; }
		}

		public string ItemNameLiteralText
		{
			get { return Global.CurrentBuyNowParams.ItemName; }
		}
		
		public string AmountLiteralText
		{
			get{ return Global.CurrentBuyNowParams.Amount; }
		}
		
		public string CurrencyLiteralText
		{
			get { return Global.CurrentBuyNowParams.Currency; }
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
