using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace ASPDotNetSamples
{
	/// <summary>
	/// Collects inputs for generating Encrypted button.
	/// </summary>
	public class InputBuyNowParameters : Page
	{
		protected System.Web.UI.WebControls.TextBox ItemNameTextBox;
		protected System.Web.UI.WebControls.TextBox ItemNumberTextBox;
		protected System.Web.UI.WebControls.TextBox AmountTextBox;
		protected System.Web.UI.WebControls.DropDownList CurrencyDropDownList;
		protected System.Web.UI.WebControls.Button SubmitButton;
		protected System.Web.UI.WebControls.RequiredFieldValidator Requiredfieldvalidator1;
		protected System.Web.UI.WebControls.RequiredFieldValidator Requiredfieldvalidator2;
		protected System.Web.UI.WebControls.RequiredFieldValidator Requiredfieldvalidator3;
		protected System.Web.UI.WebControls.Literal ReturnUrlLiteral;
		protected System.Web.UI.WebControls.Literal CancelUrlLiteral;
		protected System.Web.UI.WebControls.Literal NotifyUrlLiteral;
		protected System.Web.UI.HtmlControls.HtmlForm InputBuyNowParametersForm;
	
	
		private void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				DataBind();
			}
		}
		
		public void SubmitButton_Click(object sender, EventArgs e)
		{
			BuyNowParams buyNowParams = new BuyNowParams();
			buyNowParams.ItemName = ItemNameTextBox.Text;
			buyNowParams.ItemNumber = ItemNumberTextBox.Text;
			buyNowParams.Amount = AmountTextBox.Text;
			buyNowParams.Currency = CurrencyDropDownList.SelectedValue;
			buyNowParams.ReturnURL = ReturnUrlLiteral.Text;
			buyNowParams.CancelURL = CancelUrlLiteral.Text;
			buyNowParams.NotifyUrl = NotifyUrlLiteral.Text;
			Session[Constants.BUY_NOW_PARAMS_SESSION_KEY] = buyNowParams;
			Response.Redirect("BuyNow.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
