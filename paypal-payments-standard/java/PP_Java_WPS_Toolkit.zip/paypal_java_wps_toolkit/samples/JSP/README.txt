README for PayPal WPS Toolkit JSP Sample
========================================

Steps to run the PayPal Java WPS Toolkit JSP Sample:

1. Download and install the following required software.

   Software:          Version:       Download from:
   =========          ========       ==============
   J2SE 1.4.2 SDK     1.4.2          http://java.sun.com/j2se/1.4.2/download.html
   Apache Tomcat      4.1 or 5.0     http://tomcat.apache.org/

2. Copy the <PayPal WPS ToolKit ROOT>\samples\JSP\dist\paypalwps.war file to your Tomcat webapps folder 
   (<TOMCAT ROOT>\webapps\).

3. Restart Apache Tomcat.

4. Using Tomcat's default configuration ( that is using port 8080) running on your local machine, to access the 
   PayPal WPS Toolkit  JSP Sample homepage, open the following URL:

   http://localhost:8080/paypalwps/


5. The PayPal IPN log file (paypal-ipn.log) will be created under <TOMCAT ROOT>\webapps\paypalwps folder.

Steps to build the PayPal Java WPS Toolkit JSP Sample:

1. Download and install the following required software.

   Software:          Version:       Download from:
   =========          ========       ==============
   Apache Ant         1.6.5          http://ant.apache.org/bindownload.cgi

2. Run ant in the <PayPal WPS Toolkit ROOT>\samples\JSP\ folder.