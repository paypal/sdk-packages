module ButtonManagerSamples
  VERSION = "1.103.0"
end
