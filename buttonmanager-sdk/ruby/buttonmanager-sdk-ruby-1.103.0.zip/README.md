Install gem:

    gem install gem/paypal-sdk-core-0.2.4.gem
    gem install gem/paypal-sdk-buttonmanager-1.103.0.gem
	
    #To try samples
    gem install gem/button_manager_samples-1.103.0.gem
	
Add library to you project `Gemfile`:

    gem 'paypal-sdk-buttonmanager'

    #To try samples
    gem 'button_manager_samples', :group => :development

Generate configuration in rails application:

    rails g paypal:sdk:install

Configure routes(`config/routes.rb`) for access samples:

    mount ButtonManagerSamples::Engine => "/samples" if Rails.env.development?
