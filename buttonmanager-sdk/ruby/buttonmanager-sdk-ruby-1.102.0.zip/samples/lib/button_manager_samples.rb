require "paypal-sdk-buttonmanager"
require "button_manager_samples/engine"
require "simple_form"
require "haml"
require "twitter-bootstrap-rails"
require "coderay"
require "jquery-rails"

module ButtonManagerSamples
end
