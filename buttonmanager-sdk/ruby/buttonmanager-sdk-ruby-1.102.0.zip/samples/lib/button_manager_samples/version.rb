module ButtonManagerSamples
  VERSION = "1.102.0"
end
