module ButtonManagerSamples
  VERSION = "1.98.0"
end
