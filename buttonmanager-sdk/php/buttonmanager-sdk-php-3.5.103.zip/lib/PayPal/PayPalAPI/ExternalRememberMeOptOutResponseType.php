<?php 
namespace PayPal\PayPalAPI;
use PayPal\EBLBaseComponents\AbstractResponseType; 
/**
 * 
 */
class ExternalRememberMeOptOutResponseType  extends AbstractResponseType  
  {


}
