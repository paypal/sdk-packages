<?php 
namespace PayPal\PayPalAPI;
use PayPal\PayPalAPI\DoExpressCheckoutPaymentRequestType; 
/**
 * 
 */
class DoUATPExpressCheckoutPaymentRequestType  extends DoExpressCheckoutPaymentRequestType  
  {


    
}
