<?php 
namespace PayPal\PayPalAPI;
use PayPal\EBLBaseComponents\AbstractRequestType; 
/**
 * 
 */
class CreateRecurringPaymentsProfileRequestType  extends AbstractRequestType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var PayPal\EBLBaseComponents\CreateRecurringPaymentsProfileRequestDetailsType	 
	 */ 
	public $CreateRecurringPaymentsProfileRequestDetails;


    
}
