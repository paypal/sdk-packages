<?php 
namespace PayPal\PayPalAPI;
use PayPal\EBLBaseComponents\AbstractResponseType; 
/**
 * 
 */
class DoMobileCheckoutPaymentResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var PayPal\EBLBaseComponents\DoMobileCheckoutPaymentResponseDetailsType	 
	 */ 
	public $DoMobileCheckoutPaymentResponseDetails;


}
