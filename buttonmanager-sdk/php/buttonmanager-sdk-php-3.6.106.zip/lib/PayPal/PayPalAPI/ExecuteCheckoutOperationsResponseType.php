<?php 
namespace PayPal\PayPalAPI;
use PayPal\EBLBaseComponents\AbstractResponseType; 
/**
 * 
 */
class ExecuteCheckoutOperationsResponseType  extends AbstractResponseType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var PayPal\EBLBaseComponents\ExecuteCheckoutOperationsResponseDetailsType	 
	 */ 
	public $ExecuteCheckoutOperationsResponseDetails;


}
